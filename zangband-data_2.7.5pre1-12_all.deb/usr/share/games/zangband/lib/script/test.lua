-- A very simple test-suite for Lua support in Angband

-- Hack - this doesn't work now, it needs some replacing.
