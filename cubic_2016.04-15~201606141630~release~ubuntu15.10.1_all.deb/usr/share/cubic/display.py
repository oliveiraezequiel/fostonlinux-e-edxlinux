#!/usr/bin/python3

################################################################################
#                                                                              #
# display.py                                                                   #
#                                                                              #
# Copyright (C) 2015 PJ Singh <psingh.cubic@gmail.com>                         #
#                                                                              #
################################################################################

################################################################################
#                                                                              #
# This file is part of Cubic - Custom Ubuntu ISO Creator.                      #
#                                                                              #
# Cubic is free software: you can redistribute it and/or modify                #
# it under the terms of the GNU General Public License as published by         #
# the Free Software Foundation, either version 3 of the License, or            #
# (at your option) any later version.                                          #
#                                                                              #
# Cubic is distributed in the hope that it will be useful,                     #
# but WITHOUT ANY WARRANTY; without even the implied warranty of               #
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                #
# GNU General Public License for more details.                                 #
#                                                                              #
# You should have received a copy of the GNU General Public License            #
# along with Cubic.  If not, see <http://www.gnu.org/licenses/>.               #
#                                                                              #
################################################################################

import logger
import model

import gi

from gi.repository import GLib

gi.require_version('Gtk', '3.0')
from gi.repository import Gtk

import time


def set_visible(widget_name, is_visible):
    widget = model.builder.get_object(widget_name)
    GLib.idle_add(Gtk.Widget.set_visible, widget, is_visible)


def set_solid(widget_name, is_solid):
    widget = model.builder.get_object(widget_name)
    GLib.idle_add(Gtk.Widget.set_opacity, widget, is_solid)


def set_sensitive(widget_name, is_sensitive):
    widget = model.builder.get_object(widget_name)
    GLib.idle_add(Gtk.Widget.set_sensitive, widget, is_sensitive)


def set_label_error(widget_name, is_error):
    # logger.log_data('The entry to un/set error is', widget_name)

    label = model.builder.get_object(widget_name)

    if is_error:
        GLib.idle_add(Gtk.Label.set_name, label, 'error')
    else:
        GLib.idle_add(Gtk.Label.set_name, label, 'normal')

        # logger.log_data('The label name has been set to', label.get_name())


def set_entry_error(widget_name, is_error):
    # logger.log_data('The entry to un/set error is', widget_name)

    entry = model.builder.get_object(widget_name)
    name = entry.get_name()
    # logger.log_data('The entry name is', name)

    if is_error:
        if name == 'normal':
            GLib.idle_add(Gtk.Entry.set_name, entry, 'error')
        elif name == 'non-editable':
            GLib.idle_add(Gtk.Entry.set_name, entry, 'error_non-editable')
    else:
        if name == 'error':
            GLib.idle_add(Gtk.Entry.set_name, entry, 'normal')
        elif name == 'error_non-editable':
            GLib.idle_add(Gtk.Entry.set_name, entry, 'non-editable')

            # logger.log_data('The entry name has been set to', entry.get_name())


def set_entry_editable(widget_name, is_editable):
    # logger.log_data('The entry to un/set editable is', widget_name)

    entry = model.builder.get_object(widget_name)
    name = entry.get_name()
    # logger.log_data('The entry name is', name)

    if is_editable:
        if name == 'non-editable':
            GLib.idle_add(Gtk.Entry.set_name, entry, 'normal')
        elif name == 'error_non-editable':
            GLib.idle_add(Gtk.Entry.set_name, entry, 'error')
    else:
        if name == 'normal':
            GLib.idle_add(Gtk.Entry.set_name, entry, 'non-editable')
        elif name == 'error':
            GLib.idle_add(Gtk.Entry.set_name, entry, 'error_non-editable')

    entry.set_editable(is_editable)

    # logger.log_data('The entry name has been set to', entry.get_name())


def show_spinner():
    grid = model.builder.get_object('window_grid')
    GLib.idle_add(Gtk.Grid.set_sensitive, grid, False)

    spinner = model.builder.get_object('window_spinner')
    GLib.idle_add(Gtk.Spinner.start, spinner)
    GLib.idle_add(Gtk.Spinner.set_visible, spinner, True)


def hide_spinner():
    spinner = model.builder.get_object('window_spinner')
    GLib.idle_add(Gtk.Spinner.set_visible, spinner, False)
    GLib.idle_add(Gtk.Spinner.stop, spinner)

    grid = model.builder.get_object('window_grid')
    GLib.idle_add(Gtk.Grid.set_sensitive, grid, True)


def update_label(label_name, text):
    label = model.builder.get_object(label_name)
    GLib.idle_add(Gtk.Label.set_text, label, text)


def update_entry(entry_name, text):
    entry = model.builder.get_object(entry_name)
    GLib.idle_add(Gtk.Entry.set_text, entry, text)


def update_menuitem(menuitem_name, text):
    menuitem = model.builder.get_object(menuitem_name)
    GLib.idle_add(Gtk.MenuItem.set_label, menuitem, text)


def update_progressbar_percent(progressbar_name, percent):
    progressbar = model.builder.get_object(progressbar_name)
    GLib.idle_add(Gtk.ProgressBar.set_fraction, progressbar, float(percent) / 100.0)


def update_progressbar_text(progressbar_name, text):
    progressbar = model.builder.get_object(progressbar_name)
    GLib.idle_add(Gtk.ProgressBar.set_text, progressbar, text)


def activate_radiobutton(radiobutton_name, is_active):
    radiobutton = model.builder.get_object(radiobutton_name)
    GLib.idle_add(Gtk.RadioButton.set_active, radiobutton, is_active)


def insert_listbox_row_label(listbox_name, row_number, text, additional_height=0):
    # Since label is not displayed, there is no need to call GLib.idle_add().
    label = Gtk.Label(text)
    label.set_halign(Gtk.Align.START)
    label.set_visible(True)
    preferred_height = label.get_preferred_height()[0]
    label.set_size_request(-1, preferred_height + additional_height)

    listbox = model.builder.get_object(listbox_name)
    GLib.idle_add(Gtk.ListBox.insert, listbox, label, row_number)


def insert_listbox_row_checkbutton(listbox_name, row_number, text, is_active, additional_height=0):
    # Since checkbutton is not displayed, there is no need to call GLib.idle_add().
    checkbutton = Gtk.CheckButton(text)
    checkbutton.set_halign(Gtk.Align.START)
    checkbutton.set_visible(True)
    checkbutton.set_active(is_active)
    preferred_height = checkbutton.get_preferred_height()[0]
    checkbutton.set_size_request(-1, preferred_height + additional_height)

    listbox = model.builder.get_object(listbox_name)
    GLib.idle_add(Gtk.ListBox.insert, listbox, checkbutton, row_number)


def get_listbox_row_count(listbox_name):
    listbox = model.builder.get_object(listbox_name)
    return len(listbox.get_children())


def get_listbox_row_widget(listbox_name, row_number):
    listbox = model.builder.get_object(listbox_name)
    listbox_row = listbox.get_row_at_index(row_number)

    child = listbox_row.get_children()[0]

    return child


def select_listbox_row(listbox_name, row_number):
    # TODO: Fix auto scrolling
    #       http://stackoverflow.com/questions/5218948/how-to-auto-scroll-a-gtk-scrolledwindow

    listbox = model.builder.get_object(listbox_name)
    listbox_row = listbox.get_row_at_index(row_number)

    GLib.idle_add(Gtk.ListBox.select_row, listbox, listbox_row)


def update_listbox_row_label(listbox_name, row_number, text):
    listbox = model.builder.get_object(listbox_name)
    listbox_row = listbox.get_row_at_index(row_number)
    label = listbox_row.get_children()[0]

    GLib.idle_add(Gtk.Label.set_text, label, text)
    # label.queue_draw()


def empty_listbox(listbox_name):
    listbox = model.builder.get_object(listbox_name)
    for listbox_row in listbox.get_children():
        child = listbox_row.get_children()[0]
        if isinstance(child, Gtk.Label):
            logger.log_data('Removing label', child.get_text())
        elif isinstance(child, Gtk.Button):
            logger.log_data('Removing button', child.get_label())
        else:
            logger.log_data('Removing unknown type', child)
        GLib.idle_add(Gtk.ListBox.remove, listbox, listbox_row)
        GLib.idle_add(Gtk.Widget.destroy, listbox_row)


# TODO: Replace this function with empty_listbox(), wherever this function is used.
def empty_listbox_labels(listbox_name):
    listbox = model.builder.get_object(listbox_name)
    for child in listbox.get_children():
        logger.log_data('About to remove', child.get_children()[0].get_text())
        # listbox.remove(child)
        GLib.idle_add(Gtk.ListBox.remove, listbox, child)


def update_liststore(liststore_name, data_list):
    liststore = model.builder.get_object(liststore_name)
    GLib.idle_add(_update_liststore_rows, liststore, data_list)


def _update_liststore_rows(liststore, data_list):
    liststore.clear()
    for number, data in enumerate(data_list):
        # logger.log_data('%i) Adding' % number, data, 'to the liststore.')
        liststore.append(data)


def update_liststore_ORIGINAL(liststore_name, data_list):
    liststore = model.builder.get_object(liststore_name)
    GLib.idle_add(Gtk.ListStore.clear, liststore)
    for number, data in enumerate(data_list):
        # logger.log_data('%i) Adding to the liststore' % number, data)
        GLib.idle_add(Gtk.ListStore.append, liststore, data)


def _update_liststore_progressbar_percent(liststore, path, percent):
    liststore[path][0] = percent


def update_liststore_progressbar_percent(liststore_name, path, percent):
    liststore = model.builder.get_object(liststore_name)
    GLib.idle_add(_update_liststore_progressbar_percent, liststore, path, percent)


def update_status(prefix, status):
    # The proper naming convention must be used.
    # Object ids must end in '_status', '_spinner', or '_spinner'.
    # 'status' and 'description' are synonyms for 'label' in the *.ui file.

    # Unicode characters (<Left-CTRL><Shift><u>)
    # • = 2022 = u\2022
    # ✓ = 2713 = u\2713

    label = model.builder.get_object('%s_status' % prefix)
    spinner = model.builder.get_object('%s_spinner' % prefix)

    if status == 'processing':

        GLib.idle_add(Gtk.Label.set_text, label, '')
        GLib.idle_add(Gtk.Spinner.set_visible, spinner, True)
        GLib.idle_add(Gtk.Spinner.set_opacity, spinner, True)
        GLib.idle_add(Gtk.Spinner.start, spinner)

    elif status == 'bullet':

        GLib.idle_add(Gtk.Label.set_text, label, '\u2022')
        GLib.idle_add(Gtk.Spinner.set_visible, spinner, False)
        GLib.idle_add(Gtk.Spinner.set_opacity, spinner, False)
        GLib.idle_add(Gtk.Spinner.stop, spinner)

    elif status == 'check':

        GLib.idle_add(Gtk.Label.set_text, label, '\u2713')
        GLib.idle_add(Gtk.Spinner.set_visible, spinner, False)
        GLib.idle_add(Gtk.Spinner.set_opacity, spinner, False)
        GLib.idle_add(Gtk.Spinner.stop, spinner)

    elif status == 'error':

        GLib.idle_add(Gtk.Label.set_text, label, '\u2715')
        GLib.idle_add(Gtk.Spinner.set_visible, spinner, False)
        GLib.idle_add(Gtk.Spinner.set_opacity, spinner, False)
        GLib.idle_add(Gtk.Spinner.stop, spinner)

    else:

        GLib.idle_add(Gtk.Label.set_text, label, status)
        GLib.idle_add(Gtk.Spinner.set_visible, spinner, False)
        GLib.idle_add(Gtk.Spinner.set_opacity, spinner, False)
        GLib.idle_add(Gtk.Spinner.stop, spinner)


def reset_buttons(page_name, is_quit_visible=False, is_back_visible=False, is_next_visible=False):
    button = model.builder.get_object('%s__quit_button' % page_name)
    GLib.idle_add(Gtk.Button.set_sensitive, button, is_quit_visible)

    button = model.builder.get_object('%s__back_button' % page_name)
    GLib.idle_add(Gtk.Button.set_sensitive, button, is_back_visible)

    button = model.builder.get_object('%s__next_button' % page_name)
    GLib.idle_add(Gtk.Button.set_sensitive, button, is_next_visible)


def show_page(old_page_name, new_page_name):
    # Hide the current page.
    logger.log_data('Hiding old page', old_page_name)
    grid = model.builder.get_object(old_page_name)
    GLib.idle_add(Gtk.Grid.set_visible, grid, False)

    print()

    # Show the next page
    logger.log_data('Showing new page', new_page_name)
    grid = model.builder.get_object(new_page_name)
    GLib.idle_add(Gtk.Grid.set_visible, grid, True)

    # Set the current page name.
    model.set_page_name(new_page_name)

    time.sleep(0.25)


def main_quit():
    time.sleep(0.50)
    GLib.idle_add(Gtk.main_quit)
