#!/usr/bin/python3

################################################################################
#                                                                              #
# cubic.py                                                                     #
#                                                                              #
# Copyright (C) 2015 PJ Singh <psingh.cubic@gmail.com>                         #
#                                                                              #
################################################################################

################################################################################
#                                                                              #
# This file is part of Cubic - Custom Ubuntu ISO Creator.                      #
#                                                                              #
# Cubic is free software: you can redistribute it and/or modify                #
# it under the terms of the GNU General Public License as published by         #
# the Free Software Foundation, either version 3 of the License, or            #
# (at your option) any later version.                                          #
#                                                                              #
# Cubic is distributed in the hope that it will be useful,                     #
# but WITHOUT ANY WARRANTY; without even the implied warranty of               #
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                #
# GNU General Public License for more details.                                 #
#                                                                              #
# You should have received a copy of the GNU General Public License            #
# along with Cubic.  If not, see <http://www.gnu.org/licenses/>.               #
#                                                                              #
################################################################################

import logger
import model

from handlers import MainWindowHandlers

import gi

from gi.repository import Gdk
from gi.repository import GLib

gi.require_version('Gtk', '3.0')
from gi.repository import Gtk

import pwd
import os

if not os.path.exists('cubic.ui') or not os.getenv('SUDO_USER') or 'kde' in os.getenv('XAUTHORITY'):
    print()
    print('Error: Cubic (Custom Ubuntu ISO Creator) is a graphical user interface application and should be run using the application launcher. See "man cubic" for more information.')
    print()
    exit(1)

theme = Gtk.Settings.get_default().get_property('gtk-theme-name')
logger.log_data('The current GTK theme is', theme)

current_directory = os.getcwd()
logger.log_data('The working directory is', current_directory)

model.set_user_name(os.getenv('SUDO_USER'))

pw_name, pw_passwd, pw_uid, pw_gid, pw_gecos, pw_dir, pw_shell = pwd.getpwnam(model.user_name)
# model.set_home(os.path.expanduser('~'))
model.set_home(os.path.expanduser(pw_dir))
model.set_user_id(pw_uid)
model.set_group_id(pw_gid)

model.set_builder(Gtk.Builder())
model.builder.add_from_file('cubic.ui')

handlers = MainWindowHandlers()
model.builder.connect_signals(handlers)

model.set_page_name('project_directory_page')

window = model.builder.get_object('window')

css_provider = Gtk.CssProvider()
css_provider.load_from_path('cubic.css')
screen = Gdk.Screen.get_default()
style_context = window.get_style_context()
style_context.add_provider_for_screen(screen, css_provider, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)

window.show()

GLib.threads_init()
Gdk.threads_enter()
Gtk.main()
Gdk.threads_leave()
