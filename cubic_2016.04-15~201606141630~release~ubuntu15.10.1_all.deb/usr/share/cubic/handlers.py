#!/usr/bin/python3

################################################################################
#                                                                              #
# handlers.py                                                                  #
#                                                                              #
# Copyright (C) 2015 PJ Singh <psingh.cubic@gmail.com>                         #
#                                                                              #
################################################################################

################################################################################
#                                                                              #
# This file is part of Cubic - Custom Ubuntu ISO Creator.                      #
#                                                                              #
# Cubic is free software: you can redistribute it and/or modify                #
# it under the terms of the GNU General Public License as published by         #
# the Free Software Foundation, either version 3 of the License, or            #
# (at your option) any later version.                                          #
#                                                                              #
# Cubic is distributed in the hope that it will be useful,                     #
# but WITHOUT ANY WARRANTY; without even the implied warranty of               #
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                #
# GNU General Public License for more details.                                 #
#                                                                              #
# You should have received a copy of the GNU General Public License            #
# along with Cubic.  If not, see <http://www.gnu.org/licenses/>.               #
#                                                                              #
################################################################################

import display
import logger
import model
import transition
import utilities
import validators

import configparser

import gi

from gi.repository import Gdk

gi.require_version('Gtk', '3.0')
from gi.repository import Gtk

import os


class MainWindowHandlers(Gtk.Window):
    transition_thread = None

    ############################################################################
    # Password Dialog Handlers (Not Used)
    ############################################################################

    def on_clicked__password_dialog__cancel_button(self, widget):

        logger.log_data('Button clicked', 'Password Cancel')

        display.main_quit()

    def on_clicked__password_dialog__ok_button(self, widget):

        logger.log_data('Button clicked', 'Password OK')

        entry = model.builder.get_object('password_dialog__password_entry')
        password = entry.get_text()
        logger.log_data('The password is', password)

    def on_destroy__password_dialog(self, *args):

        logger.log_data('Button clicked', 'Password Dialog Delete')

        display.main_quit()

    ############################################################################
    # Navigation Bar Handlers
    ############################################################################

    def on_destroy(self, *args):

        logger.log_data('Button clicked', 'Window Exit')

        self.transition_thread = transition.TransitionThread(model.page_name, 'exit', self.transition_thread)
        self.transition_thread.start()

    def on_clicked__quit_button(self, widget):

        logger.log_data('Button clicked', 'Quit')

        print('PAGE NAME = %s' % model.page_name)
        print('NEXT NAME = %s' % 'exit')
        print('TRANSITION THREAD = %s' % self.transition_thread)
        self.transition_thread = transition.TransitionThread(model.page_name, 'exit', self.transition_thread)
        self.transition_thread.start()

    def on_clicked__next_button(self, widget):

        # Project Directory Page
        # New Project Page
        # Existing Project Page
        # Confirm Delete Project Page
        # Unsquashfs Page
        # Terminal Page
        # Confirm Copy Page
        # Create Filesystem Manifest Page
        # Repackage ISO Page
        # Finish Page

        logger.log_data('Button clicked', 'Next')

        new_page_name = None

        # Project Directory Page
        if model.page_name == 'project_directory_page':
            # New Project
            if not os.path.exists(model.configuration_filepath):
                new_page_name = 'new_project_page'
            # Existing Project
            else:
                new_page_name = 'existing_project_page'
                # logger.log_data('New page name', model.new_page_name)

        # New Project Page
        elif model.page_name == 'new_project_page':
            new_page_name = 'terminal_page'

        # Existing Project Page
        elif model.page_name == 'existing_project_page':
            # Create a live ISO image from the existing project.
            if model.builder.get_object('existing_project_page__radiobutton_1').get_active():
                new_page_name = 'create_manifest_page'
            # Continue customizing the existing project.
            elif model.builder.get_object('existing_project_page__radiobutton_2').get_active():
                new_page_name = 'terminal_page'
            # Delete the existing project.
            elif model.builder.get_object('existing_project_page__radiobutton_3').get_active():
                new_page_name = 'delete_project_page'

        # Confirm Delete Project Page
        elif model.page_name == 'delete_project_page':
            new_page_name = 'new_project_page'

        # Unsquashfs Page
        elif model.page_name == 'unsquashfs_page':
            new_page_name = 'terminal_page'

        # Terminal Page
        elif model.page_name == 'terminal_page':
            new_page_name = 'create_manifest_page'

        # Confirm Copy Page
        elif model.page_name == 'copy_files_page':
            new_page_name = 'terminal_page_copy_files'

        # Create Filesystem Manifest Page
        elif model.page_name == 'create_manifest_page':
            new_page_name = 'repackage_iso_page'

        # Repackage ISO Page
        elif model.page_name == 'repackage_iso_page':
            new_page_name = 'finish_page'

        # Finish Page
        elif model.page_name == 'finish_page':
            new_page_name = 'exit'

        # Error
        else:
            logger.log_data('Error. Next page for the current page is not defined', model.page_name)

        self.transition_thread = transition.TransitionThread(model.page_name, new_page_name)
        self.transition_thread.start()

    def on_clicked__back_button(self, widget):

        # Project Directory Page
        # New Project Page
        # Existing Project Page
        # Confirm Delete Project Page
        # Unsquashfs Page
        # Terminal Page
        # Confirm Copy Page
        # Create Filesystem Manifest Page
        # Repackage ISO Page
        # Finish Page

        logger.log_data('Button clicked', 'Back')

        new_page_name = None

        # Project Directory Page (back button is disabled)
        if model.page_name == 'project_directory_page':
            pass

        # New Project Page
        elif model.page_name == 'new_project_page':
            new_page_name = 'project_directory_page'

        # Existing Project Page
        elif model.page_name == 'existing_project_page':
            new_page_name = 'project_directory_page'

        # Confirm Delete Project Page
        elif model.page_name == 'delete_project_page':
            new_page_name = 'existing_project_page'

        # Unsquashfs Page
        elif model.page_name == 'unsquashfs_page':
            new_page_name = 'existing_project_page'

        # Terminal Page
        elif model.page_name == 'terminal_page':
            new_page_name = 'existing_project_page'

        # Confirm Copy Page
        elif model.page_name == 'copy_files_page':
            new_page_name = 'terminal_page_cancel_copy_files'

        # Create Filesystem Mainfest Page
        elif model.page_name == 'create_manifest_page':
            # Case for a new project:
            # - Radio button 1 (create a disk image from the existing project)
            # - was selected on the Existing Project page.
            if model.builder.get_object('existing_project_page__radiobutton_1').get_active():
                new_page_name = 'existing_project_page'
            # Case for a new project:
            # - Radio button 2 (continue customizing the existing project).
            #   was programmatically set in the function
            #   transition__from__project_directory_page__to__new_project_page()
            # Case for an existing project:
            # - Radio button 2 (create a disk image from the existing project)
            # - was selected on the Existing Project page.
            elif model.builder.get_object('existing_project_page__radiobutton_2').get_active():
                new_page_name = 'terminal_page'
            else:
                logger.log_data('Error. Back page for the current page is not defined', model.page_name)

        # Repackage ISO Page
        elif model.page_name == 'repackage_iso_page':
            new_page_name = 'create_manifest_page'

        # Error
        else:
            logger.log_data('Error. Back page for the current page is not defined', model.page_name)

        self.transition_thread = transition.TransitionThread(model.page_name, new_page_name, self.transition_thread)
        self.transition_thread.start()

    ############################################################################
    # Project Directory Page Handlers
    ############################################################################

    def on_clicked__project_directory_page__project_directory_filechooser_open_button(self, widget):

        display.set_sensitive('window', False)

        dialog = model.builder.get_object('project_directory_page__project_directory_filechooser')
        dialog.set_current_folder(model.home)

        dialog.show_all()

    def on_changed__project_directory_page__project_directory_entry(self, widget):

        model.set_project_directory(widget.get_text())

        model.set_configuration_filepath(utilities.create_configuration_filepath(model.project_directory))
        model.set_original_iso_image_mount_point(utilities.create_original_iso_image_mount_point(model.project_directory))
        model.set_custom_squashfs_directory(utilities.create_custom_squashfs_directory(model.project_directory))
        model.set_custom_live_iso_directory(utilities.create_custom_live_iso_directory(model.project_directory))

        validators.validate_project_directory_page()

    ############################################################################
    # Project Directory Page Filechooser Handlers
    ############################################################################

    def on_delete_event__project_directory_page__project_directory_filechooser(self, widget, event):

        model.builder.add_objects_from_file('cubic.ui', [
            'project_directory_page__project_directory_filechooser'])
        model.builder.connect_signals(self)

        display.set_sensitive('window', True)

    def on_clicked__project_directory_page__project_directory_filechooser_cancel_button(self, widget):

        display.set_visible('project_directory_page__project_directory_filechooser', False)

        display.set_sensitive('window', True)

    def on_clicked__project_directory_page__project_directory_filechooser_select_button(self, widget):

        dialog = model.builder.get_object('project_directory_page__project_directory_filechooser')
        project_directory = dialog.get_filename()
        # project_directory = dialog.get_current_folder()
        display.update_entry('project_directory_page__project_directory_entry', project_directory)

        display.set_visible('project_directory_page__project_directory_filechooser', False)

        display.set_sensitive('window', True)

    ############################################################################
    # New Project Page Handlers - Original ISO
    ############################################################################

    def on_clicked__new_project_page__original_iso_image_filepath_filechooser_open_button(self, widget):

        display.set_sensitive('window', False)

        dialog = model.builder.get_object('new_project_page__original_iso_image_filepath_filechooser')
        dialog.set_current_folder(model.home)
        dialog.show_all()

    ############################################################################
    # New Project Page Handlers - Custom ISO
    ############################################################################

    def on_clicked__new_project_page__custom_iso_image_directory_filechooser_open_button(self, widget):

        display.set_sensitive('window', False)

        dialog = model.builder.get_object('new_project_page__custom_iso_image_directory_filechooser')
        dialog.set_current_folder(model.custom_iso_image_directory)
        dialog.show_all()

    def on_changed__new_project_page__custom_iso_image_version_number_entry(self, widget):

        model.set_custom_iso_image_version_number(widget.get_text())

        if model.propagate:
            custom_iso_image_filename = utilities.create_custom_iso_image_filename(model.original_iso_image_filename, model.custom_iso_image_version_number)
            display.update_entry('new_project_page__custom_iso_image_filename_entry', custom_iso_image_filename)

            custom_iso_image_volume_id = utilities.create_custom_iso_image_volume_id(model.original_iso_image_volume_id, model.custom_iso_image_version_number)
            display.update_entry('new_project_page__custom_iso_image_volume_id_entry', custom_iso_image_volume_id)

        validators.validate_new_project_page_custom()

    def on_changed__new_project_page__custom_iso_image_filename_entry(self, widget):

        model.set_custom_iso_image_filename(widget.get_text())
        model.set_custom_iso_image_filepath(os.path.join(model.custom_iso_image_directory, model.custom_iso_image_filename))

        model.set_custom_iso_image_md5_filename(utilities.create_custom_iso_image_md5_filename(model.custom_iso_image_filename))
        model.set_custom_iso_image_md5_filepath(os.path.join(model.custom_iso_image_directory, model.custom_iso_image_md5_filename))

        validators.validate_new_project_page_custom()

    def on_changed__new_project_page__custom_iso_image_directory_entry(self, widget):

        model.set_custom_iso_image_directory(widget.get_text())

        model.set_custom_iso_image_filepath(os.path.join(model.custom_iso_image_directory, model.custom_iso_image_filename))

        model.set_custom_iso_image_md5_filepath(os.path.join(model.custom_iso_image_directory, model.custom_iso_image_md5_filename))

        validators.validate_new_project_page_custom()

    def on_changed__new_project_page__custom_iso_image_volume_id_entry(self, widget):

        model.set_custom_iso_image_volume_id(widget.get_text())

        if model.propagate:
            custom_iso_image_disk_name = utilities.create_custom_iso_image_disk_name(model.custom_iso_image_volume_id, model.custom_iso_image_release_name)
            display.update_entry('new_project_page__custom_iso_image_disk_name_entry', custom_iso_image_disk_name)

        validators.validate_new_project_page_custom()

    def on_changed__new_project_page__custom_iso_image_release_name_entry(self, widget):

        model.set_custom_iso_image_release_name(widget.get_text())

        if model.propagate:
            custom_iso_image_disk_name = utilities.create_custom_iso_image_disk_name(model.custom_iso_image_volume_id, model.custom_iso_image_release_name)
            display.update_entry('new_project_page__custom_iso_image_disk_name_entry', custom_iso_image_disk_name)

        validators.validate_new_project_page_custom()

    def on_changed__new_project_page__custom_iso_image_disk_name_entry(self, widget):

        model.set_custom_iso_image_disk_name(widget.get_text())

        validators.validate_new_project_page_custom()

    ############################################################################
    # New Project Page Filechooser Handlers
    ############################################################################

    def on_delete_event__new_project_page__original_iso_image_filepath_filechooser(self, widget, event):

        model.builder.add_objects_from_file('cubic.ui', [
            'new_project_page__original_iso_image_filepath_filechooser'])
        model.builder.connect_signals(self)

        display.set_sensitive('window', True)

    def on_clicked__new_project_page__original_iso_image_filepath_filechooser_cancel_button(self, widget):

        display.set_visible('new_project_page__original_iso_image_filepath_filechooser', False)

        display.set_sensitive('window', True)

    def on_clicked__new_project_page__original_iso_image_filepath_filechooser_select_button(self, widget):

        self.transition_thread = transition.TransitionThread('original_iso_image_filepath_filechooser', 'new_project_page', self.transition_thread)
        self.transition_thread.start()

    def on_delete_event__new_project_page__custom_iso_image_directory_filechooser(self, widget, event):

        model.builder.add_objects_from_file('cubic.ui', [
            'new_project_page__custom_iso_image_directory_filechooser'])
        model.builder.connect_signals(self)

        display.set_sensitive('window', True)

    def on_clicked__new_project_page__custom_iso_image_directory_filechooser_cancel_button(self, widget):

        display.set_visible('new_project_page__custom_iso_image_directory_filechooser', False)

        display.set_sensitive('window', True)

    def on_clicked__new_project_page__custom_iso_image_directory_filechooser_select_button(self, widget):

        dialog = model.builder.get_object('new_project_page__custom_iso_image_directory_filechooser')
        custom_iso_image_directory = dialog.get_filename()
        # custom_iso_image_directory = dialog.get_current_folder()
        display.update_entry('new_project_page__custom_iso_image_directory_entry', custom_iso_image_directory)

        display.set_visible('new_project_page__custom_iso_image_directory_filechooser', False)

        display.set_sensitive('window', True)

    ############################################################################
    # Existing Project Page Handlers - Original ISO
    ############################################################################

    def on_clicked__existing_project_page__original_iso_image_filepath_filechooser_open_button(self, widget):

        display.set_sensitive('window', False)

        dialog = model.builder.get_object('existing_project_page__original_iso_image_filepath_filechooser')

        print('(3) The home folder is %s.' % model.home)
        dialog.set_current_folder(model.home)

        if os.path.exists(model.original_iso_image_directory):
            print('(2) The directory is %s.' % model.original_iso_image_directory)
            dialog.set_current_folder(model.original_iso_image_directory)

        if os.path.exists(model.original_iso_image_filepath):
            print('(1) The file name is %s.' % model.original_iso_image_filepath)
            dialog.set_filename(model.original_iso_image_filepath)

        dialog.show_all()

    ############################################################################
    # Existing Project Page Handlers - Radio Buttons
    ############################################################################

    def on_toggled__existing_project_page__radiobutton(self, widget):

        model.set_propagate(False)

        logger.log_step('The radio button was toggled')

        radiobutton_1 = model.builder.get_object('existing_project_page__radiobutton_1')
        radiobutton_2 = model.builder.get_object('existing_project_page__radiobutton_2')
        radiobutton_3 = model.builder.get_object('existing_project_page__radiobutton_3')

        if radiobutton_1.get_active():

            '''
            logger.log_step('Reloading configuration file values')

            # General
            configuration = configparser.RawConfigParser()
            configuration.read(model.configuration_filepath)

            # Original
            model.set_original_iso_image_filename(configuration.get('Original', 'original_iso_image_filename'))
            model.set_original_iso_image_directory(configuration.get('Original', 'original_iso_image_directory'))
            model.set_original_iso_image_filepath(os.path.join(model.original_iso_image_directory, model.original_iso_image_filename))
            model.set_original_iso_image_volume_id(configuration.get('Original', 'original_iso_image_volume_id'))
            model.set_original_iso_image_release_name(configuration.get('Original', 'original_iso_image_release_name'))
            model.set_original_iso_image_disk_name(configuration.get('Original', 'original_iso_image_disk_name'))

            # Custom
            model.set_custom_iso_image_version_number(configuration.get('Custom', 'custom_iso_image_version_number'))
            model.set_custom_iso_image_filename(configuration.get('Custom', 'custom_iso_image_filename'))
            model.set_custom_iso_image_directory(configuration.get('Custom', 'custom_iso_image_directory'))
            model.set_custom_iso_image_filepath(os.path.join(model.custom_iso_image_directory, model.custom_iso_image_filename))
            model.set_custom_iso_image_volume_id(configuration.get('Custom', 'custom_iso_image_volume_id'))
            model.set_custom_iso_image_release_name(configuration.get('Custom', 'custom_iso_image_release_name'))
            model.set_custom_iso_image_disk_name(configuration.get('Custom', 'custom_iso_image_disk_name'))
            model.set_custom_iso_image_md5_filename(configuration.get('Custom', 'custom_iso_image_md5_filename'))
            model.set_custom_iso_image_md5_filepath(os.path.join(model.custom_iso_image_directory, model.custom_iso_image_md5_filename))

            # Display original values.
            display.update_entry('existing_project_page__original_iso_image_filename_entry', model.original_iso_image_filename)
            display.update_entry('existing_project_page__original_iso_image_directory_entry', model.original_iso_image_directory)
            display.update_entry('existing_project_page__original_iso_image_volume_id_entry', model.original_iso_image_volume_id)
            display.update_entry('existing_project_page__original_iso_image_release_name_entry', model.original_iso_image_release_name)
            display.update_entry('existing_project_page__original_iso_image_disk_name_entry', model.original_iso_image_disk_name)

            # Display custom values.
            display.update_entry('existing_project_page__custom_iso_image_version_number_entry', model.custom_iso_image_version_number)
            display.update_entry('existing_project_page__custom_iso_image_filename_entry', model.custom_iso_image_filename)
            display.update_entry('existing_project_page__custom_iso_image_directory_entry', model.custom_iso_image_directory)
            display.update_entry('existing_project_page__custom_iso_image_volume_id_entry', model.custom_iso_image_volume_id)
            display.update_entry('existing_project_page__custom_iso_image_release_name_entry', model.custom_iso_image_release_name)
            display.update_entry('existing_project_page__custom_iso_image_disk_name_entry', model.custom_iso_image_disk_name)
            '''

            display.set_sensitive('existing_project_page__original_iso_image_filepath_filechooser_open_button', True)
            validators.validate_existing_project_page()

        elif radiobutton_2.get_active():

            '''
            logger.log_step('Reloading configuration file values')

            # General
            configuration = configparser.RawConfigParser()
            configuration.read(model.configuration_filepath)

            # Original
            model.set_original_iso_image_filename(configuration.get('Original', 'original_iso_image_filename'))
            model.set_original_iso_image_directory(configuration.get('Original', 'original_iso_image_directory'))
            model.set_original_iso_image_filepath(os.path.join(model.original_iso_image_directory, model.original_iso_image_filename))
            model.set_original_iso_image_volume_id(configuration.get('Original', 'original_iso_image_volume_id'))
            model.set_original_iso_image_release_name(configuration.get('Original', 'original_iso_image_release_name'))
            model.set_original_iso_image_disk_name(configuration.get('Original', 'original_iso_image_disk_name'))

            # Custom
            model.set_custom_iso_image_version_number(configuration.get('Custom', 'custom_iso_image_version_number'))
            model.set_custom_iso_image_filename(configuration.get('Custom', 'custom_iso_image_filename'))
            model.set_custom_iso_image_directory(configuration.get('Custom', 'custom_iso_image_directory'))
            model.set_custom_iso_image_filepath(os.path.join(model.custom_iso_image_directory, model.custom_iso_image_filename))
            model.set_custom_iso_image_volume_id(configuration.get('Custom', 'custom_iso_image_volume_id'))
            model.set_custom_iso_image_release_name(configuration.get('Custom', 'custom_iso_image_release_name'))
            model.set_custom_iso_image_disk_name(configuration.get('Custom', 'custom_iso_image_disk_name'))
            model.set_custom_iso_image_md5_filename(configuration.get('Custom', 'custom_iso_image_md5_filename'))
            model.set_custom_iso_image_md5_filepath(os.path.join(model.custom_iso_image_directory, model.custom_iso_image_md5_filename))

            # Display original values.
            display.update_entry('existing_project_page__original_iso_image_filename_entry', model.original_iso_image_filename)
            display.update_entry('existing_project_page__original_iso_image_directory_entry', model.original_iso_image_directory)
            display.update_entry('existing_project_page__original_iso_image_volume_id_entry', model.original_iso_image_volume_id)
            display.update_entry('existing_project_page__original_iso_image_release_name_entry', model.original_iso_image_release_name)
            display.update_entry('existing_project_page__original_iso_image_disk_name_entry', model.original_iso_image_disk_name)

            # Display custom values.
            display.update_entry('existing_project_page__custom_iso_image_version_number_entry', model.custom_iso_image_version_number)
            display.update_entry('existing_project_page__custom_iso_image_filename_entry', model.custom_iso_image_filename)
            display.update_entry('existing_project_page__custom_iso_image_directory_entry', model.custom_iso_image_directory)
            display.update_entry('existing_project_page__custom_iso_image_volume_id_entry', model.custom_iso_image_volume_id)
            display.update_entry('existing_project_page__custom_iso_image_release_name_entry', model.custom_iso_image_release_name)
            display.update_entry('existing_project_page__custom_iso_image_disk_name_entry', model.custom_iso_image_disk_name)
            '''

            display.set_sensitive('existing_project_page__original_iso_image_filepath_filechooser_open_button', True)
            validators.validate_existing_project_page()

        elif radiobutton_3.get_active():

            logger.log_step('Reloading configuration file values')

            # General
            configuration = configparser.RawConfigParser()
            configuration.read(model.configuration_filepath)

            # Original
            model.set_original_iso_image_filename(configuration.get('Original', 'original_iso_image_filename'))
            model.set_original_iso_image_directory(configuration.get('Original', 'original_iso_image_directory'))
            model.set_original_iso_image_filepath(os.path.join(model.original_iso_image_directory, model.original_iso_image_filename))
            model.set_original_iso_image_volume_id(configuration.get('Original', 'original_iso_image_volume_id'))
            model.set_original_iso_image_release_name(configuration.get('Original', 'original_iso_image_release_name'))
            model.set_original_iso_image_disk_name(configuration.get('Original', 'original_iso_image_disk_name'))

            # Custom
            model.set_custom_iso_image_version_number(configuration.get('Custom', 'custom_iso_image_version_number'))
            model.set_custom_iso_image_filename(configuration.get('Custom', 'custom_iso_image_filename'))
            model.set_custom_iso_image_directory(configuration.get('Custom', 'custom_iso_image_directory'))
            model.set_custom_iso_image_filepath(os.path.join(model.custom_iso_image_directory, model.custom_iso_image_filename))
            model.set_custom_iso_image_volume_id(configuration.get('Custom', 'custom_iso_image_volume_id'))
            model.set_custom_iso_image_release_name(configuration.get('Custom', 'custom_iso_image_release_name'))
            model.set_custom_iso_image_disk_name(configuration.get('Custom', 'custom_iso_image_disk_name'))
            model.set_custom_iso_image_md5_filename(configuration.get('Custom', 'custom_iso_image_md5_filename'))
            model.set_custom_iso_image_md5_filepath(os.path.join(model.custom_iso_image_directory, model.custom_iso_image_md5_filename))

            # Display original values.
            display.update_entry('existing_project_page__original_iso_image_filename_entry', model.original_iso_image_filename)
            display.update_entry('existing_project_page__original_iso_image_directory_entry', model.original_iso_image_directory)
            display.update_entry('existing_project_page__original_iso_image_volume_id_entry', model.original_iso_image_volume_id)
            display.update_entry('existing_project_page__original_iso_image_release_name_entry', model.original_iso_image_release_name)
            display.update_entry('existing_project_page__original_iso_image_disk_name_entry', model.original_iso_image_disk_name)

            # Display custom values.
            display.update_entry('existing_project_page__custom_iso_image_version_number_entry', model.custom_iso_image_version_number)
            display.update_entry('existing_project_page__custom_iso_image_filename_entry', model.custom_iso_image_filename)
            display.update_entry('existing_project_page__custom_iso_image_directory_entry', model.custom_iso_image_directory)
            display.update_entry('existing_project_page__custom_iso_image_volume_id_entry', model.custom_iso_image_volume_id)
            display.update_entry('existing_project_page__custom_iso_image_release_name_entry', model.custom_iso_image_release_name)
            display.update_entry('existing_project_page__custom_iso_image_disk_name_entry', model.custom_iso_image_disk_name)

            display.set_sensitive('existing_project_page__original_iso_image_filepath_filechooser_open_button', False)
            validators.validate_existing_project_page_for_delete()

        model.set_propagate(True)

    ############################################################################
    # Existing Project Page Handlers - Custom ISO
    ############################################################################

    def on_clicked__existing_project_page__custom_iso_image_directory_filechooser_open_button(self, widget):

        display.set_sensitive('window', False)

        dialog = model.builder.get_object('existing_project_page__custom_iso_image_directory_filechooser')

        if os.path.exists(model.custom_iso_image_directory):
            dialog.set_current_folder(model.custom_iso_image_directory)
        else:
            dialog.set_current_folder(model.home)

        dialog.show_all()

    def on_changed__existing_project_page__custom_iso_image_version_number_entry(self, widget):

        model.set_custom_iso_image_version_number(widget.get_text())

        if model.propagate:
            custom_iso_image_filename = utilities.create_custom_iso_image_filename(model.original_iso_image_filename, model.custom_iso_image_version_number)
            display.update_entry('existing_project_page__custom_iso_image_filename_entry', custom_iso_image_filename)

            custom_iso_image_volume_id = utilities.create_custom_iso_image_volume_id(model.original_iso_image_volume_id, model.custom_iso_image_version_number)
            display.update_entry('existing_project_page__custom_iso_image_volume_id_entry', custom_iso_image_volume_id)

        validators.validate_existing_project_page_custom()

    def on_changed__existing_project_page__custom_iso_image_filename_entry(self, widget):

        model.set_custom_iso_image_filename(widget.get_text())
        model.set_custom_iso_image_filepath(os.path.join(model.custom_iso_image_directory, model.custom_iso_image_filename))

        model.set_custom_iso_image_md5_filename(utilities.create_custom_iso_image_md5_filename(model.custom_iso_image_filename))
        model.set_custom_iso_image_md5_filepath(os.path.join(model.custom_iso_image_directory, model.custom_iso_image_md5_filename))

        validators.validate_existing_project_page_custom()

    def on_changed__existing_project_page__custom_iso_image_directory_entry(self, widget):

        model.set_custom_iso_image_directory(widget.get_text())

        model.set_custom_iso_image_filepath(os.path.join(model.custom_iso_image_directory, model.custom_iso_image_filename))

        model.set_custom_iso_image_md5_filepath(os.path.join(model.custom_iso_image_directory, model.custom_iso_image_md5_filename))

        validators.validate_existing_project_page_custom()

    def on_changed__existing_project_page__custom_iso_image_volume_id_entry(self, widget):

        model.set_custom_iso_image_volume_id(widget.get_text())

        if model.propagate:
            custom_iso_image_disk_name = utilities.create_custom_iso_image_disk_name(model.custom_iso_image_volume_id, model.custom_iso_image_release_name)
            display.update_entry('existing_project_page__custom_iso_image_disk_name_entry', custom_iso_image_disk_name)

        validators.validate_existing_project_page_custom()

    def on_changed__existing_project_page__custom_iso_image_release_name_entry(self, widget):

        model.set_custom_iso_image_release_name(widget.get_text())

        if model.propagate:
            custom_iso_image_disk_name = utilities.create_custom_iso_image_disk_name(model.custom_iso_image_volume_id, model.custom_iso_image_release_name)
            display.update_entry('existing_project_page__custom_iso_image_disk_name_entry', custom_iso_image_disk_name)

        validators.validate_existing_project_page_custom()

    def on_changed__existing_project_page__custom_iso_image_disk_name_entry(self, widget):

        model.set_custom_iso_image_disk_name(widget.get_text())

        validators.validate_existing_project_page_custom()

    ############################################################################
    # Existing Project Page Filechooser Handlers
    ############################################################################

    def on_delete_event__existing_project_page__original_iso_image_filepath_filechooser(self, widget, event):

        model.builder.add_objects_from_file('cubic.ui', [
            'existing_project_page__original_iso_image_filepath_filechooser'])
        model.builder.connect_signals(self)

        display.set_sensitive('window', True)

    def on_clicked__existing_project_page__original_iso_image_filepath_filechooser_cancel_button(self, widget):

        display.set_visible('existing_project_page__original_iso_image_filepath_filechooser', False)

        display.set_sensitive('window', True)

    def on_clicked__existing_project_page__original_iso_image_filepath_filechooser_select_button(self, widget):

        self.transition_thread = transition.TransitionThread('original_iso_image_filepath_filechooser', 'existing_project_page', self.transition_thread)
        self.transition_thread.start()

    def on_delete_event__existing_project_page__custom_iso_image_directory_filechooser(self, widget, event):

        model.builder.add_objects_from_file('cubic.ui', [
            'existing_project_page__custom_iso_image_directory_filechooser'])
        model.builder.connect_signals(self)

        display.set_sensitive('window', True)

    def on_clicked__existing_project_page__custom_iso_image_directory_filechooser_cancel_button(self, widget):

        display.set_visible('existing_project_page__custom_iso_image_directory_filechooser', False)

        display.set_sensitive('window', True)

    def on_clicked__existing_project_page__custom_iso_image_directory_filechooser_select_button(self, widget):

        dialog = model.builder.get_object('existing_project_page__custom_iso_image_directory_filechooser')
        custom_iso_image_directory = dialog.get_filename()
        # custom_iso_image_directory = dialog.get_current_folder()
        display.update_entry('existing_project_page__custom_iso_image_directory_entry', custom_iso_image_directory)

        display.set_visible('existing_project_page__custom_iso_image_directory_filechooser', False)

        display.set_sensitive('window', True)

    ############################################################################
    # Confirm Delete Page Handlers - Nautilus
    ############################################################################

    def on_clicked__delete_project_page__custom_iso_image_directory_open_button(self, widget):

        # os.startfile(custom_iso_image_directory)
        # subprocess.Popen(['xdg-open', model.custom_iso_image_directory])
        # process = subprocess.Popen(['xdg-open', model.custom_iso_image_directory], preexec_fn=utilities.set_user_and_group(model.user_id, model.group_id))
        # subprocess.call(['xdg-open', model.custom_iso_image_directory])
        # logger.log_data('The user, group for the current process is', 'User %s, Group %s' % (os.getuid(), os.getgid()))
        return

    def on_clicked__delete_project_page__custom_iso_image_md5_directory_open_button(self, widget):

        # os.startfile(custom_iso_image_directory)
        # subprocess.Popen(['xdg-open', model.custom_iso_image_directory])
        # process = subprocess.Popen(['xdg-open', model.custom_iso_image_directory], preexec_fn=utilities.set_user_and_group(model.user_id, model.group_id))
        # subprocess.call(['xdg-open', model.custom_iso_image_directory])
        # logger.log_data('The user, group for the current process is', 'User %s, Group %s' % (os.getuid(), os.getgid()))
        return

    ############################################################################
    # Terminal Page Handlers
    ############################################################################

    def on_child_exited__terminal_page(self, *args):

        # TODO: Implement on_child_exited
        # logger.log_note('WARNING: on_child_exited is not implemented.')
        # create_terminal_thread.enter_terminal_environment()
        pass

    def on_drag_data_received__terminal_page(self, widget, drag_context, x, y, data, info, drag_time):

        logger.log_data('Drag data received for', 'terminal_page')

        # Gtk.SelectionData
        # atom = data.get_data_type()
        # logger.log_data('The data type is', str(atom))
        model.set_uris(data.get_uris())

        # Go to the next page.

        self.transition_thread = transition.TransitionThread(model.page_name, 'copy_files_page')
        self.transition_thread.start()

    def on_button_press_event__terminal_page(self, widget, event):

        if event.type == Gdk.EventType.BUTTON_PRESS and event.button == 3:

            logger.log_data('Mouse button 3 pressed for', 'terminal_page')

            terminal = model.builder.get_object('terminal_page__terminal')
            terminal_has_selection = terminal.get_has_selection()

            clipboard = Gtk.Clipboard.get(Gdk.SELECTION_CLIPBOARD)

            # Menuitem 1
            display.set_sensitive('terminal_page__select_all_menuitem', True)

            # Menuitem 2
            display.set_sensitive('terminal_page__copy_text_menuitem', terminal_has_selection)

            # Menuitem 3
            clipboard_has_text = clipboard.wait_is_text_available()
            display.set_sensitive('terminal_page__paste_text_menuitem', clipboard_has_text and not terminal_has_selection)

            # Menuitem 4
            clipboard_has_uris = clipboard.wait_is_uris_available()
            if clipboard_has_uris and not terminal_has_selection:
                count = len(clipboard.wait_for_uris())
                label = 'Paste File' if count == 1 else 'Paste %s Files' % count
                display.update_menuitem('terminal_page__paste_file_menuitem', label)
                display.set_sensitive('terminal_page__paste_file_menuitem', True)
            else:
                label = 'Paste File(s)'
                display.update_menuitem('terminal_page__paste_file_menuitem', label)
                display.set_sensitive('terminal_page__paste_file_menuitem', False)

            menu = model.builder.get_object('terminal_page__menu')
            menu.popup(None, None, None, None, event.button, event.time)

    ############################################################################
    # Terminal Page Handlers - Popup Menu
    ############################################################################

    def on_button_release_event__terminal_page__select_all_menuitem(self, *args):

        terminal = model.builder.get_object('terminal_page__terminal')
        terminal.select_all()

    def on_button_release_event__terminal_page__copy_text_menuitem(self, *args):

        terminal = model.builder.get_object('terminal_page__terminal')
        terminal.copy_clipboard()

        # https://lazka.github.io/pgi-docs/#Vte-2.90/classes/Terminal.html#methods
        try:
            terminal.unselect_all
        except AttributeError:
            # Vte 2.90 only...
            # Ubuntu 14.04 uses libvte-2.90
            terminal.select_none()
        else:
            # Vte 2.91 only...
            # Ubuntu 15.04 uses libvte-2.91
            terminal.unselect_all()

    def on_button_release_event__terminal_page__paste_text_menuitem(self, *args):

        terminal = model.builder.get_object('terminal_page__terminal')
        terminal.paste_clipboard()

    def on_button_release_event__terminal_page__paste_file_menuitem(self, *args):

        clipboard = Gtk.Clipboard.get(Gdk.SELECTION_CLIPBOARD)
        model.set_uris(clipboard.wait_for_uris())

        # Go to the next page.

        self.transition_thread = transition.TransitionThread(model.page_name, 'copy_files_page')
        self.transition_thread.start()

    ############################################################################
    # Create Filesystem Manifest Page Handlers
    ############################################################################

    def on_toggled__create_manifest_page_checkbutton(self, widget, row):

        liststore = model.builder.get_object('create_manifest_page__package_details_liststore')
        liststore[row][0] = not liststore[row][0]

    ############################################################################
    # Create Filesystem Manifest Page Handlers
    ############################################################################

    def on_toggled__create_filesystem_manifest_page_checkbutton(self, widget, row):

        liststore = model.builder.get_object('create_filesystem_manifest_page__package_details_liststore')
        liststore[row][0] = not liststore[row][0]

    ############################################################################
    # Finish Page Handlers - Nautilus
    ############################################################################

    def on_clicked__finish_page__custom_iso_image_directory_open_button(self, widget):

        # os.startfile(model.custom_iso_image_directory)
        # subprocess.Popen(['xdg-open', model.custom_iso_image_directory])
        # process = subprocess.Popen(['xdg-open', model.custom_iso_image_directory], preexec_fn=utilities.set_user_and_group(model.user_id, model.group_id))
        # subprocess.call(['xdg-open', model.custom_iso_image_directory])
        # logger.log_data('The user, group for the current process is', 'User %s, Group %s' % (os.getuid(), os.getgid()))
        return
