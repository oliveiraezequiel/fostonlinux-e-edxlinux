#!/usr/bin/python3

################################################################################
#                                                                              #
# utilities.py                                                                 #
#                                                                              #
# Copyright (C) 2015 PJ Singh <psingh.cubic@gmail.com>                         #
#                                                                              #
################################################################################

################################################################################
#                                                                              #
# This file is part of Cubic - Custom Ubuntu ISO Creator.                      #
#                                                                              #
# Cubic is free software: you can redistribute it and/or modify                #
# it under the terms of the GNU General Public License as published by         #
# the Free Software Foundation, either version 3 of the License, or            #
# (at your option) any later version.                                          #
#                                                                              #
# Cubic is distributed in the hope that it will be useful,                     #
# but WITHOUT ANY WARRANTY; without even the implied warranty of               #
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                #
# GNU General Public License for more details.                                 #
#                                                                              #
# You should have received a copy of the GNU General Public License            #
# along with Cubic.  If not, see <http://www.gnu.org/licenses/>.               #
#                                                                              #
################################################################################

import display
import logger
import model

import configparser
import datetime
import gi
gi.require_version('Gdk', '3.0')
from gi.repository import Gdk
from gi.repository import Gio
from gi.repository import GLib
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk
from gi.repository import Pango
try:
    gi.require_version('Vte', '2.91')
    logger.log_data('Using Vte version', '2.91')
except ValueError:
    gi.require_version('Vte', '2.90')
    logger.log_data('Using Vte version', '2.90')
from gi.repository.Vte import Terminal, PtyFlags

import glob
import hashlib
import os
import pexpect
import platform
import re
import signal
import stat
import string
import subprocess
from subprocess import Popen, PIPE
import time
import uuid
from urllib.parse import urlparse

time_zone = 'America/New_York'  # cat /etc/timezone


################################################################################
# Execute Functions
################################################################################

# https://pexpect.readthedocs.org/en/stable/api/pexpect.html#spawn-class
# Because spwan() is a byte interface, you must use process.read().decode().
# Because spwanu() is a string interface, so process.read().decode() is not necessary.

def execute_synchronous(thread, command, working_directory=None):
    logger.log_data('Execute synchronously', command)
    process = pexpect.spawnu(command, cwd=working_directory)
    # For Pexpect Pexpect 3.x
    # process = pexpect.spawnu(command, cwd=working_directory)
    # For Pexpect 4.0
    # process = pexpect.spawn(command, cwd=working_directory, encoding='UTF-8')
    thread.set_process(process)
    logger.log_data('The process id is', thread.get_process_id())
    process.expect(pexpect.EOF)


def execute_asynchronous(thread, command, working_directory=None):
    logger.log_data('Execute asynchronously', command)
    process = pexpect.spawnu(command, cwd=working_directory)
    # For Pexpect Pexpect 3.x
    # process = pexpect.spawnu(command, cwd=working_directory)
    # For Pexpect 4.0
    # process = pexpect.spawn(command, cwd=working_directory, encoding='UTF-8')
    thread.set_process(process)
    logger.log_data('The process id is', thread.get_process_id())


def execute_synchronous_popen(thread, command):
    logger.log_data('Execute synchronously (popen)', command)
    process = Popen(command.split(), stdout=PIPE, stderr=PIPE, bufsize=-1, universal_newlines=True)
    thread.set_process(process)
    logger.log_data('The process id is', thread.get_process_id())
    output, error = process.communicate()
    returncode = process.poll()
    if returncode == 0:
        logger.log_data('Success', output)
    else:
        logger.log_data('Error', error)


def execute_synchronous_popen_no_output(thread, command):
    process = Popen(command.split(), stdout=PIPE, stderr=PIPE, bufsize=-1, universal_newlines=True)
    thread.set_process(process)
    output, error = process.communicate()
    returncode = process.poll()

    return returncode, error


################################################################################
# File Functions
################################################################################

def replace_text_in_file(filepath, search_text, replacement_text):
    logger.log_data('Replacing text in file %s.' % filepath)
    logger.log_data('Search text', search_text)
    logger.log_data('Replacement text', replacement_text)

    if os.path.exists(filepath):

        with open(filepath, 'r+') as file:
            file_contents = file.read()
            file_contents = re.sub(search_text, replacement_text, file_contents)
            file.seek(0)
            file.truncate()
            file.write(file_contents)

    else:

        logger.log_data('Does file %s exist?' % filepath, 'No.  Can not replace text.')


def delete_file(thread, filepath):
    logger.log_data('Deleting file %s.' % filepath)

    if os.path.exists(filepath):

        logger.log_data('Does file %s exist?' % filepath, 'Yes.  Delete it.')
        command = 'rm -rf %s' % filepath
        execute_synchronous(thread, command)

    else:

        logger.log_data('Does file %s exist?' % filepath, 'No.  Do nothing.')


def get_directory_size(start_path):
    logger.log_note('Calculating directory size', )
    total_size = 0

    for dirpath, dirnames, filenames in os.walk(start_path):

        for filename in filenames:
            filepath = os.path.join(dirpath, filename)
            total_size += os.path.getsize(filepath)

    return total_size


################################################################################
# Miscelaneous Functions
################################################################################

def set_user_and_group(user_id, group_id):
    logger.log_note('Changing user and group')
    logger.log_data('New user', user_id)
    logger.log_data('New group', group_id)
    os.setgid(group_id)
    os.setuid(user_id)


################################################################################
# Configuration File Functions
################################################################################

# TODO: Make creating the configuration object more efficient by storing it in the model.

def save_configuration():
    logger.log_note('Saving the configuration')

    # Create the configuraton.
    configuration = configparser.ConfigParser()

    # General
    configuration.add_section('General')
    configuration.set('General', 'project_directory', model.project_directory)

    # Original
    configuration.add_section('Original')
    # configuration.set('Original', 'original_iso_image_filepath', model.original_iso_image_filepath)
    configuration.set('Original', 'original_iso_image_filename', model.original_iso_image_filename)
    configuration.set('Original', 'original_iso_image_directory', model.original_iso_image_directory)
    configuration.set('Original', 'original_iso_image_volume_id', model.original_iso_image_volume_id)
    configuration.set('Original', 'original_iso_image_release_name', model.original_iso_image_release_name)
    configuration.set('Original', 'original_iso_image_disk_name', model.original_iso_image_disk_name)

    # Custom
    configuration.add_section('Custom')
    configuration.set('Custom', 'custom_iso_image_version_number', model.custom_iso_image_version_number)
    # configuration.set('Custom', 'custom_iso_image_filepath', model.custom_iso_image_filepath)
    configuration.set('Custom', 'custom_iso_image_filename', model.custom_iso_image_filename)
    configuration.set('Custom', 'custom_iso_image_directory', model.custom_iso_image_directory)
    configuration.set('Custom', 'custom_iso_image_volume_id', model.custom_iso_image_volume_id)
    configuration.set('Custom', 'custom_iso_image_release_name', model.custom_iso_image_release_name)
    configuration.set('Custom', 'custom_iso_image_disk_name', model.custom_iso_image_disk_name)
    configuration.set('Custom', 'custom_iso_image_md5_filename', model.custom_iso_image_md5_filename)

    # Status
    configuration.add_section('Status')
    configuration.set('Status', 'is_success_copy_original_iso_files', str(model.is_success_copy_original_iso_files))
    configuration.set('Status', 'is_success_extract_squashfs', str(model.is_success_extract_squashfs))

    # Write the configuration file.
    with open(model.configuration_filepath, 'w') as configuration_file:
        configuration.write(configuration_file)

    os.chown(model.configuration_filepath, model.user_id, model.group_id)

    # Alternate syntax...
    # configuration_file = open(model.configuration_filepath, 'w')
    # with configuration_file: configuration.write(configuration_file)


# def get_configuration_value(section, key):
#     # Create the configuration.
#     configuration = configparser.ConfigParser()
#     # Read the configuration.
#     configuration.read(model.configuration_filepath)
#     return configuration.get(section, key)

def save_configuration_value(section, key, value):
    # Create the configuration.
    configuration = configparser.ConfigParser()

    # Set the section, key, and value.
    configuration.add_section(section)
    configuration.set(section, key, value)

    # Write the configuration file.
    with open(model.configuration_filepath, 'w') as configuration_file:
        configuration.write(configuration_file)


################################################################################
# ISO Mount Functions
################################################################################

def is_mounted(iso_image_filepath, iso_image_mount_point):
    mount_information = subprocess.check_output('mount').decode()
    match = bool(re.search(r'%s\s*on\s*%s' % (iso_image_filepath, iso_image_mount_point), mount_information))
    logger.log_data('Is mounted?', match)
    logger.log_data('ISO image', iso_image_filepath)
    logger.log_data('Mount point', iso_image_mount_point)

    return bool(match)


def mount_iso_image(thread, iso_image_filepath, iso_image_mount_point):
    logger.log_note('Mount the iso image')
    logger.log_data('ISO image', iso_image_filepath)
    logger.log_data('Mount point', iso_image_mount_point)

    if os.path.exists(iso_image_mount_point):
        # Unmount existing mount point, just in case it is already mounted.
        logger.log_data('Unmount existing mount point if it is mounted', iso_image_mount_point)
        command = 'umount %s' % iso_image_mount_point
        execute_synchronous(thread, command)
    else:
        # Create the mount point if it does not exist.
        logger.log_data('Create the mount point if it does not exist', iso_image_mount_point)
        command = 'mkdir %s' % iso_image_mount_point
        execute_synchronous(thread, command)

    if os.path.exists(iso_image_filepath):
        # Only mount the filepath if it exists.
        logger.log_data('Mount', iso_image_filepath)
        command = 'mount -o loop %s %s' % (iso_image_filepath, iso_image_mount_point)
        execute_synchronous(thread, command)


def delete_iso_mount(thread, iso_image_mount_point):
    logger.log_note('Deleting ISO image mount point %s' % iso_image_mount_point)

    if os.path.exists(iso_image_mount_point):

        # Unmount existing mount point, just in case it is already mounted.

        logger.log_data('Unmount if it is mounted', iso_image_mount_point)
        command = 'umount %s' % iso_image_mount_point
        execute_synchronous(thread, command)
        time.sleep(1.00)

        # Delete the mount point.
        logger.log_data('Delete mount point', iso_image_mount_point)
        command = 'rm -rf %s' % iso_image_mount_point
        execute_synchronous(thread, command)
        time.sleep(1.00)

    else:

        logger.log_data('The mount point does not exist.', 'Do nothing.')


############################################################################
# Get Iso Image Information
############################################################################

def get_iso_image_volume_id(iso_image_filepath):
    # Get the original iso image volume id.
    iso_info = subprocess.check_output(['isoinfo', '-d', '-i', iso_image_filepath]).decode()
    iso_image_volume_id = re.sub(r'.*Volume id:\s+(.*[^\n]).*Volume\s+set\s+id.*', r'\1', iso_info, 0, re.DOTALL)

    return iso_image_volume_id


def get_iso_image_release_name(iso_image_mount_point):
    try:
        # Read the original iso image README.diskdefines file.
        readme_diskdefines = subprocess.check_output(['cat', os.path.join(iso_image_mount_point, 'README.diskdefines')]).decode()
        # Get the original iso image release name.
        iso_image_release_name = re.search(r'DISKNAME.*"(.*)"', readme_diskdefines).group(1)
    except Exception as exception:
        logger.log_data('Ignoring exception %s while reading iso image release name from README.diskdefines', exception)
        iso_image_release_name = 'Unknown release name'

    return iso_image_release_name


def get_iso_image_disk_name(iso_image_mount_point):
    try:
        # Read the original iso image README.diskdefines file.
        readme_diskdefines = subprocess.check_output(['cat', os.path.join(iso_image_mount_point, 'README.diskdefines')]).decode()
        # Get the original iso image disk name.
        iso_image_disk_name = re.search(r'DISKNAME *(.*)', readme_diskdefines).group(1)
    except Exception as exception:
        logger.log_data('Ignoring exception %s while reading iso image disk name from README.diskdefines', exception)
        iso_image_disk_name = 'Unknown disk name'

    return iso_image_disk_name


############################################################################
# Creators
############################################################################

def create_custom_iso_image_version_number():
    return datetime.datetime.now().strftime('%Y.%m.%d')


def create_configuration_filepath(project_directory):
    return os.path.join(project_directory, 'cubic.conf')


def create_original_iso_image_mount_point(project_directory):
    return os.path.join(project_directory, 'original-iso-mount')


def create_custom_squashfs_directory(project_directory):
    return os.path.join(project_directory, 'squashfs-root')


def create_custom_live_iso_directory(project_directory):
    return os.path.join(project_directory, 'custom-live-iso')


def create_custom_iso_image_filename(original_iso_image_filename, custom_iso_image_version_number):
    # TODO: Account for .iso at the end.

    logger.log_note('Creating custom iso image filename')

    try:

        match = None
        distribution_and_release = None
        point_release = None
        architecture = None

        logger.log_data('Original iso image filename: match', match)
        logger.log_data('Original iso image filename: distribution and release', distribution_and_release)
        logger.log_data('Original iso image filename: point release', point_release)
        logger.log_data('Original iso image filename: architecture', architecture)

        # This regular expression matches three parts of the file name:
        # For example, ubuntu-13.04.7-2015-09-01-server-powerpc.iso will match
        # (1) ubuntu-13.04, (2) 7, and (3) server-powerpc

        match = re.search(r'^(\S+?-\d{2}.\d{2})(?:\.(\d)){0,2}(?:-\d{4}\.\d{2}\.\d{2}){0,1}.*-(\S+-\S+)\.iso$', original_iso_image_filename)
        logger.log_data('Original iso image filename: match', match.group(0))

        distribution_and_release = match.group(1)
        logger.log_data('Original iso image filename: distribution and release', distribution_and_release)

        point_release = match.group(2)
        logger.log_data('Original iso image filename: point release', point_release)

        architecture = match.group(3)
        logger.log_data('Original iso image filename: architecture', architecture)

        if point_release is None: point_release = '0'
        if custom_iso_image_version_number:
            custom_iso_image_filename = '%s.%s-%s-%s.iso' % (distribution_and_release, point_release, custom_iso_image_version_number, architecture)
        else:
            custom_iso_image_filename = '%s.%s-%s.iso' % (distribution_and_release, point_release, architecture)

    except Exception as exception:

        logger.log_data('Encountered exception while creating custom iso image filename', exception)
        custom_iso_image_filename = ''

    logger.log_data('The created custom iso image filename is', custom_iso_image_filename)
    return custom_iso_image_filename


def create_custom_iso_image_volume_id(original_iso_image_volume_id, custom_iso_image_version_number):
    logger.log_note('Creating custom iso image volume id')

    try:

        # TODO: Delete this old code.
        # This regular expression matches three parts of the volume id:
        # For example, Ubuntu 15.04.7 amd64 will match
        # (1) Ubuntu 15.04, (2) 7, and (3) amd64
        # match = re.search(r'^(\S+?\s*\d{2}.\d{2})(?:\.(\d)){0,1}(?:\s*\d{4}\.\d{2}\.\d{2}){0,1}\s*(\S+)$', original_iso_image_volume_id)

        match = None
        distribution = None
        release = None
        version = None
        architecture = None

        logger.log_data('Original iso image volume id: match', match)
        logger.log_data('Original iso image volume id: distribution', distribution)
        logger.log_data('Original iso image volume id: release', release)
        logger.log_data('Original iso image volume id: version (not used)', version)
        logger.log_data('Original iso image volume id: architecture', architecture)

        # This regular expression matches a volume id with three or four parts:
        # For example, 'Ubuntu 14.04.1 LTS amd64' will match
        #     (1) Ubuntu, (2) 14.04.1, (3) LTS, and (4) amd64
        # For example, 'Ubuntu 15.04 amd64' will match
        #     (1) Ubuntu, (2) 15.04, (3) None, and (4) amd64
        # For example, 'Ubuntu 15.04.0 2016.02.28 amd64' will match
        #     (1) Ubuntu, (2) 15.04.0, (3) 2016.02.28, and (4) amd64

        match = re.search(r'^(\S+)\s+(\S+)(?:\s+(\S+)){0,1}\s+(\S+)$', original_iso_image_volume_id)
        logger.log_data('Original iso image volume id: match', match.group(0))

        distribution = match.group(1)
        logger.log_data('Original iso image volume id: distribution', distribution)

        release = match.group(2)
        logger.log_data('Original iso image volume id: release', release)

        version = match.group(3)  # Not used.
        logger.log_data('Original iso image volume id: version (not used)', version)

        architecture = match.group(4)
        logger.log_data('Original iso image volume id: architecture', architecture)

        # This regular expression matches a release with two or three parts:
        # For example, '14.04.1' will match
        #     (1) 14, (2) 04, and (3) 1
        # For example, '14.04.15' will match
        #     (1) 14, (2) 04, and (3) 15
        # For example, '15.10' will match
        #     (1) 15, (2) 10, and (3) None

        match = re.search(r'^(\d{2})\.(\d{2})(?:\.(\d{1,2})){0,1}$', release)
        logger.log_data('Original iso image volume id release: match', match.group(0))

        major_release = match.group(1)
        logger.log_data('Original iso image volume id release: major release', major_release)

        minor_release = match.group(2)
        logger.log_data('Original iso image volume id release: minor release', minor_release)

        point_release = match.group(3)
        logger.log_data('Original iso image volume id release: point release', point_release)

        if point_release is None: point_release = '0'
        if custom_iso_image_version_number:
            custom_iso_image_volume_id = '%s %s.%s.%s %s %s' % (distribution, major_release, minor_release, point_release, custom_iso_image_version_number, architecture)
        else:
            custom_iso_image_volume_id = '%s %s.%s.%s %s' % (distribution, major_release, minor_release, point_release, architecture)

    except Exception as exception:

        logger.log_data('Encountered exception %s while creating custom iso image volume id', exception)
        custom_iso_image_volume_id = ''

    logger.log_data('The created custom iso image volume id is', custom_iso_image_volume_id)
    return custom_iso_image_volume_id


def create_custom_iso_image_release_name(original_iso_image_release_name):
    logger.log_note('Creating custom iso image release name')

    try:
        custom_iso_image_release_name = 'Custom %s' % re.sub(r'^Custom\s*', '', original_iso_image_release_name)
    except Exception as exception:
        logger.log_data('Encountered exception %s while creating custom iso image release name', exception)
        custom_iso_image_release_name = ''

    logger.log_data('The created custom iso image release name is', custom_iso_image_release_name)
    return custom_iso_image_release_name


def create_custom_iso_image_disk_name(custom_iso_image_volume_id, custom_iso_image_release_name):
    logger.log_note('Creating custom iso image disk name')

    if custom_iso_image_volume_id and custom_iso_image_release_name:
        custom_iso_image_disk_name = '%s "%s"' % (custom_iso_image_volume_id, custom_iso_image_release_name)
    elif custom_iso_image_volume_id:
        custom_iso_image_disk_name = custom_iso_image_volume_id
    elif custom_iso_image_release_name:
        custom_iso_image_disk_name = custom_iso_image_release_name
    else:
        custom_iso_image_disk_name = ''

    logger.log_data('The created custom iso image disk name is', custom_iso_image_disk_name)
    return custom_iso_image_disk_name


def create_custom_iso_image_md5_filename(custom_iso_image_filename):
    logger.log_note('Creating custom iso image md5 filename')

    try:
        custom_iso_image_md5_filename = re.sub(r'\.iso$|\.$|$', '.md5', custom_iso_image_filename)
    except Exception as exception:
        logger.log_data('Encountered exception %s while creating custom iso image md5 filename', exception)
        custom_iso_image_md5_filename = 'custom.md5'

    # logger.log_data('The created custom iso image md5 filename is', custom_iso_image_md5_filename)
    return custom_iso_image_md5_filename


################################################################################
# Copy Files Functions
################################################################################

def create_file_details_list():
    logger.log_note('Listing files to copy')

    file_details_list = []

    for file_number, uri in enumerate(model.uris):
        filepath = urlparse(uri).path
        file_details_list.append([0, filepath])

    return file_details_list


def copy_files(thread):
    logger.log_note('Copying files')

    # Vte 2.90 or Vte 2.91..
    current_directory = os.readlink('/proc/%i/cwd' % model.terminal_pid)

    # Vte 2.91 only...
    # (Note: on libvte-2.90, this returns the Computer Name and directory, so it does not work).
    # terminal = model.builder.get_object("terminal_page_terminal")
    # current_directory_uri = terminal.get_current_directory_uri()
    # current_directory = urlparse(current_directory_uri).path

    total_files = len(model.uris)

    for file_number, uri in enumerate(model.uris):

        filepath = urlparse(uri).path

        relative_directory = os.path.join('/', os.path.relpath(current_directory, model.custom_squashfs_directory))
        if total_files == 1:
            label = 'Copying one file to %s' % relative_directory
        else:
            label = 'Copying file %s of %s to %s' % (file_number + 1, total_files, relative_directory)
        display.update_label('copy_files_page__progress_label', label)
        # display.select_listbox_row('copy_files_page__files_listbox', file_number)

        copy_file(thread, filepath, file_number, current_directory, total_files)

        time.sleep(0.25)


def copy_file(thread, filepath, file_number, target_directory, total_files):
    logger.log_data('Copying file number', '%s of %s' % (file_number, total_files))
    logger.log_data('The file is', filepath)
    logger.log_data('The target directory is', target_directory)

    # rsync --archive --progress "/home/psingh/test_folder_1 (copy)/squashfs-root" "/home/psingh/test_folder_1/squashfs-root/root/temp"
    # rsync --archive --info=progress2 "/home/psingh/test_folder_1 (copy)/squashfs-root" "/home/psingh/test_folder_1/squashfs-root/root/temp"
    # sudo gcp -rf "/home/psingh/test_folder_1 (copy)/squashfs-root" "/home/psingh/test_folder_1/squashfs-root/root/temp"
    # sudo curl -o "/home/psingh/test_folder_1/squashfs-root/root/temp" "file://home/psingh/test_folder_1 (copy)/squashfs-root"

    # command = 'rsync --archive --progress "%s" "%s"' % (filepath, target_directory)
    # command = 'gcp -rf "%s" "%s"' % (filepath, target_directory)
    command = 'rsync --archive --info=progress2 "%s" "%s"' % (filepath, target_directory)

    execute_asynchronous(thread, command)

    progress_initial_global = int(round(100 * file_number / total_files, 0))
    # progress_target  = int(round(progress_initial + 100/total_files))
    # progress_display_global = progress_initial_global - 1
    # progress_current = progress_initial

    progress_initial = 0
    progress_target = 100
    progress_display = progress_initial - 1
    progress_current = progress_initial

    logger.log_data('The progress is', '%s%% of %s%%' % (progress_current, progress_target))

    while (thread.process.exitstatus is None) or (progress_display < progress_target and thread.process.exitstatus == 0):

        try:
            line = thread.process.read_nonblocking(100, 0.05)
            result = re.search(r'([0-9]{1,3})%', str(line))
            if result:
                progress_current = progress_initial + int(result.group(1))
                # progress_current_global = round(progress_initial_global + progress_current/total_files, 0)
        except pexpect.TIMEOUT:
            pass
        except pexpect.EOF:
            if progress_current < progress_target: progress_current = progress_target
            time.sleep(0.01)

        if progress_current > progress_display:
            progress_display += 1
            if progress_display == 0:
                display.update_progressbar_text('copy_files_page__copy_files_progressbar', None)
                display.update_liststore_progressbar_percent('copy_files_page__file_details_liststore', file_number, 0)
            display.update_progressbar_percent('copy_files_page__copy_files_progressbar', progress_initial_global + progress_display / total_files)
            display.update_liststore_progressbar_percent('copy_files_page__file_details_liststore', file_number, progress_display)

    time.sleep(0.01)


################################################################################
# Enter Chroot Environment Functions
################################################################################

def copy_original_iso_files(thread, is_new_project):
    logger.log_note('Copying the original iso files')

    source_path = os.path.join(model.original_iso_image_mount_point, '')
    logger.log_data('The source path is', source_path)

    target_path = os.path.join(model.custom_live_iso_directory, '')
    logger.log_data('The target path is', target_path)

    if is_new_project:
        # Copy all files from the original iso.
        # Exclude or copy the following files as indicated.
        # Do not copy: /md5sum.txt
        # Do not copy: /casper/filesystem.manifest
        # ****** Copy: /casper/filesystem.manifest-remove
        # Do not copy: /casper/filesystem.size
        # Do not copy: /casper/filesystem.squashfs
        # Do not copy: /casper/filesystem.squashfs.gpg
        # Do not copy: /casper/initrd.lz
        # Do not copy: /casper/vmlinuz.efi

        # command = 'rsync --delete --archive --exclude=md5sum.txt --exclude=/casper/filesystem.manifest --exclude=/casper/filesystem.size --exclude=/casper/filesystem.squashfs --progress "%s" "%s"' % (source_path, target_path)
        command = 'rsync --delete --archive --exclude=md5sum.txt --include=/casper/filesystem.manifest-remove --exclude=/casper/* --progress "%s" "%s"' % (source_path, target_path)
    else:
        # Copy all files from the original iso.
        # Exclude or copy the following files as indicated.
        # Do not copy: /md5sum.txt
        # Do not copy: /casper/filesystem.manifest
        # Do not copy: /casper/filesystem.manifest-remove
        # Do not copy: /casper/filesystem.size
        # Do not copy: /casper/filesystem.squashfs
        # Do not copy: /casper/filesystem.squashfs.gpg
        # Do not copy: /casper/initrd.lz
        # Do not copy: /casper/vmlinuz.efi

        # command = 'rsync --delete --archive --exclude=md5sum.txt --exclude=/casper/filesystem.manifest --exclude=/casper/filesystem.manifest-remove --exclude=/casper/filesystem.size --exclude=/casper/filesystem.squashfs --progress "%s" "%s"' % (source_path, target_path)
        command = 'rsync --delete --archive --exclude=md5sum.txt --exclude=/casper/* --progress "%s" "%s"' % (source_path, target_path)
    execute_asynchronous(thread, command)

    progress_initial = 0
    progress_target = 100
    progress_display = progress_initial - 1
    progress_current = progress_initial

    while (thread.process.exitstatus is None) or (progress_display < progress_target and thread.process.exitstatus == 0):

        try:
            line = thread.process.read_nonblocking(100, 0.05)
            result = re.search(r'([0-9]{1,3})%', str(line))
            if result: progress_current = progress_initial + int(result.group(1))
        except pexpect.TIMEOUT:
            pass
        except pexpect.EOF:
            if progress_current < progress_target: progress_current = progress_target
            time.sleep(0.05)

        if progress_current > progress_display:
            progress_display += 1
            if progress_display == 0:
                display.update_progressbar_text('unsquashfs_page__copy_original_iso_files_progressbar', None)
            display.update_progressbar_percent('unsquashfs_page__copy_original_iso_files_progressbar', progress_display)

    time.sleep(0.10)


def extract_squashfs(thread):
    # Delete custom squashfs directory, if it exists.
    delete_file(thread, model.custom_squashfs_directory)

    logger.log_note('Extracting squashfs')

    target_path = model.custom_squashfs_directory
    logger.log_data('The target path is', target_path)

    source_path = os.path.join(model.original_iso_image_mount_point, 'casper', 'filesystem.squashfs')
    logger.log_data('The source path is', source_path)

    command = 'unsquashfs -force -dest %s %s' % (target_path, source_path)
    execute_asynchronous(thread, command)

    progress_initial = 0
    progress_target = 100
    progress_display = progress_initial - 1
    progress_current = progress_initial

    while (thread.process.exitstatus is None) or (progress_display < progress_target and thread.process.exitstatus == 0):
        try:
            line = thread.process.read_nonblocking(100, 0.05)
            result = re.search(r'([0-9]{1,3})%', str(line))
            if result: progress_current = progress_initial + int(result.group(1))
        except pexpect.TIMEOUT:
            pass
        except pexpect.EOF:
            if progress_current < progress_target:
                progress_current = progress_target
            time.sleep(0.05)

        if progress_current > progress_display:
            progress_display += 1
            if progress_display == 0:
                display.update_progressbar_text('unsquashfs_page__unsquashfs_progressbar', None)
            display.update_progressbar_percent('unsquashfs_page__unsquashfs_progressbar', progress_display)
            # logger.log_data('The progress is', '%s%% display, %s%% current' % (progress_display, progress_current))

    time.sleep(0.10)


def prepare_chroot_environment(thread):
    logger.log_note('Preparing the chroot environment')

    # command = 'xhost +local:'
    command = 'xhost +'
    execute_synchronous(thread, command)

    command = 'mount --bind /dev %s' % os.path.join(model.custom_squashfs_directory, 'dev')
    execute_synchronous(thread, command)

    command = 'mount --bind /run %s' % os.path.join(model.custom_squashfs_directory, 'run')
    execute_synchronous(thread, command)


def terminal_setup_function(thread, *args):
    # logger.log_note('Executing the terminal setup function')

    os.chroot(model.custom_squashfs_directory)

    command = 'mount -t proc none /proc'
    returncode, error = execute_synchronous_popen_no_output(thread, command)
    if returncode != 0: logger.log_data('Error mounting /proc:\n%s', error)

    command = 'mount -t sysfs none /sys'
    returncode, error = execute_synchronous_popen_no_output(thread, command)
    if returncode != 0: logger.log_data('Error mounting /sys:\n%s', error)

    # TODO: Confirm the mode and gid below are useful.
    # command = 'mount -t devpts none /dev/pts'
    # Exception pty.fork() failed: out of pty devices.
    # Try mode=620,gid=5 to remedy out of pty devices exception.
    # https://bugzilla.redhat.com/show_bug.cgi?id=510183
    # You should also probably use the newinstance devpts mount option to avoid any tampering with the host system
    command = 'mount -t devpts none /dev/pts'
    # command = 'mount -t devpts -o mode=620,gid=5 none /dev/pts'
    # command = 'mount -t devpts -o                 ,gid=5,mode=620 none /dev/pts'
    # command = 'mount -t devpts -o rw,noexec,nosuid,gid=5,mode=620 none /dev/pts'
    # command = 'mount -t devpts none /dev/pts'
    returncode, error = execute_synchronous_popen_no_output(thread, command)
    if returncode != 0: logger.log_data('Error mounting /dev/pts:\n%s', error)

    # machine_id = model.get_machine_id()
    machine_id = str(uuid.uuid4()).replace('-', '')
    filepath = '/var/lib/dbus/machine-id'
    with open(filepath, 'w') as file:
        file.write('%s' % machine_id)
    # logger.log_data('The new machine id is %s' % machine_id)

    command = 'dpkg-divert --local --rename --add /sbin/initctl'
    returncode, error = execute_synchronous_popen_no_output(thread, command)
    if returncode != 0:  logger.log_data('Error diverting /sbin/initctl:\n%s', error)

    # https://help.ubuntu.com/community/BasicChroot
    # command = ["export DISPLAY=:0.0"]
    # process = Popen(command, stdout=PIPE, stderr=PIPE, bufsize=1, universal_newlines=True)
    # returncode = process.wait()
    # if (returncode == 0):
    #     logger.log_note('Successfully exported the display')
    # else:
    #     logger.log_note('There was an error exporting the display')

# Vte Terminal Information
# https://lazka.github.io/pgi-docs/#Vte-2.91/classes/Terminal.html

def enter_chroot_environment(thread):
    logger.log_note('Entering the chroot environment')
    logger.log_data('The chroot environment directory is', model.custom_squashfs_directory)

    terminal = model.builder.get_object('terminal_page__terminal')
    terminal.reset(True, False)
    settings = Gio.Settings('org.gnome.desktop.interface')
    font_name = settings.get_string('monospace-font-name')
    font = Pango.FontDescription(font_name)
    terminal.set_font(font)
    # terminal.set_scrollback_lines(-1)

    flags = Gtk.DestDefaults.MOTION | Gtk.DestDefaults.HIGHLIGHT | Gtk.DestDefaults.DROP
    # TODO: Change: Gtk.TargetFlags
    #       See: https://lazka.github.io/pgi-docs/Gtk-3.0/structs/TargetEntry.html#methods
    targets = [Gtk.TargetEntry.new('text/uri-list', 0, 80), Gtk.TargetEntry.new('text/plain', 0, 80)]
    actions = Gdk.DragAction.COPY
    terminal.drag_dest_set(flags, targets, actions)

    pty_flags = PtyFlags.DEFAULT
    working_directory = os.path.join(model.custom_squashfs_directory, 'root')
    terminal_argument_vector = ['/bin/bash', '--login']
    # environment_variables = ['HOME=/root', 'LC_ALL=C', 'DISPLAY=%s' % (os.environ['DISPLAY']), 'TZ=%s' % time_zone]
    # LC_ALL - environment variable overrides all the other localisation
    #          settings, and forces default language for output. The C locale is
    #          a special locale that.  It uses ASCII and is meant to be the
    #          simplest local.  This is incompatible with most locales that can
    #          can take up from 1 to 6 bytes and require UTF-8.
    #          http://unix.stackexchange.com/questions/87745/what-does-lc-all-c-do
    #          This causes the error, "UnicodeDecodeError: 'ascii' codec can't
    #          decode byte ... ordinal not in range(128)" when a script run in
    #          the chroot environment requires UTF8 characters.
    #          http://stackoverflow.com/questions/9644099/python-ascii-codec-cant-decode-byte
    environment_variables = ['HOME=/root', 'DISPLAY=%s' % (os.environ['DISPLAY']), 'TZ=%s' % time_zone]
    # spawn_flags = GLib.SpawnFlags.DO_NOT_REAP_CHILD
    spawn_flags = GLib.SpawnFlags.DEFAULT
    terminal_setup_data = thread

    # https://lazka.github.io/pgi-docs/#Vte-2.90/classes/Terminal.html#methods

    try:

        terminal.spawn_sync

    except AttributeError:

        # Ubuntu 14.04 uses libvte-2.90
        # For Vte 2.90 use fork_command_full()...
        # terminal_pid = int(terminal.fork_command_full(pty_flags, logger.log_data('Creating a terminal widget using function', 'fork_command_full(); libvte-2.90+; Ubuntu 14.04+')
        terminal_pid = int(terminal.fork_command_full(pty_flags, working_directory, terminal_argument_vector, environment_variables, spawn_flags, terminal_setup_function, terminal_setup_data)[1])
        model.set_terminal_pid(terminal_pid)

        # Clear the terminal.
        # Work-around for Bug #1550003
        # In Ubuntu 14.04, the first few lines of text in in the Terminal are not visible.
        terminal.feed_child('clear\n', -1)

    else:

        # Ubuntu 15.04 uses libvte-2.91
        # For Vte 2.91 use spawn_sync()...
        # terminal_pid = int(terminal.spawn_sync(pty_flags, logger.log_data('Creating a terminal widget using function', 'spawn_sync(); libvte-2.91+; Ubuntu 15.04+')
        terminal_pid = int(terminal.spawn_sync(pty_flags, working_directory, terminal_argument_vector, environment_variables, spawn_flags, terminal_setup_function, terminal_setup_data)[1])
        model.set_terminal_pid(terminal_pid)

        # Clear the terminal.
        # Work-around for Bug in Ubuntu 15.04+, where the bottom of the terminal appears shaded.
        terminal.feed_child('clear\n', -1)

def check_chroot_environment(thread):
    logger.log_note('Checking the chroot environment')

    terminal = model.builder.get_object('terminal_page__terminal')

    # If not in chroot, exit the terminal. Once the terminal exits, the function
    # handler.on_child_exited__terminal_page() will be invoked.
    # For testing only:
    # terminal.feed_child('if [ "$(id -u)" != 0 ] && [ "$(stat -c %d:%i /)" != "$(stat -c %d:%i /proc/1/root/.)" ]; then clear; echo "\n$(tput bold)$(tput setaf 2)You are in the chroot environment.$(tput sgr0)\n"; else clear; echo "\n$(tput bold)$(tput setaf 1)WARNING! You are in NOT the chroot environment. Exiting.$(tput sgr0)\n"; exit; fi\n', -1)
    terminal.feed_child('if [ "$(id -u)" == 0 ] && [ "$(stat -c %d:%i /)" != "$(stat -c %d:%i /proc/1/root/.)" ]; then clear; echo "\n$(tput bold)$(tput setaf 2)You are in the chroot environment.$(tput sgr0)\n"; else clear; echo "\n$(tput bold)$(tput setaf 1)WARNING! You are in NOT the chroot environment. Exiting.$(tput sgr0)\n"; exit; fi\n', -1)


################################################################################
# Exit Chroot Environment Functions
################################################################################

def get_processes_using_directory(directory):
    logger.log_data('Gett processes that are using directory', directory)

    pids = []
    symlinks = glob.glob('/proc/*/root')
    for symlink in symlinks:
        try:
            target = os.readlink(symlink)
            if directory in target:
                pid = int(re.search(r'.*/(\d*)/.*', symlink).group(1))
                pids.append(pid)
        except FileNotFoundError as exception:
            pass

    if pids:
        logger.log_data('%i processes were found that are using directory' % len(pids), directory)
        logger.log_data('%s' % pids)
        # for index, pid in enumerate(pids):
        #     logger.log_data('% 2i. %s' % (index+1, pid))
    else:
        logger.log_data('No processes were found that are using directory', directory)

    return pids


def kill_processes(pids, exclude_pid=None):
    while pids:
        pid = pids.pop()
        if pid != exclude_pid:
            logger.log_data('Killing chroot process with pid', pid)
            os.kill(pid, signal.SIGKILL)
        else:
            logger.log_data('Not killing excluded chroot process with pid', pid)


def get_mount_points_in_directory(directory):
    logger.log_data('Get mount points in directory', directory)

    mount_points = None

    try:
        command = ('grep %s /proc/mounts' % directory)
        logger.log_data('Execute synchronously', command)
        result = subprocess.check_output(command.split()).decode()
        mount_points = re.findall(r'\s(/\S*)\s', result)
    except subprocess.CalledProcessError as exception:
        pass

    if mount_points:
        logger.log_data('%i mount points were found in directory' % len(mount_points), directory)
        for index, mount_point in enumerate(mount_points):
            logger.log_data('Mount point % 2i' % (index + 1), mount_point)
    else:
        logger.log_data('No mount points were found in directory', directory)

    return mount_points


def unmount_mount_points(mount_points):
    while mount_points:
        mount_point = mount_points.pop()
        try:
            logger.log_data('Unmounting the mount point ', mount_point)
            command = 'umount %s' % mount_point
            logger.log_data('Execute synchronously', command)
            subprocess.check_call(command.split())
        except subprocess.CalledProcessError as exception:
            logger.log_data('Error unmounting', mount_point)


def exit_chroot_environment(thread):
    # http://askubuntu.com/questions/162319/how-do-i-stop-all-processes-in-a-chroot

    logger.log_note('Exiting the chroot environment')

    terminal = model.builder.get_object('terminal_page__terminal')

    # Disable input to the terminal while we exit.
    # terminal.set_input_enabled(False)
    # display.set_sensitive(terminal, False)

    # Remove file /sbin/initctl and remove initctl diversion.
    terminal.feed_child('rm -f /sbin/initctl\n', -1)
    terminal.feed_child('dpkg-divert --rename --remove /sbin/initctl\n', -1)

    # Exit the terminal.
    terminal.feed_child('exit\n', -1)

    #
    # Attempt to remove all chroot mounts.
    #

    # Attempt 1
    chroot_mount_points = get_mount_points_in_directory(model.custom_squashfs_directory)
    if chroot_mount_points: unmount_mount_points(chroot_mount_points)

    # Attempt 2
    chroot_mount_points = get_mount_points_in_directory(model.custom_squashfs_directory)
    if chroot_mount_points: unmount_mount_points(chroot_mount_points)

    #
    # Attempt to kill remaining processes and remove rmaining chroot mounts.
    #

    # Attempt 1
    chroot_processes = get_processes_using_directory(model.custom_squashfs_directory)
    if chroot_processes: kill_processes(chroot_processes, model.terminal_pid)
    chroot_mount_points = get_mount_points_in_directory(model.custom_squashfs_directory)
    if chroot_mount_points: unmount_mount_points(chroot_mount_points)

    # Attempt 2
    chroot_processes = get_processes_using_directory(model.custom_squashfs_directory)
    if chroot_processes: kill_processes(chroot_processes, model.terminal_pid)
    chroot_mount_points = get_mount_points_in_directory(model.custom_squashfs_directory)
    if chroot_mount_points: unmount_mount_points(chroot_mount_points)

    #
    # Check if all chroot processes were killed.
    #
    chroot_processes = get_processes_using_directory(model.custom_squashfs_directory)
    if chroot_processes:
        logger.log_note('Error killing all chroot processes')
        for index, process in enumerate(chroot_processes):
            logger.log_data('Process % 2i.' % (index + 1), process)

    #
    # Check if all chroot mount points were unmounted.
    #
    chroot_mount_points = get_mount_points_in_directory(model.custom_squashfs_directory)
    if chroot_mount_points:
        logger.log_data('Error unmounting all chroot mount points ')
        for index, mount_point in enumerate(chroot_mount_points):
            logger.log_data('Mount point % 2i' % (index + 1), mount_point)

    # Remove file /var/lib/dbus/machine-id.
    command = 'rm -f %s' % os.path.join(model.custom_squashfs_directory, 'var', 'lib', 'dbus', 'machine-id')
    execute_synchronous(thread, command)

    # Turns off acccess control (all remote hosts will have access to X server).
    # Turns access control back on (all remote hosts will not have access to X server).
    command = 'xhost -local:'
    execute_synchronous(thread, command)


################################################################################
# Manage Linux Kernels Functions
################################################################################

def get_current_kernel_version_name():
    version_name = None
    try:
        version_information = re.search(r'(\d+\.\d+\.\d+(?:-\d+))', platform.release())
        version_name = version_information.group(1)
    except AttributeError as exception:
        pass
    return version_name

def get_current_kernel_release_name():
    return platform.release()

def create_vmlinuz_version_details_list(*directories):
    version_details_list = []
    for directory in directories:
        version_details_list.extend(get_vmlinuz_versions_list_from_directory(directory))
    version_details_list.sort()

    current_kernel_release_name = get_current_kernel_release_name()
    current_kernel_version_name = get_current_kernel_version_name()

    selected_index = len(version_details_list) -1
    priority = 0
    for index, version_details in enumerate(version_details_list):
        # Remove the 1st column because it is a tuple and can not be rendered.
        version_details.pop(0)

        # The resulting version_details is:
        # 0:version_name, 1:vmlinuz_filename, 2:initrd_filename, 3:directory, 4:note, 5:is_selected, 6:is_remove
        vmlinuz_filename = version_details[1]
        version_name = version_details[0]
        note = version_details[4]
        if vmlinuz_filename.endswith(current_kernel_release_name):
            if note: note += os.linesep
            note += 'This is the kernel you are currently running.'
            if priority <= 3:
                selected_index = index
                priority = 3
        if current_kernel_version_name == version_name:
            if note: note += os.linesep
            note += 'You are running kernel version %s.' % current_kernel_version_name
            if priority <= 2:
                selected_index = index
                priority = 2
        if vmlinuz_filename == 'vmlinuz.efi' or vmlinuz_filename == 'vmlinuz':
            if note: note += os.linesep
            note += 'This is kernel %s, used to boot the original iso image\n(%s).' % (version_name, model.original_iso_image_filename)
            if priority <= 1:
                selected_index = index
                priority = 1
        # 0:version_name, 1:vmlinuz_filename, 2:initrd_filename, 3:directory, 4:note, 5:is_selected, 6:is_remove
        version_details[4] = note
    # 0:version_name, 1:vmlinuz_filename, 2:initrd_filename, 3:directory, 4:note, 5:is_selected, 6:is_remove
    version_details_list[selected_index][5] = True
    return version_details_list

def get_vmlinuz_versions_list_from_directory(directory):
    logger.log_data('Get vmlinuz versions from directory', directory)
    filepath_pattern = os.path.join(directory, 'vmlinuz*')
    filepaths = glob.glob(filepath_pattern)
    versions_list = []
    for filepath in filepaths:
        if not filepath.endswith('efi.signed'):
            version_details = get_vmlinuz_version_from_file(filepath)
            versions_list.append(version_details)
    return versions_list

# It is better to use the get_vmlinuz_versions_list_from_directory function,
# which invokes this function.
def get_vmlinuz_version_from_file(filepath):
    version_name = _get_vmlinuz_version_name_from_file_type(filepath) or _get_vmlinuz_version_name_from_file_contents(filepath)
    version_integers = tuple(map(int, re.split('[.-]', version_name)))
    directory, vmlinuz_filename = os.path.split(filepath)

    initrd_filename = None
    # Handle special case.
    # .../original-iso-mount/casper/vmlinuz.efi
    # .../original-iso-mount/casper/initrd.lz
    if (vmlinuz_filename == 'vmlinuz.efi' or vmlinuz_filename == 'vmlinuz') and os.path.exists(os.path.join(directory, 'initrd.lz')):
        initrd_filename = vmlinuz_filename.replace(vmlinuz_filename, 'initrd.lz')
    # Handle normal case.
    # .../squashfs-root/boot/vmlinuz-*
    # .../squashfs-root/boot/initrd.img-*
    elif os.path.exists(os.path.join(directory, vmlinuz_filename.replace('vmlinuz', 'initrd.img'))):
        initrd_filename = vmlinuz_filename.replace('vmlinuz', 'initrd.img')

    note =''
    is_selected = False
    is_remove = False # This is currently not used, and is for future use.
    # 0:version_integers, 1:version_name, 2:vmlinuz_filename, 3:initrd_filename, 4:directory, 5:note, 6:is_selected, 7:is_remove
    version_details = [version_integers, version_name, vmlinuz_filename, initrd_filename, directory, note, is_selected, is_remove]
    return version_details

def _get_vmlinuz_version_name_from_file_type(filepath):
    logger.log_data('Get vmlinuz version from file type', filepath)
    version_name = None
    try:
        line = subprocess.check_output(['file', filepath]).decode()
        version_information = re.search(r'(\d+\.\d+\.\d+(?:-\d+))', str(line))
        version_name = version_information.group(1)
        logger.log_data('Found version', version_name)
    except subprocess.CalledProcessError as exception:
        pass
    except AttributeError as exception:
        pass
    return version_name

def _get_vmlinuz_version_name_from_file_contents(filepath):
    logger.log_data('Get vmlinuz version from file contents', filepath)
    version_name = None
    with open(filepath, errors='ignore') as file:
        contents = file.read()
    candidate = ''
    for character in contents:
        if character in string.printable:
            candidate += character
        elif len(candidate) > 4:
            try:
                version_information = re.search(r'(\d+\.\d+\.\d+(?:-\d+))', str(candidate))
                version_name = version_information.group(1)
                logger.log_data('Found version', version_name)
                break
            except:
                candidate = ''
        else:
            candidate = ''
    return version_name


################################################################################
# Create Filesystem Manifest Functions
################################################################################

def create_filesystem_manifest_file(thread):
    logger.log_note('Creating the filesystem manifest')

    # Create the filesystem.manifest file.
    command = 'chroot %s dpkg-query -W' % model.custom_squashfs_directory
    execute_asynchronous(thread, command)
    line = thread.process.read()
    filepath = os.path.join(model.custom_live_iso_directory, 'casper', 'filesystem.manifest')
    with open(filepath, 'w') as file: file.write('%s' % line)

    # Count the number of installed packages.
    package_count = count_lines(thread, filepath)
    logger.log_data('Number of installed packages', package_count)
    display.update_label('create_manifest_page__create_filesystem_manifest_result_label', 'There are %s packages installed.' % package_count)


def get_installed_packages_list():
    logger.log_note('Creating the list of installed packages')

    # Installed packages.
    installed_packages_list = []
    filepath = os.path.join(model.custom_live_iso_directory, 'casper', 'filesystem.manifest')
    with open(filepath, 'r') as file: installed_packages_list = file.read().splitlines()

    return installed_packages_list


def get_removable_packages_list():
    # Packages to remove.
    removable_packages_list = []
    filepath = os.path.join(model.custom_live_iso_directory, 'casper', 'filesystem.manifest-remove')
    with open(filepath, 'r') as file: removable_packages_list = file.read().splitlines()

    return removable_packages_list


def create_package_details_list(installed_packages_list, removable_packages_list):
    logger.log_note('Creating the package details list')

    # List installed packages and mark packages that will be removed.
    package_details_list = []
    for line in installed_packages_list:
        package_details = line.split()
        package_name = package_details[0]
        # Add an element at the beginning of the list to indicate if the package_name
        # should be removed (True) or kept (False).
        package_details.insert(0, package_name in removable_packages_list)
        # print(package_details)
        package_details_list.append(package_details)

    return package_details_list


################################################################################
# Repackage Functions
################################################################################

def create_removable_packages_list():
    logger.log_note('Creating the removable packages list')

    liststore = model.builder.get_object('create_manifest_page__package_details_liststore')

    removable_packages_list = []
    item = liststore.get_iter_first()
    while item is not None:
        flag = liststore.get_value(item, 0)
        package_name = liststore.get_value(item, 1)
        # print ('Flag: %s, Package', (flag, package_name))
        if flag: removable_packages_list.append(package_name)
        item = liststore.iter_next(item)

    removable_packages_list.sort()
    return removable_packages_list


def create_filesystem_manifest_remove_file(removable_packages_list):
    filepath = os.path.join(model.custom_live_iso_directory, 'casper', 'filesystem.manifest-remove')
    with open(filepath, 'w') as file:
        first_line = True
        for packages_name in removable_packages_list:
            if first_line:
                file.write('%s' % packages_name)
                first_line = False
            else:
                file.write('\n%s' % packages_name)

def copy_boot_files(thread):
    logger.log_note('Copying boot files')

    liststore = model.builder.get_object('manage_linux_kernels_page__kernel_details_liststore')
    for selected, version_details in enumerate(liststore):
        # 0:version_name, 1:vmlinuz_filename, 2:initrd_filename, 3:directory, 4:note, 5:is_selected, 6:is_remove
        if version_details[5]: break
    # else: selected = -1
    else: selected = len(version_details_list) - 1

    # 0:version_name, 1:vmlinuz_filename, 2:initrd_filename, 3:directory, 4:note, 5:is_selected, 6:is_remove
    directory = liststore[selected][3]

    # vmlinuz
    # 0:version_name, 1:vmlinuz_filename, 2:initrd_filename, 3:directory, 4:note, 5:is_selected, 6:is_remove
    filename = liststore[selected][1]

    if (filename == 'vmlinuz.efi' or filename == 'vmlinuz'):
        target_filename = filename
    elif os.path.exists(os.path.join(directory, 'vmlinuz')):
        target_filename = 'vmlinuz'
    else:
        target_filename = 'vmlinuz.efi'

    source_path = os.path.join(directory, filename)
    target_path = os.path.join(model.custom_live_iso_directory, 'casper', target_filename)
    logger.log_data('The vmlinuz source file is', source_path)
    logger.log_data('The vmlinuz target file is', target_path)
    copy_boot_file(thread, source_path, 0, target_path, 2)
    # chmod a=r ./custom-live-iso/casper/vmlinuz.efi
    os.chmod(target_path, stat.S_IRUSR | stat.S_IWUSR| stat.S_IRGRP | stat.S_IROTH)

    # initrd
    # 0:version_name, 1:vmlinuz_filename, 2:initrd_filename, 3:directory, 4:note, 5:is_selected, 6:is_remove
    filename = liststore[selected][2]
    source_path = os.path.join(directory, filename)
    target_path = os.path.join(model.custom_live_iso_directory, 'casper', 'initrd.lz')
    copy_boot_file(thread, source_path, 1, target_path, 2)
    logger.log_data('The initrd source file is', source_path)
    logger.log_data('The initrd target file is', target_path)

    # chmod a=r ./custom-live-iso/casper/initrd.lz
    os.chmod(target_path, stat.S_IRUSR | stat.S_IRGRP | stat.S_IROTH)

    # TODO: Make sure the following *relative* links are created:
    #       - squashfs-root/initrd.img --> /boot/initrd.img-4.8.0-37-generic
    #       - squashfs-root/vmlinuz    --> /boot/vmlinuz-4.8.0-37-generic
    #       - Use the function: os.symlink(src, dst)

def copy_boot_file(thread, source_path, file_number, target_path, total_files):
    logger.log_data('Copying file number', '%s of %s' % (file_number + 1, total_files))
    logger.log_data('The source file is', source_path)
    logger.log_data('The target file is', target_path)

    command = 'rsync --archive --no-relative --no-implied-dirs --info=progress2 "%s" "%s"' % (source_path, target_path)

    execute_asynchronous(thread, command)

    progress_initial_global = int(round(100 * file_number / total_files, 0))

    progress_initial = 0
    progress_target = 100
    progress_display = progress_initial - 1
    progress_current = progress_initial

    logger.log_data('The progress is', '%s%% of %s%%' % (progress_current, progress_target))

    while (thread.process.exitstatus is None) or (progress_display < progress_target and thread.process.exitstatus == 0):

        try:
            line = thread.process.read_nonblocking(100, 0.05)
            result = re.search(r'([0-9]{1,3})%', str(line))
            if result:
                progress_current = progress_initial + int(result.group(1))
                # progress_current_global = round(progress_initial_global + progress_current/total_files, 0)
        except pexpect.TIMEOUT:
            pass
        except pexpect.EOF:
            if progress_current < progress_target: progress_current = progress_target
            time.sleep(0.01)

        if progress_current > progress_display:
            progress_display += 1
            if progress_display == 0:
                display.update_progressbar_text('repackage_iso_page__copy_boot_files_progressbar', None)
            display.update_progressbar_percent('repackage_iso_page__copy_boot_files_progressbar', progress_initial_global + progress_display / total_files)

    time.sleep(0.01)

def create_squashfs(thread):
    logger.log_note('Creating squashfs')

    source_path = model.custom_squashfs_directory
    logger.log_data('The source path is', source_path)

    target_path = os.path.join(model.custom_live_iso_directory, 'casper', 'filesystem.squashfs')
    logger.log_data('The target path is', target_path)

    command = 'mksquashfs %s %s -noappend -comp xz' % (source_path, target_path)
    execute_asynchronous(thread, command)

    progress_initial = 0
    progress_target = 100
    progress_display = progress_initial - 1
    progress_current = progress_initial

    while (thread.process.exitstatus is None) or (progress_display < progress_target and thread.process.exitstatus == 0):

        try:
            line = thread.process.read_nonblocking(100, 0.05)
            result = re.search(r'([0-9]{1,3})%', str(line))
            if result: progress_current = progress_initial + int(result.group(1))
        except pexpect.TIMEOUT:
            pass
        except pexpect.EOF:
            if progress_current < progress_target: progress_current = progress_target
            time.sleep(0.05)

        if progress_current > progress_display:
            progress_display += 1
            if progress_display == 0:
                display.update_progressbar_text('repackage_iso_page__create_squashfs_progressbar', None)
            display.update_progressbar_percent('repackage_iso_page__create_squashfs_progressbar', progress_display)

    time.sleep(0.10)


def update_filesystem_size(thread):
    logger.log_note('Updating the filesystem size')

    command = 'du -sx --block-size=1 %s' % model.custom_squashfs_directory
    execute_asynchronous(thread, command)
    line = thread.process.read()

    filepath = os.path.join(model.custom_live_iso_directory, 'casper', 'filesystem.size')
    size = re.search(r'^([0-9]+)\s', line).group(1)
    with open(filepath, 'w') as file: file.write('%s' % size)

    return int(size)


def update_disk_name():
    logger.log_note('Updating the disk name')

    try:
        path = os.path.join(model.custom_live_iso_directory, 'README.diskdefines')
        search_text = r'^#define DISKNAME.*'
        replacement_text = '#define DISKNAME %s' % model.custom_iso_image_disk_name
        replace_text_in_file(path, search_text, replacement_text)
    except Exception as exception:
        logger.log_data('Ignoring exception %s while updating disk name in README.diskdefines', exception)


def update_disk_info():
    logger.log_note('Updating the disk information')

    filepath = os.path.join(model.custom_live_iso_directory, '.disk', 'info')
    with open(filepath, 'w') as file: file.write('%s' % model.custom_iso_image_disk_name)


def buffered_hash_md5(filepath, blocksize=2**20):
    m = hashlib.md5()
    with open(filepath, 'rb' ) as f:
        while True:
            buf = f.read(blocksize)
            if not buf: break
            m.update(buf)
    return m.hexdigest()


def update_md5_sums():
    logger.log_note('Updating the md5 sums')

    os.chdir(model.custom_live_iso_directory)

    with open('md5sum.txt', 'w') as md5_sum_file:
        for root, dirs, files in os.walk('.'):
            for filename in files:
                if root != './isolinux' and filename != 'md5sum.txt':
                    filepath = os.path.join(root, filename)
                    md5_sum = hashlib.md5(open(filepath, 'rb').read()).hexdigest()
                    md5_sum_file.write('%s  %s\n' % (md5_sum, filepath))
                    # logger.log_note('%s  %s' % (md5_sum, filepath))


def count_lines(thread, filepath):
    command = 'wc -l %s' % filepath
    execute_asynchronous(thread, command)
    line = thread.process.read()
    count = int(re.search(r'([0-9]*) ', str(line)).group(1))
    return count


def create_iso_image(thread):
    # TODO: Address larger than 4GiB file error.
    # I: -input-charset not specified, using utf-8 (detected in locale settings)
    # File ./casper/filesystem.squashfs is larger than 4GiB-1.
    # -allow-limited-size was not specified. There is no way do represent this file size. Aborting.

    logger.log_note('Creating the iso image')

    # Bug #1623261
    # https://www.gnu.org/software/xorriso/man_1_xorrisofs.html
    # http://www.syslinux.org/wiki/index.php?title=Isohybrid
    if os.path.exists('/usr/lib/ISOLINUX/isohdpfx.bin'):
        # Ubuntu 15.04 uses isolinux (/usr/lib/ISOLINUX/isohdpfx.bin).
        logger.log_data('Using xorriso with isohybrid MBR', '/usr/lib/ISOLINUX/isohdpfx.bin')

        if os.path.exists('boot/grub/efi.img'):
            command = 'xorriso'\
                    ' -as mkisofs -r -V "%s" -cache-inodes -J -l'\
                    ' -isohybrid-mbr /usr/lib/ISOLINUX/isohdpfx.bin'\
                    ' -c isolinux/boot.cat'\
                    ' -b isolinux/isolinux.bin'\
                    '  -no-emul-boot'\
                    '  -boot-load-size 4'\
                    '  -boot-info-table'\
                    ' -eltorito-alt-boot'\
                    '  -e boot/grub/efi.img'\
                    '  -no-emul-boot'\
                    '  -isohybrid-gpt-basdat'\
                    ' -o "%s" .'\
                    % (model.custom_iso_image_volume_id, model.custom_iso_image_filepath)
        else:
            command = 'xorriso'\
                    ' -as mkisofs -r -V "%s" -cache-inodes -J -l'\
                    ' -isohybrid-mbr /usr/lib/ISOLINUX/isohdpfx.bin'\
                    ' -c isolinux/boot.cat'\
                    ' -b isolinux/isolinux.bin'\
                    '  -no-emul-boot'\
                    '  -boot-load-size 4'\
                    '  -boot-info-table'\
                    ' -o "%s" .'\
                    % (model.custom_iso_image_volume_id, model.custom_iso_image_filepath)
    elif os.path.exists('/usr/lib/syslinux/isohdpfx.bin'):
        # Ubuntu 14.04 uses syslinux-common (/usr/lib/syslinux/isohdpfx.bin).
        logger.log_data('Using xorriso with isohybrid MBR', '/usr/lib/syslinux/isohdpfx.bin')

        if os.path.exists('boot/grub/efi.img'):
            command = 'xorriso'\
                    ' -as mkisofs -r -V "%s" -cache-inodes -J -l'\
                    ' -isohybrid-mbr /usr/lib/syslinux/isohdpfx.bin'\
                    ' -c isolinux/boot.cat'\
                    ' -b isolinux/isolinux.bin'\
                    '  -no-emul-boot'\
                    '  -boot-load-size 4'\
                    '  -boot-info-table'\
                    ' -eltorito-alt-boot'\
                    '  -e boot/grub/efi.img'\
                    '  -no-emul-boot'\
                    '  -isohybrid-gpt-basdat'\
                    ' -o "%s" .'\
                    % (model.custom_iso_image_volume_id, model.custom_iso_image_filepath)
        else:
            command = 'xorriso'\
                    ' -as mkisofs -r -V "%s" -cache-inodes -J -l'\
                    ' -isohybrid-mbr /usr/lib/syslinux/isohdpfx.bin'\
                    ' -c isolinux/boot.cat'\
                    ' -b isolinux/isolinux.bin'\
                    '  -no-emul-boot'\
                    '  -boot-load-size 4'\
                    '  -boot-info-table'\
                    ' -o "%s" .'\
                    % (model.custom_iso_image_volume_id, model.custom_iso_image_filepath)
    else:
        logger.log_data('Using mkisofs', 'No isohybrid MBR available.')
        command = 'mkisofs -r -V "%s" -cache-inodes -J -l'\
                ' -c isolinux/boot.cat'\
                ' -b isolinux/isolinux.bin'\
                '  -no-emul-boot'\
                '  -boot-load-size 4'\
                '  -boot-info-table'\
                ' -o "%s" .'\
                % (model.custom_iso_image_volume_id, model.custom_iso_image_filepath)

    execute_asynchronous(thread, command, model.custom_live_iso_directory)

    progress_initial = 0
    progress_target = 100
    progress_display = progress_initial - 1
    progress_current = progress_initial

    while (thread.process.exitstatus is None) or (progress_display < progress_target and thread.process.exitstatus == 0):

        try:
            line = thread.process.read_nonblocking(100, 0.05)
            result = re.search(r'([0-9]{1,3})%', str(line))
            if result: progress_current = progress_initial + int(result.group(1))
        except pexpect.TIMEOUT:
            pass
        except pexpect.EOF:
            if progress_current < progress_target: progress_current = progress_target
            time.sleep(0.05)

        if progress_current > progress_display:
            progress_display += 1
            if progress_display == 0:
                display.update_progressbar_text('repackage_iso_page__create_iso_image_progressbar', None)
            display.update_progressbar_percent('repackage_iso_page__create_iso_image_progressbar', progress_display)

    os.chown(model.custom_iso_image_filepath, model.user_id, model.group_id)

    time.sleep(0.10)


def calculate_iso_md5_sum():
    logger.log_note('Calculating the md5 sum')

    md5_sum = buffered_hash_md5(model.custom_iso_image_filepath)
    model.set_custom_iso_image_md5_sum(md5_sum)

    with open(model.custom_iso_image_md5_filepath, 'w') as md5_sum_file:
        md5_sum_file.write('%s  %s' % (md5_sum, model.custom_iso_image_filename))

    os.chown(model.custom_iso_image_md5_filepath, model.user_id, model.group_id)
