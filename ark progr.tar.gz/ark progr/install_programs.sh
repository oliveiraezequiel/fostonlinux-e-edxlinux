#!/bin/bash

# Define the list of programs to install
programs=(
    "vlc"
    "gimp"
    "firefox"
    "chromium-browser"
    "git"
)

# Update package lists
sudo apt update

# Install the programs
for program in "${programs[@]}"; do
    echo "Installing $program..."
    sudo apt install -y "$program"
done

echo "Installation complete."
