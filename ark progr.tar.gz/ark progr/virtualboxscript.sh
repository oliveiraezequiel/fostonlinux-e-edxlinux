#!/bin/bash
apt update -y 
apt install virtualbox -y 
echo "o grupo EDX linux e trianguloOS agradesem"
echo "tenham um bom dia"



