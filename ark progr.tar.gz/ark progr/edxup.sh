#!/bin/bash

# Atualiza a lista de pacotes
sudo apt update

# Atualiza todos os pacotes instalados
sudo apt upgrade -y

# Limpa pacotes antigos
sudo apt autoremove -y