#!/usr/bin/python3

################################################################################
#                                                                              #
# transitions.py                                                               #
#                                                                              #
# Copyright (C) 2015 PJ Singh <psingh.cubic@gmail.com>                         #
#                                                                              #
################################################################################

################################################################################
#                                                                              #
# This file is part of Cubic - Custom Ubuntu ISO Creator.                      #
#                                                                              #
# Cubic is free software: you can redistribute it and/or modify                #
# it under the terms of the GNU General Public License as published by         #
# the Free Software Foundation, either version 3 of the License, or            #
# (at your option) any later version.                                          #
#                                                                              #
# Cubic is distributed in the hope that it will be useful,                     #
# but WITHOUT ANY WARRANTY; without even the implied warranty of               #
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                #
# GNU General Public License for more details.                                 #
#                                                                              #
# You should have received a copy of the GNU General Public License            #
# along with Cubic.  If not, see <http://www.gnu.org/licenses/>.               #
#                                                                              #
################################################################################

import display
import logger
import model
import utilities
import validators

import configparser
import os
import re
import time


# General steps for each transiton.
#
# Note: Deactivating a page is done by showing the spinner.
#       Activating a page is done by hiding the spinner.
#
# [1] Perform functions on the current page, and deactivate the current page.
# [2] Prepare and display the new page.
# [3] Perform functions on the new page, and activate the new page.

################################################################################
# TransitionThread - Transition
################################################################################

def transition(old_page_name, new_page_name, quit_visible, back_visible, next_visible):
    logger.log_step('Tranisitioning from %s to %s' % (old_page_name, new_page_name))

    # [1] Perform functions on the current page, and deactivate the current page.

    display.show_spinner()
    display.reset_buttons(old_page_name)

    # [2] Prepare and display the new page.

    display.show_page(old_page_name, new_page_name)
    display.reset_buttons(new_page_name, quit_visible, back_visible, next_visible)

    # [3] Perform functions on the new page, and activate the new page.

    display.hide_spinner()


################################################################################
# TransitionThread - Transition Next Functions
################################################################################

# Project Directory Page
# New Project Page
# Existing Project Page
# Confirm Delete Project Page
# Unsquashfs Page
# Terminal Page
# Confirm Copy Page
# Create Manifest Page
# Repackage ISO Page
# Finish Page

#
# Project Directory Page Project Directory Filechooser
#

#
# (New Project Page / Existing Project Page) Original Iso Image Filepath Filechooser
#

def transition__from__project_directory_page__project_directory_filechooser__to__project_directory_page(thread):

    dialog = model.builder.get_object('project_directory_page__project_directory_filechooser')
    project_directory = dialog.get_filename()
    # project_directory = dialog.get_current_folder()
    display.update_entry('project_directory_page__project_directory_entry', project_directory)

    display.set_visible('project_directory_page__project_directory_filechooser', False)

    display.set_sensitive('window', True)


def transition__from__original_iso_image_filepath_filechooser__to__new_project_page(thread):
    model.set_propagate(False)

    dialog = model.builder.get_object('new_project_page__original_iso_image_filepath_filechooser')

    # Original
    model.set_original_iso_image_filepath(dialog.get_filename())
    model.set_original_iso_image_filename(re.sub(r'.*/(.*$)', r'\1', model.original_iso_image_filepath))
    model.set_original_iso_image_directory(dialog.get_current_folder())

    # If the iso image filepath is not mounted at the mount point, mount it. If
    # the iso image filepath has changed, the previous image will be unmounted
    # before the new image is mounted at the mount point.
    if not utilities.is_mounted(model.original_iso_image_filepath, model.original_iso_image_mount_point):
        # This function will unmount the existing image at the mount point.
        # This function will not mount the iso image filepath if it is invalid.
        utilities.mount_iso_image(thread, model.original_iso_image_filepath, model.original_iso_image_mount_point)
    else:
        logger.log_data('The original iso image is already mounted at', model.original_iso_image_mount_point)

    if utilities.is_mounted(model.original_iso_image_filepath, model.original_iso_image_mount_point):
        # Original
        model.set_original_iso_image_volume_id(utilities.get_iso_image_volume_id(model.original_iso_image_filepath))
        model.set_original_iso_image_release_name(utilities.get_iso_image_release_name(model.original_iso_image_mount_point))
        model.set_original_iso_image_disk_name(utilities.get_iso_image_disk_name(model.original_iso_image_mount_point))

        # Custom
        model.set_custom_iso_image_version_number(utilities.create_custom_iso_image_version_number())
        model.set_custom_iso_image_filename(utilities.create_custom_iso_image_filename(model.original_iso_image_filename, model.custom_iso_image_version_number))
        model.set_custom_iso_image_directory(model.project_directory)
        model.set_custom_iso_image_filepath(os.path.join(model.custom_iso_image_directory, model.custom_iso_image_filename))
        model.set_custom_iso_image_volume_id(utilities.create_custom_iso_image_volume_id(model.original_iso_image_volume_id, model.custom_iso_image_version_number))
        model.set_custom_iso_image_release_name(utilities.create_custom_iso_image_release_name(model.original_iso_image_release_name))
        model.set_custom_iso_image_disk_name(utilities.create_custom_iso_image_disk_name(model.custom_iso_image_volume_id, model.custom_iso_image_release_name))
        model.set_custom_iso_image_md5_filename(utilities.create_custom_iso_image_md5_filename(model.custom_iso_image_filename))
        model.set_custom_iso_image_md5_filepath(os.path.join(model.custom_iso_image_directory, model.custom_iso_image_md5_filepath))

    # Display original values.
    display.update_entry('new_project_page__original_iso_image_filename_entry', model.original_iso_image_filename)
    display.update_entry('new_project_page__original_iso_image_directory_entry', model.original_iso_image_directory)
    display.update_entry('new_project_page__original_iso_image_volume_id_entry', model.original_iso_image_volume_id)
    display.update_entry('new_project_page__original_iso_image_release_name_entry', model.original_iso_image_release_name)
    display.update_entry('new_project_page__original_iso_image_disk_name_entry', model.original_iso_image_disk_name)

    # Display custom values.
    display.update_entry('new_project_page__custom_iso_image_version_number_entry', model.custom_iso_image_version_number)
    display.update_entry('new_project_page__custom_iso_image_filename_entry', model.custom_iso_image_filename)
    display.update_entry('new_project_page__custom_iso_image_directory_entry', model.custom_iso_image_directory)
    display.update_entry('new_project_page__custom_iso_image_volume_id_entry', model.custom_iso_image_volume_id)
    display.update_entry('new_project_page__custom_iso_image_release_name_entry', model.custom_iso_image_release_name)
    display.update_entry('new_project_page__custom_iso_image_disk_name_entry', model.custom_iso_image_disk_name)

    validators.validate_new_project_page()

    display.set_visible('new_project_page__original_iso_image_filepath_filechooser', False)

    display.set_sensitive('window', True)

    model.set_propagate(True)


def transition__from__original_iso_image_filepath_filechooser__to__existing_project_page(thread):
    model.set_propagate(False)

    dialog = model.builder.get_object('existing_project_page__original_iso_image_filepath_filechooser')

    # General
    configuration = configparser.RawConfigParser()
    configuration.read(model.configuration_filepath)

    # Original
    model.set_original_iso_image_filepath(dialog.get_filename())
    model.set_original_iso_image_filename(re.sub(r'.*/(.*$)', r'\1', model.original_iso_image_filepath))
    model.set_original_iso_image_directory(dialog.get_current_folder())

    # If the iso image filepath is not mounted at the mount point, mount it. If
    # the iso image filepath has changed, the previous image will be unmounted
    # before the new image is mounted at the mount point.
    if not utilities.is_mounted(model.original_iso_image_filepath, model.original_iso_image_mount_point):
        # This function will unmount the existing image at the mount point.
        # This function will not mount the iso image filepath if it is invalid.
        utilities.mount_iso_image(thread, model.original_iso_image_filepath, model.original_iso_image_mount_point)
    else:
        logger.log_data('The original iso image is already mounted at', model.original_iso_image_mount_point)

    if utilities.is_mounted(model.original_iso_image_filepath, model.original_iso_image_mount_point):
        # Original
        model.set_original_iso_image_volume_id(utilities.get_iso_image_volume_id(model.original_iso_image_filepath))
        model.set_original_iso_image_release_name(utilities.get_iso_image_release_name(model.original_iso_image_mount_point))
        model.set_original_iso_image_disk_name(utilities.get_iso_image_disk_name(model.original_iso_image_mount_point))

        # Custom
        model.set_custom_iso_image_version_number(configuration.get('Custom', 'custom_iso_image_version_number'))
        model.set_custom_iso_image_filename(configuration.get('Custom', 'custom_iso_image_filename'))
        model.set_custom_iso_image_directory(configuration.get('Custom', 'custom_iso_image_directory'))
        model.set_custom_iso_image_filepath(os.path.join(model.custom_iso_image_directory, model.custom_iso_image_filename))
        model.set_custom_iso_image_volume_id(configuration.get('Custom', 'custom_iso_image_volume_id'))
        model.set_custom_iso_image_release_name(configuration.get('Custom', 'custom_iso_image_release_name'))
        model.set_custom_iso_image_disk_name(configuration.get('Custom', 'custom_iso_image_disk_name'))
        model.set_custom_iso_image_md5_filename(configuration.get('Custom', 'custom_iso_image_md5_filename'))
        model.set_custom_iso_image_md5_filepath(os.path.join(model.custom_iso_image_directory, model.custom_iso_image_md5_filename))

    # Display original values.
    display.update_entry('existing_project_page__original_iso_image_filename_entry', model.original_iso_image_filename)
    display.update_entry('existing_project_page__original_iso_image_directory_entry', model.original_iso_image_directory)
    display.update_entry('existing_project_page__original_iso_image_volume_id_entry', model.original_iso_image_volume_id)
    display.update_entry('existing_project_page__original_iso_image_release_name_entry', model.original_iso_image_release_name)
    display.update_entry('existing_project_page__original_iso_image_disk_name_entry', model.original_iso_image_disk_name)

    # Display custom values.
    display.update_entry('existing_project_page__custom_iso_image_version_number_entry', model.custom_iso_image_version_number)
    display.update_entry('existing_project_page__custom_iso_image_filename_entry', model.custom_iso_image_filename)
    display.update_entry('existing_project_page__custom_iso_image_directory_entry', model.custom_iso_image_directory)
    display.update_entry('existing_project_page__custom_iso_image_volume_id_entry', model.custom_iso_image_volume_id)
    display.update_entry('existing_project_page__custom_iso_image_release_name_entry', model.custom_iso_image_release_name)
    display.update_entry('existing_project_page__custom_iso_image_disk_name_entry', model.custom_iso_image_disk_name)

    validators.validate_existing_project_page()

    display.set_visible('existing_project_page__original_iso_image_filepath_filechooser', False)

    display.set_sensitive('window', True)

    model.set_propagate(True)


def transition__from__custom_iso_image_directory_filechooser__to__new_project_page(thread):

    dialog = model.builder.get_object('new_project_page__custom_iso_image_directory_filechooser')
    custom_iso_image_directory = dialog.get_filename()
    # custom_iso_image_directory = dialog.get_current_folder()
    display.update_entry('new_project_page__custom_iso_image_directory_entry', custom_iso_image_directory)

    display.set_visible('new_project_page__custom_iso_image_directory_filechooser', False)

    display.set_sensitive('window', True)


def transition__from__custom_iso_image_directory_filechooser__to__existing_project_page(thread):

    dialog = model.builder.get_object('existing_project_page__custom_iso_image_directory_filechooser')
    custom_iso_image_directory = dialog.get_filename()
    # custom_iso_image_directory = dialog.get_current_folder()
    display.update_entry('existing_project_page__custom_iso_image_directory_entry', custom_iso_image_directory)

    display.set_visible('existing_project_page__custom_iso_image_directory_filechooser', False)

    display.set_sensitive('window', True)


#
# Project Directory Page
#

def transition__from__project_directory_page__to__new_project_page(thread):
    # [1] Perform functions on the current page, and deactivate the current page.

    model.set_propagate(False)
    display.show_spinner()
    display.reset_buttons('project_directory_page')

    # Original
    model.set_original_iso_image_filepath('')  # Aggregated value; not displayed.
    model.set_original_iso_image_filename('')
    model.set_original_iso_image_directory('')
    model.set_original_iso_image_volume_id('')
    model.set_original_iso_image_release_name('')
    model.set_original_iso_image_disk_name('')

    # Custom
    model.set_custom_iso_image_version_number('')
    model.set_custom_iso_image_filename('')
    model.set_custom_iso_image_directory('')
    model.set_custom_iso_image_filepath('')  # Aggregated value; not displayed.
    model.set_custom_iso_image_volume_id('')
    model.set_custom_iso_image_release_name('')
    model.set_custom_iso_image_disk_name('')
    model.set_custom_iso_image_md5_filename('')  # Aggregated value; not displayed.
    model.set_custom_iso_image_md5_filepath('')  # Aggregated value; not displayed.

    # Status
    model.set_is_success_copy_original_iso_files(False)
    model.set_is_success_extract_squashfs(False)

    # [2] Prepare and display the new page.

    # Display original values.
    display.update_entry('new_project_page__original_iso_image_filename_entry', model.original_iso_image_filename)
    display.update_entry('new_project_page__original_iso_image_directory_entry', model.original_iso_image_directory)
    display.update_entry('new_project_page__original_iso_image_volume_id_entry', model.original_iso_image_volume_id)
    display.update_entry('new_project_page__original_iso_image_release_name_entry', model.original_iso_image_release_name)
    display.update_entry('new_project_page__original_iso_image_disk_name_entry', model.original_iso_image_disk_name)

    # Display custom values.
    display.update_entry('new_project_page__custom_iso_image_version_number_entry', model.custom_iso_image_version_number)
    display.update_entry('new_project_page__custom_iso_image_filename_entry', model.custom_iso_image_filename)
    display.update_entry('new_project_page__custom_iso_image_directory_entry', model.custom_iso_image_directory)
    display.update_entry('new_project_page__custom_iso_image_volume_id_entry', model.custom_iso_image_volume_id)
    display.update_entry('new_project_page__custom_iso_image_release_name_entry', model.custom_iso_image_release_name)
    display.update_entry('new_project_page__custom_iso_image_disk_name_entry', model.custom_iso_image_disk_name)

    # Activate radio button 2 as the default option (continue customizing the
    # existing project) when the existing project page is displyed.
    # The handler on_toggled__existing_project_page__radiobutton() is called
    # whenever the radiobutton is toggled; however the function will not
    # execute, because model.propagate is False.
    display.activate_radiobutton('existing_project_page__radiobutton_2', True)

    # Transition to the New Project page.
    display.show_page('project_directory_page', 'new_project_page')
    display.reset_buttons('new_project_page', True, True, False)

    # [3] Perform functions on the new page, and activate the new page.

    validators.validate_new_project_page()

    display.hide_spinner()

    model.set_propagate(True)


def transition__from__project_directory_page__to__existing_project_page(thread):
    # [1] Perform functions on the current page, and deactivate the current page.

    model.set_propagate(False)
    display.show_spinner()
    display.reset_buttons('project_directory_page')

    # General
    configuration = configparser.ConfigParser()
    configuration.read(model.configuration_filepath)

    # Original
    model.set_original_iso_image_filename(configuration.get('Original', 'original_iso_image_filename'))
    model.set_original_iso_image_directory(configuration.get('Original', 'original_iso_image_directory'))
    model.set_original_iso_image_filepath(os.path.join(model.original_iso_image_directory, model.original_iso_image_filename))

    # If the iso image filepath is not mounted at the mount point, mount it. If
    # the iso image filepath has changed, the previous image will be unmounted
    # before the new image is mounted at the mount point.
    is_mounted = utilities.is_mounted(model.original_iso_image_filepath, model.original_iso_image_mount_point)
    if not is_mounted:
        # This function will unmount the existing image at the mount point.
        # This function will not mount the iso image filepath if it is invalid.
        utilities.mount_iso_image(thread, model.original_iso_image_filepath, model.original_iso_image_mount_point)

    # if utilities.is_mounted(model.original_iso_image_filepath, model.original_iso_image_mount_point):
    # model.set_original_iso_image_volume_id(utilities.get_iso_image_volume_id(model.original_iso_image_filepath))
    model.set_original_iso_image_volume_id(configuration.get('Original', 'original_iso_image_volume_id'))
    # model.set_original_iso_image_release_name(utilities.get_iso_image_release_name(model.original_iso_image_mount_point))
    model.set_original_iso_image_release_name(configuration.get('Original', 'original_iso_image_release_name'))
    # model.set_original_iso_image_disk_name(utilities.get_iso_image_disk_name(model.original_iso_image_mount_point))
    model.set_original_iso_image_disk_name(configuration.get('Original', 'original_iso_image_disk_name'))

    # Custom
    model.set_custom_iso_image_version_number(configuration.get('Custom', 'custom_iso_image_version_number'))
    model.set_custom_iso_image_filename(configuration.get('Custom', 'custom_iso_image_filename'))
    model.set_custom_iso_image_directory(configuration.get('Custom', 'custom_iso_image_directory'))
    model.set_custom_iso_image_filepath(os.path.join(model.custom_iso_image_directory, model.custom_iso_image_filename))
    model.set_custom_iso_image_volume_id(configuration.get('Custom', 'custom_iso_image_volume_id'))
    model.set_custom_iso_image_release_name(configuration.get('Custom', 'custom_iso_image_release_name'))
    model.set_custom_iso_image_disk_name(configuration.get('Custom', 'custom_iso_image_disk_name'))
    model.set_custom_iso_image_md5_filename(configuration.get('Custom', 'custom_iso_image_md5_filename'))
    model.set_custom_iso_image_md5_filepath(os.path.join(model.custom_iso_image_directory, model.custom_iso_image_md5_filename))

    # Status
    # model.set_is_success_copy_original_iso_files(configuration.getboolean('Status', 'is_success_copy_original_iso_files'))
    # model.set_is_success_extract_squashfs(configuration.getboolean('Status', 'is_success_extract_squashfs'))
    model.set_is_success_copy_original_iso_files(configuration.getboolean('Status', 'is_success_copy_original_iso_files', fallback=True))
    model.set_is_success_extract_squashfs(configuration.getboolean('Status', 'is_success_extract_squashfs', fallback=True))

    # [2] Prepare and display the new page.

    # Display original values.
    display.update_entry('existing_project_page__original_iso_image_filename_entry', model.original_iso_image_filename)
    display.update_entry('existing_project_page__original_iso_image_directory_entry', model.original_iso_image_directory)
    display.update_entry('existing_project_page__original_iso_image_volume_id_entry', model.original_iso_image_volume_id)
    display.update_entry('existing_project_page__original_iso_image_release_name_entry', model.original_iso_image_release_name)
    display.update_entry('existing_project_page__original_iso_image_disk_name_entry', model.original_iso_image_disk_name)

    # Display custom values.
    display.update_entry('existing_project_page__custom_iso_image_version_number_entry', model.custom_iso_image_version_number)
    display.update_entry('existing_project_page__custom_iso_image_filename_entry', model.custom_iso_image_filename)
    display.update_entry('existing_project_page__custom_iso_image_directory_entry', model.custom_iso_image_directory)
    display.update_entry('existing_project_page__custom_iso_image_volume_id_entry', model.custom_iso_image_volume_id)
    display.update_entry('existing_project_page__custom_iso_image_release_name_entry', model.custom_iso_image_release_name)
    display.update_entry('existing_project_page__custom_iso_image_disk_name_entry', model.custom_iso_image_disk_name)

    # Activate radio button 1 as the default option (create a disk image from
    # the existing project) when the existing project page is displyed.
    # The handler on_toggled__existing_project_page__radiobutton() is called
    # whenever the radiobutton is toggled; however the function will not
    # execute, because model.propagate is False.
    display.activate_radiobutton('existing_project_page__radiobutton_1', True)

    # Transition to the Existing Project page.
    display.show_page('project_directory_page', 'existing_project_page')
    display.reset_buttons('existing_project_page', True, True, False)

    # [3] Perform functions on the new page, and activate the new page.

    validators.validate_existing_project_page()

    display.hide_spinner()

    model.set_propagate(True)


#
# New Project Page
#

def transition__from__new_project_page__to__terminal_page(thread):
    # [1] Perform functions on the current page, and deactivate the current page.

    display.show_spinner()
    display.reset_buttons('new_project_page')

    # Save the configuration (since it may have changed).
    utilities.save_configuration()

    # [2] Prepare and display the new page.

    # Setup the Copy Original Iso Files section.
    display.update_label('unsquashfs_page__copy_original_iso_files_label', 'Copy iso files from the original disk image:')
    display.update_label('unsquashfs_page__copy_original_iso_files_original_disk_image_label', '%s' % model.original_iso_image_filepath)
    display.update_progressbar_percent('unsquashfs_page__copy_original_iso_files_progressbar', 0)
    display.update_progressbar_text('unsquashfs_page__copy_original_iso_files_progressbar', '')
    display.set_label_error('unsquashfs_page__copy_original_iso_files_result_label', False)
    display.update_label('unsquashfs_page__copy_original_iso_files_result_label', '...')
    display.set_visible('unsquashfs_page__copy_original_iso_files_spinner', False)
    display.update_status('unsquashfs_page__unsquashfs', 'bullet')
    display.set_visible('unsquashfs_page__grid_02', True)

    # Setup the Unsquashfs section.
    display.update_label('unsquashfs_page__unsquashfs_original_disk_image_label', '%s' % model.original_iso_image_filepath)
    display.update_progressbar_percent('unsquashfs_page__unsquashfs_progressbar', 0)
    display.update_progressbar_text('unsquashfs_page__unsquashfs_progressbar', '')
    display.set_label_error('unsquashfs_page__unsquashfs_result_label', False)
    display.update_label('unsquashfs_page__unsquashfs_result_label', '...')
    display.set_visible('unsquashfs_page__unsquashfs_spinner', False)
    display.update_status('unsquashfs_page__unsquashfs', 'bullet')
    display.set_visible('unsquashfs_page__grid_03', True)

    # Transition to the Unsquashfs page.
    display.show_page('new_project_page', 'unsquashfs_page')
    display.reset_buttons('unsquashfs_page', True, True, False)

    # [3] Perform functions on the new page, and activate the new page.

    display.hide_spinner()

    # Perform actions in the Copy Original Iso Files section.
    display.update_status('unsquashfs_page__copy_original_iso_files', 'processing')
    time.sleep(0.25)

    # Copy original iso files.
    utilities.copy_original_iso_files(thread, True)
    # TODO: Check for result and set success value, message, and color accordingly.
    model.set_is_success_copy_original_iso_files(True)
    display.update_label('unsquashfs_page__copy_original_iso_files_result_label', 'All original iso files have been copied.')
    display.update_status('unsquashfs_page__copy_original_iso_files', 'check')
    time.sleep(0.25)

    # Perform actions in the Unsquashfs section.
    display.update_status('unsquashfs_page__unsquashfs', 'processing')
    time.sleep(0.25)

    # Extract filesystem.squashfs.
    utilities.extract_squashfs(thread)
    # TODO: Check for result and set success value, message, and color accordingly.
    model.set_is_success_extract_squashfs(True)
    display.update_label('unsquashfs_page__unsquashfs_result_label', 'The compressed Linux file system has been extracted.')
    display.update_status('unsquashfs_page__unsquashfs', 'check')
    time.sleep(0.25)

    # Save the configuration (since it may have changed).
    utilities.save_configuration()

    # Decide to transition to the Terminal page or remain on the Unsquashfs page.
    if model.is_success_copy_original_iso_files and model.is_success_extract_squashfs:

        # Transition to the Terminal page.

        # [1] Perform functions on the current page, and deactivate the current page.

        # Pause to let the user read the screen before automatic transition.
        time.sleep(1.00)
        display.show_spinner()
        display.reset_buttons('unsquashfs_page')

        # Prepare the chroot terminal.
        utilities.prepare_chroot_environment(thread)
        utilities.enter_chroot_environment(thread)

        # [2] Prepare and display the new page.

        display.set_visible('terminal_page__exit_terminal_label', False)

        # Transition to the Terminal page.
        display.show_page('unsquashfs_page', 'terminal_page')
        display.reset_buttons('terminal_page', True, True, True)

        # [3] Perform functions on the new page, and activate the new page.

        utilities.check_chroot_environment(thread)
        display.hide_spinner()

    else:

        # Stay on the  the Unsquashfs page.

        # [1] Perform functions on the current page, and deactivate the current page.

        # [2] Prepare and display the new page.

        display.reset_buttons('unsquashfs_page', True, True, False)

        # [3] Perform functions on the new page, and activate the new page.


#
# Existing Project Page
#

def transition__from__existing_project_page__to__existing_project_page(thread):

    if model.builder.get_object('existing_project_page__radiobutton_1').get_active():
        transition__from__existing_project_page__to__existing_project_page_radiobutton_1(thread)
    elif model.builder.get_object('existing_project_page__radiobutton_2').get_active():
        transition__from__existing_project_page__to__existing_project_page_radiobutton_2(thread)
    elif model.builder.get_object('existing_project_page__radiobutton_3').get_active():
        transition__from__existing_project_page__to__existing_project_page_radiobutton_3(thread)


def transition__from__existing_project_page__to__existing_project_page_radiobutton_1(thread):

    display.set_sensitive('existing_project_page__original_iso_image_filepath_filechooser_open_button', True)
    display.reset_buttons('existing_project_page', True, True, False)
    validators.validate_existing_project_page()

    '''
    # [1] Perform functions on the current page, and deactivate the current page.

    model.set_propagate(False)
    display.show_spinner()
    display.reset_buttons('existing_project_page')

    # General
    configuration = configparser.ConfigParser()
    configuration.read(model.configuration_filepath)

    # Original
    model.set_original_iso_image_filename(configuration.get('Original', 'original_iso_image_filename'))
    model.set_original_iso_image_directory(configuration.get('Original', 'original_iso_image_directory'))
    model.set_original_iso_image_filepath(os.path.join(model.original_iso_image_directory, model.original_iso_image_filename))

    # If the iso image filepath is not mounted at the mount point, mount it. If
    # the iso image filepath has changed, the previous image will be unmounted
    # before the new image is mounted at the mount point.
    is_mounted = utilities.is_mounted(model.original_iso_image_filepath, model.original_iso_image_mount_point)
    if not is_mounted:
        # This function will unmount the existing image at the mount point.
        # This function will not mount the iso image filepath if it is invalid.
        utilities.mount_iso_image(thread, model.original_iso_image_filepath, model.original_iso_image_mount_point)
    else:
        logger.log_data('The original iso image is already mounted at', model.original_iso_image_mount_point)

    if utilities.is_mounted(model.original_iso_image_filepath, model.original_iso_image_mount_point):
        # Original
        model.set_original_iso_image_volume_id(configuration.get('Original', 'original_iso_image_volume_id'))
        model.set_original_iso_image_release_name(configuration.get('Original', 'original_iso_image_release_name'))
        model.set_original_iso_image_disk_name(configuration.get('Original', 'original_iso_image_disk_name'))

    # Custom
    model.set_custom_iso_image_version_number(configuration.get('Custom', 'custom_iso_image_version_number'))
    model.set_custom_iso_image_filename(configuration.get('Custom', 'custom_iso_image_filename'))
    model.set_custom_iso_image_directory(configuration.get('Custom', 'custom_iso_image_directory'))
    model.set_custom_iso_image_filepath(os.path.join(model.custom_iso_image_directory, model.custom_iso_image_filename))
    model.set_custom_iso_image_volume_id(configuration.get('Custom', 'custom_iso_image_volume_id'))
    model.set_custom_iso_image_release_name(configuration.get('Custom', 'custom_iso_image_release_name'))
    model.set_custom_iso_image_disk_name(configuration.get('Custom', 'custom_iso_image_disk_name'))
    model.set_custom_iso_image_md5_filename(configuration.get('Custom', 'custom_iso_image_md5_filename'))
    model.set_custom_iso_image_md5_filepath(os.path.join(model.custom_iso_image_directory, model.custom_iso_image_md5_filename))

    # Status
    # model.set_is_success_copy_original_iso_files(configuration.getboolean('Status', 'is_success_copy_original_iso_files'))
    # model.set_is_success_extract_squashfs(configuration.getboolean('Status', 'is_success_extract_squashfs'))
    model.set_is_success_copy_original_iso_files(configuration.getboolean('Status', 'is_success_copy_original_iso_files', fallback=True))
    model.set_is_success_extract_squashfs(configuration.getboolean('Status', 'is_success_extract_squashfs', fallback=True))

    # Status
    # model.set_is_success_copy_original_iso_files(configuration.getboolean('Status', 'is_success_copy_original_iso_files'))
    # model.set_is_success_extract_squashfs(configuration.getboolean('Status', 'is_success_extract_squashfs'))
    model.set_is_success_copy_original_iso_files(configuration.getboolean('Status', 'is_success_copy_original_iso_files', fallback=True))
    model.set_is_success_extract_squashfs(configuration.getboolean('Status', 'is_success_extract_squashfs', fallback=True))

    # [2] Prepare and display the new page.

    # Display original values.
    display.update_entry('existing_project_page__original_iso_image_filename_entry', model.original_iso_image_filename)
    display.update_entry('existing_project_page__original_iso_image_directory_entry', model.original_iso_image_directory)
    display.update_entry('existing_project_page__original_iso_image_volume_id_entry', model.original_iso_image_volume_id)
    display.update_entry('existing_project_page__original_iso_image_release_name_entry', model.original_iso_image_release_name)
    display.update_entry('existing_project_page__original_iso_image_disk_name_entry', model.original_iso_image_disk_name)

    display.set_sensitive('existing_project_page__original_iso_image_filepath_filechooser_open_button', True)

    # Display custom values.
    display.update_entry('existing_project_page__custom_iso_image_version_number_entry', model.custom_iso_image_version_number)
    display.update_entry('existing_project_page__custom_iso_image_filename_entry', model.custom_iso_image_filename)
    display.update_entry('existing_project_page__custom_iso_image_directory_entry', model.custom_iso_image_directory)
    display.update_entry('existing_project_page__custom_iso_image_volume_id_entry', model.custom_iso_image_volume_id)
    display.update_entry('existing_project_page__custom_iso_image_release_name_entry', model.custom_iso_image_release_name)
    display.update_entry('existing_project_page__custom_iso_image_disk_name_entry', model.custom_iso_image_disk_name)

    display.set_sensitive('existing_project_page__custom_iso_image_directory_filechooser_open_button', True)

    # Transition to the Existing Project page.
    # display.show_page('project_directory_page', 'existing_project_page')
    display.reset_buttons('existing_project_page', True, True, False)

    # [3] Perform functions on the new page, and activate the new page.

    validators.validate_existing_project_page()

    display.hide_spinner()

    model.set_propagate(True)
    '''

def transition__from__existing_project_page__to__existing_project_page_radiobutton_2(thread):

    display.set_sensitive('existing_project_page__original_iso_image_filepath_filechooser_open_button', True)
    display.reset_buttons('existing_project_page', True, True, False)
    validators.validate_existing_project_page()

    '''
    # [1] Perform functions on the current page, and deactivate the current page.

    model.set_propagate(False)
    display.show_spinner()
    display.reset_buttons('existing_project_page')

    # General
    configuration = configparser.ConfigParser()
    configuration.read(model.configuration_filepath)

    # Original
    model.set_original_iso_image_filename(configuration.get('Original', 'original_iso_image_filename'))
    model.set_original_iso_image_directory(configuration.get('Original', 'original_iso_image_directory'))
    model.set_original_iso_image_filepath(os.path.join(model.original_iso_image_directory, model.original_iso_image_filename))

    # If the iso image filepath is not mounted at the mount point, mount it. If
    # the iso image filepath has changed, the previous image will be unmounted
    # before the new image is mounted at the mount point.
    is_mounted = utilities.is_mounted(model.original_iso_image_filepath, model.original_iso_image_mount_point)
    if not is_mounted:
        # This function will unmount the existing image at the mount point.
        # This function will not mount the iso image filepath if it is invalid.
        utilities.mount_iso_image(thread, model.original_iso_image_filepath, model.original_iso_image_mount_point)
    else:
        logger.log_data('The original iso image is already mounted at', model.original_iso_image_mount_point)

    if utilities.is_mounted(model.original_iso_image_filepath, model.original_iso_image_mount_point):
        # Original
        model.set_original_iso_image_volume_id(configuration.get('Original', 'original_iso_image_volume_id'))
        model.set_original_iso_image_release_name(configuration.get('Original', 'original_iso_image_release_name'))
        model.set_original_iso_image_disk_name(configuration.get('Original', 'original_iso_image_disk_name'))

    # Custom
    model.set_custom_iso_image_version_number(configuration.get('Custom', 'custom_iso_image_version_number'))
    model.set_custom_iso_image_filename(configuration.get('Custom', 'custom_iso_image_filename'))
    model.set_custom_iso_image_directory(configuration.get('Custom', 'custom_iso_image_directory'))
    model.set_custom_iso_image_filepath(os.path.join(model.custom_iso_image_directory, model.custom_iso_image_filename))
    model.set_custom_iso_image_volume_id(configuration.get('Custom', 'custom_iso_image_volume_id'))
    model.set_custom_iso_image_release_name(configuration.get('Custom', 'custom_iso_image_release_name'))
    model.set_custom_iso_image_disk_name(configuration.get('Custom', 'custom_iso_image_disk_name'))
    model.set_custom_iso_image_md5_filename(configuration.get('Custom', 'custom_iso_image_md5_filename'))
    model.set_custom_iso_image_md5_filepath(os.path.join(model.custom_iso_image_directory, model.custom_iso_image_md5_filename))

    # Status
    # model.set_is_success_copy_original_iso_files(configuration.getboolean('Status', 'is_success_copy_original_iso_files'))
    # model.set_is_success_extract_squashfs(configuration.getboolean('Status', 'is_success_extract_squashfs'))
    model.set_is_success_copy_original_iso_files(configuration.getboolean('Status', 'is_success_copy_original_iso_files', fallback=True))
    model.set_is_success_extract_squashfs(configuration.getboolean('Status', 'is_success_extract_squashfs', fallback=True))

    # Status
    # model.set_is_success_copy_original_iso_files(configuration.getboolean('Status', 'is_success_copy_original_iso_files'))
    # model.set_is_success_extract_squashfs(configuration.getboolean('Status', 'is_success_extract_squashfs'))
    model.set_is_success_copy_original_iso_files(configuration.getboolean('Status', 'is_success_copy_original_iso_files', fallback=True))
    model.set_is_success_extract_squashfs(configuration.getboolean('Status', 'is_success_extract_squashfs', fallback=True))

    # [2] Prepare and display the new page.

    # Display original values.
    display.update_entry('existing_project_page__original_iso_image_filename_entry', model.original_iso_image_filename)
    display.update_entry('existing_project_page__original_iso_image_directory_entry', model.original_iso_image_directory)
    display.update_entry('existing_project_page__original_iso_image_volume_id_entry', model.original_iso_image_volume_id)
    display.update_entry('existing_project_page__original_iso_image_release_name_entry', model.original_iso_image_release_name)
    display.update_entry('existing_project_page__original_iso_image_disk_name_entry', model.original_iso_image_disk_name)

    display.set_sensitive('existing_project_page__original_iso_image_filepath_filechooser_open_button', True)

    # Display custom values.
    display.update_entry('existing_project_page__custom_iso_image_version_number_entry', model.custom_iso_image_version_number)
    display.update_entry('existing_project_page__custom_iso_image_filename_entry', model.custom_iso_image_filename)
    display.update_entry('existing_project_page__custom_iso_image_directory_entry', model.custom_iso_image_directory)
    display.update_entry('existing_project_page__custom_iso_image_volume_id_entry', model.custom_iso_image_volume_id)
    display.update_entry('existing_project_page__custom_iso_image_release_name_entry', model.custom_iso_image_release_name)
    display.update_entry('existing_project_page__custom_iso_image_disk_name_entry', model.custom_iso_image_disk_name)

    display.set_sensitive('existing_project_page__custom_iso_image_directory_filechooser_open_button', True)

    # Transition to the Existing Project page.
    # display.show_page('project_directory_page', 'existing_project_page')
    display.reset_buttons('existing_project_page', True, True, False)

    # [3] Perform functions on the new page, and activate the new page.

    validators.validate_existing_project_page()

    display.hide_spinner()

    model.set_propagate(True)
    '''


def transition__from__existing_project_page__to__existing_project_page_radiobutton_3(thread):

    # TODO: Consider showing the spinner, since this step may take some time.

    # [1] Perform functions on the current page, and deactivate the current page.

    model.set_propagate(False)
    display.show_spinner()
    display.reset_buttons('existing_project_page')

    # General
    configuration = configparser.ConfigParser()
    configuration.read(model.configuration_filepath)

    # Original
    model.set_original_iso_image_filename(configuration.get('Original', 'original_iso_image_filename'))
    model.set_original_iso_image_directory(configuration.get('Original', 'original_iso_image_directory'))
    model.set_original_iso_image_filepath(os.path.join(model.original_iso_image_directory, model.original_iso_image_filename))

    # If the iso image filepath is not mounted at the mount point, mount it. If
    # the iso image filepath has changed, the previous image will be unmounted
    # before the new image is mounted at the mount point.
    is_mounted = utilities.is_mounted(model.original_iso_image_filepath, model.original_iso_image_mount_point)
    if not is_mounted:
        # This function will unmount the existing image at the mount point.
        # This function will not mount the iso image filepath if it is invalid.
        utilities.mount_iso_image(thread, model.original_iso_image_filepath, model.original_iso_image_mount_point)
    else:
        logger.log_data('The original iso image is already mounted at', model.original_iso_image_mount_point)

    if utilities.is_mounted(model.original_iso_image_filepath, model.original_iso_image_mount_point):
        # Original
        model.set_original_iso_image_volume_id(configuration.get('Original', 'original_iso_image_volume_id'))
        model.set_original_iso_image_release_name(configuration.get('Original', 'original_iso_image_release_name'))
        model.set_original_iso_image_disk_name(configuration.get('Original', 'original_iso_image_disk_name'))

    # Custom
    model.set_custom_iso_image_version_number(configuration.get('Custom', 'custom_iso_image_version_number'))
    model.set_custom_iso_image_filename(configuration.get('Custom', 'custom_iso_image_filename'))
    model.set_custom_iso_image_directory(configuration.get('Custom', 'custom_iso_image_directory'))
    model.set_custom_iso_image_filepath(os.path.join(model.custom_iso_image_directory, model.custom_iso_image_filename))
    model.set_custom_iso_image_volume_id(configuration.get('Custom', 'custom_iso_image_volume_id'))
    model.set_custom_iso_image_release_name(configuration.get('Custom', 'custom_iso_image_release_name'))
    model.set_custom_iso_image_disk_name(configuration.get('Custom', 'custom_iso_image_disk_name'))
    model.set_custom_iso_image_md5_filename(configuration.get('Custom', 'custom_iso_image_md5_filename'))
    model.set_custom_iso_image_md5_filepath(os.path.join(model.custom_iso_image_directory, model.custom_iso_image_md5_filename))

    # Status
    # model.set_is_success_copy_original_iso_files(configuration.getboolean('Status', 'is_success_copy_original_iso_files'))
    # model.set_is_success_extract_squashfs(configuration.getboolean('Status', 'is_success_extract_squashfs'))
    model.set_is_success_copy_original_iso_files(configuration.getboolean('Status', 'is_success_copy_original_iso_files', fallback=True))
    model.set_is_success_extract_squashfs(configuration.getboolean('Status', 'is_success_extract_squashfs', fallback=True))

    # Status
    # model.set_is_success_copy_original_iso_files(configuration.getboolean('Status', 'is_success_copy_original_iso_files'))
    # model.set_is_success_extract_squashfs(configuration.getboolean('Status', 'is_success_extract_squashfs'))
    model.set_is_success_copy_original_iso_files(configuration.getboolean('Status', 'is_success_copy_original_iso_files', fallback=True))
    model.set_is_success_extract_squashfs(configuration.getboolean('Status', 'is_success_extract_squashfs', fallback=True))

    # [2] Prepare and display the new page.

    # Display original values.
    display.update_entry('existing_project_page__original_iso_image_filename_entry', model.original_iso_image_filename)
    display.update_entry('existing_project_page__original_iso_image_directory_entry', model.original_iso_image_directory)
    display.update_entry('existing_project_page__original_iso_image_volume_id_entry', model.original_iso_image_volume_id)
    display.update_entry('existing_project_page__original_iso_image_release_name_entry', model.original_iso_image_release_name)
    display.update_entry('existing_project_page__original_iso_image_disk_name_entry', model.original_iso_image_disk_name)

    display.set_sensitive('existing_project_page__original_iso_image_filepath_filechooser_open_button', False)

    # Display custom values.
    display.update_entry('existing_project_page__custom_iso_image_version_number_entry', model.custom_iso_image_version_number)
    display.update_entry('existing_project_page__custom_iso_image_filename_entry', model.custom_iso_image_filename)
    display.update_entry('existing_project_page__custom_iso_image_directory_entry', model.custom_iso_image_directory)
    display.update_entry('existing_project_page__custom_iso_image_volume_id_entry', model.custom_iso_image_volume_id)
    display.update_entry('existing_project_page__custom_iso_image_release_name_entry', model.custom_iso_image_release_name)
    display.update_entry('existing_project_page__custom_iso_image_disk_name_entry', model.custom_iso_image_disk_name)

    # display.set_sensitive('existing_project_page__custom_iso_image_directory_filechooser_open_button', False)

    # Transition to the Existing Project page.
    # display.show_page('project_directory_page', 'existing_project_page')
    display.reset_buttons('existing_project_page', True, True, False)

    # [3] Perform functions on the new page, and activate the new page.

    validators.validate_existing_project_page_for_delete()

    display.hide_spinner()

    model.set_propagate(True)


def transition__from__existing_project_page__to__manage_linux_kernels_page(thread):
    # [1] Perform functions on the current page, and deactivate the current page.

    display.show_spinner()
    display.reset_buttons('existing_project_page')

    # Read old values from the configuration before overwriting them.
    configuration = configparser.ConfigParser()
    configuration.read(model.configuration_filepath)
    saved_original_iso_image_filepath = os.path.join(configuration.get('Original', 'original_iso_image_directory'), configuration.get('Original', 'original_iso_image_filename'))
    logger.log_data('The original iso image file path is', model.original_iso_image_filepath)
    logger.log_data('The original iso image file path in the configuration is', saved_original_iso_image_filepath)
    if model.original_iso_image_filepath != saved_original_iso_image_filepath:
        model.is_success_copy_original_iso_files = False

    # Save the configuration (since it may have changed).
    utilities.save_configuration()

    # Decide to transition to the Manage Linux Kernels Page page or remain on the Unsquashfs page.
    if model.is_success_copy_original_iso_files and model.is_success_extract_squashfs:

        # Transition to the Manage Linux Kernels page.

        # [1] Perform functions on the current page, and deactivate the current page.

        # Get the list of linux kernels.
        # .../squashfs-root/boot/vmlinuz-*; initrd.img-*
        directory_1 = os.path.join(model.custom_squashfs_directory, 'boot')
        # .../original-iso-mount/casper/vmlinuz.efi; initrd.lz
        directory_2 = os.path.join(model.original_iso_image_mount_point, 'casper')
        vmlinuz_version_details_list = utilities.create_vmlinuz_version_details_list(directory_1, directory_2)

        # [2] Prepare and display the new page.

        # TODO: See if this code can be replaced with elements in cubic.ui
        # REFERENCE: https://whyareyoureadingthisurl.wordpress.com/2012/01/21/howto-pack-gtk-cellrenderers-vertically-in-a-gtk-treeview/
        import gi
        gi.require_version('Gtk', '3.0')
        from gi.repository import Gtk
        column = model.builder.get_object('manage_linux_kernels_page__filename_treeviewcolumn_2')
        area = column.get_area()
        area.set_orientation(Gtk.Orientation.VERTICAL)

        display.update_liststore('manage_linux_kernels_page__kernel_details_liststore', vmlinuz_version_details_list)

        # Transition to the Manage Linux Kernels page.
        display.show_page('existing_project_page', 'manage_linux_kernels_page')
        display.reset_buttons('manage_linux_kernels_page', True, True, True)

        # [3] Perform functions on the new page, and activate the new page.

        display.hide_spinner()

    else:

        # Transition to the Unsquashfs page.

        # [1] Perform functions on the current page, and deactivate the current page.

        # [2] Prepare and display the new page.

        # Setup the Copy Original Iso Files section.
        if not model.is_success_copy_original_iso_files:
            if model.original_iso_image_filepath == saved_original_iso_image_filepath:
                display.update_label('unsquashfs_page__copy_original_iso_files_label', 'Copy iso files from the original disk image:')
            else:
                display.update_label('unsquashfs_page__copy_original_iso_files_label', 'Copy iso files from the new original disk image:')
            display.update_label('unsquashfs_page__copy_original_iso_files_original_disk_image_label', '%s' % model.original_iso_image_filepath)
            display.update_progressbar_percent('unsquashfs_page__copy_original_iso_files_progressbar', 0)
            display.update_progressbar_text('unsquashfs_page__copy_original_iso_files_progressbar', '')
            display.set_label_error('unsquashfs_page__copy_original_iso_files_result_label', False)
            display.update_label('unsquashfs_page__copy_original_iso_files_result_label', '...')
            display.set_visible('unsquashfs_page__copy_original_iso_files_spinner', False)
            display.update_status('unsquashfs_page__unsquashfs', 'bullet')
            display.set_visible('unsquashfs_page__grid_02', True)
        else:
            display.set_visible('unsquashfs_page__grid_02', False)

        # Setup the Unsquashfs section.
        if not model.is_success_extract_squashfs:
            display.update_label('unsquashfs_page__unsquashfs_original_disk_image_label', '%s' % model.original_iso_image_filepath)
            display.update_progressbar_percent('unsquashfs_page__unsquashfs_progressbar', 0)
            display.update_progressbar_text('unsquashfs_page__unsquashfs_progressbar', '')
            display.set_label_error('unsquashfs_page__unsquashfs_result_label', False)
            display.update_label('unsquashfs_page__unsquashfs_result_label', '...')
            display.set_visible('unsquashfs_page__unsquashfs_spinner', False)
            display.update_status('unsquashfs_page__unsquashfs', 'bullet')
            display.set_visible('unsquashfs_page__grid_03', True)
        else:
            display.set_visible('unsquashfs_page__grid_03', False)

        # Transition to the Unsquashfs page.
        display.show_page('existing_project_page', 'unsquashfs_page')
        display.reset_buttons('unsquashfs_page', True, True, False)

        # [3] Perform functions on the new page, and activate the new page.

        display.hide_spinner()

        # Perform actions in the Copy Original Iso Files section.
        if not model.is_success_copy_original_iso_files:
            display.update_status('unsquashfs_page__copy_original_iso_files', 'processing')
            time.sleep(0.25)

            # Copy original iso files.
            utilities.copy_original_iso_files(thread, False)
            # TODO: Check for result and set success value, message, and color accordingly.
            model.set_is_success_copy_original_iso_files(True)
            display.update_label('unsquashfs_page__copy_original_iso_files_result_label', 'All original iso files have been copied.')
            display.update_status('unsquashfs_page__copy_original_iso_files', 'check')
            time.sleep(0.25)

        # Perform actions in the Unsquashfs section.
        if not model.is_success_extract_squashfs:
            display.update_status('unsquashfs_page__unsquashfs', 'processing')
            time.sleep(0.25)

            # Extract filesystem.squashfs.
            utilities.extract_squashfs(thread)
            # TODO: Check for result and set success value, message, and color accordingly.
            model.set_is_success_extract_squashfs(True)
            display.update_label('unsquashfs_page__unsquashfs_result_label', 'The compressed Linux file system has been extracted.')
            display.update_status('unsquashfs_page__unsquashfs', 'check')
            time.sleep(0.25)

        # Save the configuration (since it may have changed).
        utilities.save_configuration()

        # Decide to transition to the Manage Linux Kernels Page page or remain on the Unsquashfs page.
        if model.is_success_copy_original_iso_files and model.is_success_extract_squashfs:

            # Transition to the Manage Linux Kernels page.

            # [1] Perform functions on the current page, and deactivate the current page.

            # Get the list of linux kernels.
            # .../squashfs-root/boot/vmlinuz-*; initrd.img-*
            directory_1 = os.path.join(model.custom_squashfs_directory, 'boot')
            # .../original-iso-mount/casper/vmlinuz.efi; initrd.lz
            directory_2 = os.path.join(model.original_iso_image_mount_point, 'casper')
            vmlinuz_version_details_list = utilities.create_vmlinuz_version_details_list(directory_1, directory_2)

            # [2] Prepare and display the new page.

            # TODO: See if this code can be replaced with elements in cubic.ui
            # REFERENCE: https://whyareyoureadingthisurl.wordpress.com/2012/01/21/howto-pack-gtk-cellrenderers-vertically-in-a-gtk-treeview/
            import gi
            gi.require_version('Gtk', '3.0')
            from gi.repository import Gtk
            column = model.builder.get_object('manage_linux_kernels_page__filename_treeviewcolumn_2')
            area = column.get_area()
            area.set_orientation(Gtk.Orientation.VERTICAL)

            display.update_liststore('manage_linux_kernels_page__kernel_details_liststore', vmlinuz_version_details_list)

            # Transition to the Manage Linux Kernels page.
            display.show_page('existing_project_page', 'manage_linux_kernels_page')
            display.reset_buttons('manage_linux_kernels_page', True, True, True)

            # [3] Perform functions on the new page, and activate the new page.

            display.hide_spinner()

        else:

            # Stay on the  the Unsquashfs page.

            # [1] Perform functions on the current page, and deactivate the current page.

            # [2] Prepare and display the new page.

            display.reset_buttons('unsquashfs_page', True, True, False)

            # [3] Perform functions on the new page, and activate the new page.


def transition__from__existing_project_page__to__terminal_page(thread):
    # [1] Perform functions on the current page, and deactivate the current page.

    display.show_spinner()
    display.reset_buttons('existing_project_page')

    # Read old values from the configuration before overwriting them.
    configuration = configparser.ConfigParser()
    configuration.read(model.configuration_filepath)
    saved_original_iso_image_filepath = os.path.join(configuration.get('Original', 'original_iso_image_directory'), configuration.get('Original', 'original_iso_image_filename'))
    logger.log_data('The original iso image file path is', model.original_iso_image_filepath)
    logger.log_data('The original iso image file path in the configuration is', saved_original_iso_image_filepath)
    if model.original_iso_image_filepath != saved_original_iso_image_filepath:
        model.is_success_copy_original_iso_files = False

    # Save the configuration (since it may have changed).
    utilities.save_configuration()

    # Decide to transition to the Terminal page or remain on the Unsquashfs page.
    if model.is_success_copy_original_iso_files and model.is_success_extract_squashfs:

        # Transition to the Terminal page.

        # [1] Perform functions on the current page, and deactivate the current page.

        # Prepare the chroot terminal.
        utilities.prepare_chroot_environment(thread)
        utilities.enter_chroot_environment(thread)

        # [2] Prepare and display the new page.

        display.set_visible('terminal_page__exit_terminal_label', False)

        # Transition to the Terminal page.
        display.show_page('existing_project_page', 'terminal_page')
        display.reset_buttons('terminal_page', True, True, True)

        # [3] Perform functions on the new page, and activate the new page.

        utilities.check_chroot_environment(thread)
        display.hide_spinner()

    else:

        # Transition to the Unsquashfs page.

        # [1] Perform functions on the current page, and deactivate the current page.

        # [2] Prepare and display the new page.

        # Setup the Copy Original Iso Files section.
        if not model.is_success_copy_original_iso_files:
            if model.original_iso_image_filepath == saved_original_iso_image_filepath:
                display.update_label('unsquashfs_page__copy_original_iso_files_label', 'Copy iso files from the original disk image:')
            else:
                display.update_label('unsquashfs_page__copy_original_iso_files_label', 'Copy iso files from the new original disk image:')
            display.update_label('unsquashfs_page__copy_original_iso_files_original_disk_image_label', '%s' % model.original_iso_image_filepath)
            display.update_progressbar_percent('unsquashfs_page__copy_original_iso_files_progressbar', 0)
            display.update_progressbar_text('unsquashfs_page__copy_original_iso_files_progressbar', '')
            display.set_label_error('unsquashfs_page__copy_original_iso_files_result_label', False)
            display.update_label('unsquashfs_page__copy_original_iso_files_result_label', '...')
            display.set_visible('unsquashfs_page__copy_original_iso_files_spinner', False)
            display.update_status('unsquashfs_page__unsquashfs', 'bullet')
            display.set_visible('unsquashfs_page__grid_02', True)
        else:
            display.set_visible('unsquashfs_page__grid_02', False)

        # Setup the Unsquashfs section.
        if not model.is_success_extract_squashfs:
            display.update_label('unsquashfs_page__unsquashfs_original_disk_image_label', '%s' % model.original_iso_image_filepath)
            display.update_progressbar_percent('unsquashfs_page__unsquashfs_progressbar', 0)
            display.update_progressbar_text('unsquashfs_page__unsquashfs_progressbar', '')
            display.set_label_error('unsquashfs_page__unsquashfs_result_label', False)
            display.update_label('unsquashfs_page__unsquashfs_result_label', '...')
            display.set_visible('unsquashfs_page__unsquashfs_spinner', False)
            display.update_status('unsquashfs_page__unsquashfs', 'bullet')
            display.set_visible('unsquashfs_page__grid_03', True)
        else:
            display.set_visible('unsquashfs_page__grid_03', False)

        # Transition to the Unsquashfs page.
        display.show_page('existing_project_page', 'unsquashfs_page')
        display.reset_buttons('unsquashfs_page', True, True, False)

        # [3] Perform functions on the new page, and activate the new page.

        display.hide_spinner()

        # Perform actions in the Copy Original Iso Files section.
        if not model.is_success_copy_original_iso_files:
            display.update_status('unsquashfs_page__copy_original_iso_files', 'processing')
            time.sleep(0.25)

            # Copy original iso files.
            utilities.copy_original_iso_files(thread, False)
            # TODO: Check for result and set success value, message, and color accordingly.
            model.set_is_success_copy_original_iso_files(True)
            display.update_label('unsquashfs_page__copy_original_iso_files_result_label', 'All original iso files have been copied.')
            display.update_status('unsquashfs_page__copy_original_iso_files', 'check')
            time.sleep(0.25)

        # Perform actions in the Unsquashfs section.
        if not model.is_success_extract_squashfs:
            display.update_status('unsquashfs_page__unsquashfs', 'processing')
            time.sleep(0.25)

            # Extract filesystem.squashfs.
            utilities.extract_squashfs(thread)
            # TODO: Check for result and set success value, message, and color accordingly.
            model.set_is_success_extract_squashfs(True)
            display.update_label('unsquashfs_page__unsquashfs_result_label', 'The compressed Linux file system has been extracted.')
            display.update_status('unsquashfs_page__unsquashfs', 'check')
            time.sleep(0.25)

        # Save the configuration (since it may have changed).
        utilities.save_configuration()

        # Decide to transition to the Terminal page or remain on the Unsquashfs page.
        if model.is_success_copy_original_iso_files and model.is_success_extract_squashfs:

            # Transition to the Terminal page.

            # [1] Perform functions on the current page, and deactivate the current page.

            # Pause to let the user read the screen before automatic transition.
            time.sleep(1.00)
            display.show_spinner()
            display.reset_buttons('unsquashfs_page')

            # Prepare the chroot terminal.
            utilities.prepare_chroot_environment(thread)
            utilities.enter_chroot_environment(thread)

            # [2] Prepare and display the new page.

            display.set_visible('terminal_page__exit_terminal_label', False)

            # Transition to the Terminal page.
            display.show_page('unsquashfs_page', 'terminal_page')
            display.reset_buttons('terminal_page', True, True, True)

            # [3] Perform functions on the new page, and activate the new page.

            utilities.check_chroot_environment(thread)
            display.hide_spinner()

        else:

            # Stay on the  the Unsquashfs page.

            # [1] Perform functions on the current page, and deactivate the current page.

            # [2] Prepare and display the new page.

            display.reset_buttons('unsquashfs_page', True, True, False)

            # [3] Perform functions on the new page, and activate the new page.


def transition__from__existing_project_page__to__delete_project_page(thread):
    # [1] Perform functions on the current page, and deactivate the current page.

    display.show_spinner()
    display.reset_buttons('existing_project_page')

    # [2] Prepare and display the new page.

    if os.path.exists(model.configuration_filepath):
        display.update_status('delete_project_page__configuration_file', 'bullet')
        display.set_visible('delete_project_page__configuration_file_status', True)
        display.set_visible('delete_project_page__configuration_file_description', True)
        display.set_visible('delete_project_page__configuration_file_spinner', False)
    else:
        display.update_status('delete_project_page__configuration_file', 'bullet')
        display.set_visible('delete_project_page__configuration_file_status', True)
        display.set_visible('delete_project_page__configuration_file_description', True)
        display.set_visible('delete_project_page__configuration_file_spinner', False)
    if os.path.exists(model.original_iso_image_mount_point):
        display.update_status('delete_project_page__original_iso_image_mount_point', 'bullet')
        display.set_visible('delete_project_page__original_iso_image_mount_point_status', True)
        display.set_visible('delete_project_page__original_iso_image_mount_point_description', True)
        display.set_visible('delete_project_page__original_iso_image_mount_point_spinner', False)
    else:
        display.update_status('delete_project_page__original_iso_image_mount_point', 'bullet')
        display.set_visible('delete_project_page__original_iso_image_mount_point_status', False)
        display.set_visible('delete_project_page__original_iso_image_mount_point_description', False)
        display.set_visible('delete_project_page__original_iso_image_mount_point_spinner', False)
    if os.path.exists(model.custom_squashfs_directory):
        display.update_status('delete_project_page__custom_squashfs_directory', 'bullet')
        display.set_visible('delete_project_page__custom_squashfs_directory_status', True)
        display.set_visible('delete_project_page__custom_squashfs_directory_description', True)
        display.set_visible('delete_project_page__custom_squashfs_directory_spinner', False)
    else:
        display.update_status('delete_project_page__custom_squashfs_directory', 'bullet')
        display.set_visible('delete_project_page__custom_squashfs_directory_status', False)
        display.set_visible('delete_project_page__custom_squashfs_directory_description', False)
        display.set_visible('delete_project_page__custom_squashfs_directory_spinner', False)
    if os.path.exists(model.custom_live_iso_directory):
        display.update_status('delete_project_page__custom_live_iso_directory', 'bullet')
        display.set_visible('delete_project_page__custom_live_iso_directory_status', True)
        display.set_visible('delete_project_page__custom_live_iso_directory_description', True)
        display.set_visible('delete_project_page__custom_live_iso_directory_spinner', False)
    else:
        display.update_status('delete_project_page__custom_live_iso_directory', 'bullet')
        display.set_visible('delete_project_page__custom_live_iso_directory_status', False)
        display.set_visible('delete_project_page__custom_live_iso_directory_description', False)
        display.set_visible('delete_project_page__custom_live_iso_directory_spinner', False)

    # Only delete the custom iso image if it is directly under the project directory.
    filepath = os.path.join(model.project_directory, model.custom_iso_image_filename)
    if os.path.exists(filepath):
        display.update_status('delete_project_page__custom_iso_image_filename', 'bullet')
        display.set_visible('delete_project_page__custom_iso_image_filename_status', True)
        display.set_visible('delete_project_page__custom_iso_image_filename_description', True)
        display.set_visible('delete_project_page__custom_iso_image_filename_spinner', False)
        display.set_visible('delete_project_page__grid_03', True)
        display.update_label('delete_project_page__custom_iso_image_filename_label', model.custom_iso_image_filepath)
        # display.set_visible('delete_project_page__custom_iso_image_filename_label', True)
        # display.set_visible('delete_project_page__custom_iso_image_filename_instructions', True)
    else:
        display.update_status('delete_project_page__custom_iso_image_filename', 'bullet')
        display.set_visible('delete_project_page__custom_iso_image_filename_status', False)
        display.set_visible('delete_project_page__custom_iso_image_filename_description', False)
        display.set_visible('delete_project_page__custom_iso_image_filename_spinner', False)
        display.set_visible('delete_project_page__grid_03', False)
        display.update_label('delete_project_page__custom_iso_image_filename_label', '...')
        # display.set_visible('delete_project_page__custom_iso_image_filename_label', False)
        # display.set_visible('delete_project_page__custom_iso_image_filename_instructions', False)

    # Only delete the custom iso image MD5 file if it is directly under the project directory.
    filepath = os.path.join(model.project_directory, model.custom_iso_image_md5_filename)
    if os.path.exists(filepath):
        display.update_status('delete_project_page__custom_iso_image_md5_filename', 'bullet')
        display.set_visible('delete_project_page__custom_iso_image_md5_filename_status', True)
        display.set_visible('delete_project_page__custom_iso_image_md5_filename_description', True)
        display.set_visible('delete_project_page__custom_iso_image_md5_filename_spinner', False)
        display.set_visible('delete_project_page__grid_04', True)
        display.update_label('delete_project_page__custom_iso_image_md5_filename_label', model.custom_iso_image_md5_filepath)
        # display.set_visible('delete_project_page__custom_iso_image_md5_filename_label', True)
        # display.set_visible('delete_project_page__custom_iso_image_md5_filename_instructions', True)
    else:
        display.update_status('delete_project_page__custom_iso_image_md5_filename', 'bullet')
        display.set_visible('delete_project_page__custom_iso_image_md5_filename_status', False)
        display.set_visible('delete_project_page__custom_iso_image_md5_filename_description', False)
        display.set_visible('delete_project_page__custom_iso_image_md5_filename_spinner', False)
        display.set_visible('delete_project_page__grid_04', False)
        display.update_label('delete_project_page__custom_iso_image_md5_filename_label', '...')
        # display.set_visible('delete_project_page__custom_iso_image_md5_filename_label', False)
        # display.set_visible('delete_project_page__custom_iso_image_md5_filename_instructions', False)

    # Transition to the Delete Project page.
    display.show_page('existing_project_page', 'delete_project_page')
    display.reset_buttons('delete_project_page', True, True, True)

    # [3] Perform functions on the new page, and activate the new page.
    display.hide_spinner()


#
# Confirm Delete Project Page
#

def transition__from__delete_project_page__to__new_project_page(thread):
    # [1] Perform functions on the current page, and deactivate the current page.

    model.set_propagate(False)
    display.reset_buttons('delete_project_page', True, False, False)

    # TODO: Add checks if delete actions were successful.
    if os.path.exists(model.configuration_filepath):

        display.update_status('delete_project_page__configuration_file', 'processing')
        display.set_visible('delete_project_page__configuration_file_status', True)
        display.set_visible('delete_project_page__configuration_file_description', True)
        display.set_visible('delete_project_page__configuration_file_spinner', True)
        time.sleep(0.25)

        # Delete file, cubic.conf.
        logger.log_data('About to delete configuration file', model.configuration_filepath)
        utilities.delete_file(thread, model.configuration_filepath)
        display.update_status('delete_project_page__configuration_file', 'check')
        time.sleep(0.25)

    else:

        display.update_status('delete_project_page__configuration_file', 'bullet')
        display.set_visible('delete_project_page__configuration_file_status', False)
        display.set_visible('delete_project_page__configuration_file_description', False)
        display.set_visible('delete_project_page__configuration_file_spinner', False)

    if os.path.exists(model.original_iso_image_mount_point):

        display.update_status('delete_project_page__original_iso_image_mount_point', 'processing')
        display.set_visible('delete_project_page__original_iso_image_mount_point_status', True)
        display.set_visible('delete_project_page__original_iso_image_mount_point_description', True)
        display.set_visible('delete_project_page__original_iso_image_mount_point_spinner', True)
        time.sleep(0.25)

        # Unmount the original iso image and delete the mount point.
        logger.log_data('About to delete original iso image mount point', model.original_iso_image_mount_point)
        utilities.delete_iso_mount(thread, model.original_iso_image_mount_point)
        display.update_status('delete_project_page__original_iso_image_mount_point', 'check')
        time.sleep(0.25)

    else:

        display.update_status('delete_project_page__original_iso_image_mount_point', 'bullet')
        display.set_visible('delete_project_page__original_iso_image_mount_point_status', False)
        display.set_visible('delete_project_page__original_iso_image_mount_point_description', False)
        display.set_visible('delete_project_page__original_iso_image_mount_point_spinner', False)

    if os.path.exists(model.custom_squashfs_directory):

        display.update_status('delete_project_page__custom_squashfs_directory', 'processing')
        time.sleep(0.25)
        display.set_visible('delete_project_page__custom_squashfs_directory_status', True)
        display.set_visible('delete_project_page__custom_squashfs_directory_description', True)
        display.set_visible('delete_project_page__custom_squashfs_directory_spinner', True)

        # Delete directory, squashfs-root.
        logger.log_data('About to delete custom squashfs directory', model.custom_squashfs_directory)
        utilities.delete_file(thread, model.custom_squashfs_directory)
        display.update_status('delete_project_page__custom_squashfs_directory', 'check')
        time.sleep(0.25)

    else:

        display.update_status('delete_project_page__custom_squashfs_directory', ', ''bullet')
        display.set_visible('delete_project_page__custom_squashfs_directory_status', False)
        display.set_visible('delete_project_page__custom_squashfs_directory_description', False)
        display.set_visible('delete_project_page__custom_squashfs_directory_spinner', False)

    if os.path.exists(model.custom_live_iso_directory):
        display.update_status('delete_project_page__custom_live_iso_directory', 'processing')
        display.set_visible('delete_project_page__custom_live_iso_directory_status', True)
        display.set_visible('delete_project_page__custom_live_iso_directory_description', True)
        display.set_visible('delete_project_page__custom_live_iso_directory_spinner', True)
        time.sleep(0.25)

        # Delete directory, custom-live-iso.
        logger.log_data('About to delete custom live iso directory', model.custom_live_iso_directory)
        utilities.delete_file(thread, model.custom_live_iso_directory)
        display.update_status('delete_project_page__custom_live_iso_directory', 'check')
        time.sleep(0.25)

    else:

        display.update_status('delete_project_page__custom_live_iso_directory', 'bullet')
        display.set_visible('delete_project_page__custom_live_iso_directory_status', False)
        display.set_visible('delete_project_page__custom_live_iso_directory_description', False)
        display.set_visible('delete_project_page__custom_live_iso_directory_spinner', False)

    # Only delete the custom iso image if it is directly under the project directory.
    filepath = os.path.join(model.project_directory, model.custom_iso_image_filename)
    if os.path.exists(filepath):

        display.update_status('delete_project_page__custom_iso_image_filename', 'processing')
        display.set_visible('delete_project_page__custom_iso_image_filename_status', True)
        display.set_visible('delete_project_page__custom_iso_image_filename_description', True)
        display.set_visible('delete_project_page__custom_iso_image_filename_spinner', True)
        display.set_visible('delete_project_page__grid_03', True)
        display.update_label('delete_project_page__custom_iso_image_filename_label', model.custom_iso_image_filepath)
        # display.set_visible('delete_project_page__custom_iso_image_filename_label', True)
        # display.set_visible('delete_project_page__custom_iso_image_filename_instructions', True)
        time.sleep(0.25)

        # Delete file, *.iso.
        logger.log_data('About to delete custom iso image file', filepath)
        utilities.delete_file(thread, filepath)
        display.update_status('delete_project_page__custom_iso_image_filename', 'check')
        time.sleep(0.25)

    else:

        display.update_status('delete_project_page__custom_iso_image_filename', 'bullet')
        display.set_visible('delete_project_page__custom_iso_image_filename_status', False)
        display.set_visible('delete_project_page__custom_iso_image_filename_description', False)
        display.set_visible('delete_project_page__custom_iso_image_filename_spinner', False)
        display.set_visible('delete_project_page__grid_03', False)
        display.update_label('delete_project_page__custom_iso_image_filename_label', '')
        # display.set_visible('delete_project_page__custom_iso_image_filename_label', False)
        # display.set_visible('delete_project_page__custom_iso_image_filename_instructions', False)
        time.sleep(0.25)

    # Only delete the MD5 file if it is directly under the project directory.
    filepath = os.path.join(model.project_directory, model.custom_iso_image_md5_filename)
    if os.path.exists(filepath):

        display.update_status('delete_project_page__custom_iso_image_md5_filename', 'processing')
        display.set_visible('delete_project_page__custom_iso_image_md5_filename_status', True)
        display.set_visible('delete_project_page__custom_iso_image_md5_filename_description', True)
        display.set_visible('delete_project_page__custom_iso_image_md5_filename_spinner', True)
        display.set_visible('delete_project_page__grid_04', True)
        display.update_label('delete_project_page__custom_iso_image_md5_filename_label', model.custom_iso_image_md5_filepath)
        # display.set_visible('delete_project_page__custom_iso_image_md5_filename_label', True)
        # display.set_visible('delete_project_page__custom_iso_image_md5_filename_instructions', True)
        time.sleep(0.25)

        # Delete file, *.md5.
        logger.log_data('About to delete custom iso image MD5 file', filepath)
        utilities.delete_file(thread, filepath)
        display.update_status('delete_project_page__custom_iso_image_md5_filename', 'check')
        time.sleep(0.25)

    else:

        display.update_status('delete_project_page__custom_iso_image_md5_filename', 'bullet')
        display.set_visible('delete_project_page__custom_iso_image_md5_filename_status', False)
        display.set_visible('delete_project_page__custom_iso_image_md5_filename_description', False)
        display.set_visible('delete_project_page__custom_iso_image_md5_filename_spinner', False)
        display.set_visible('delete_project_page__grid_04', False)
        display.update_label('delete_project_page__custom_iso_image_md5_filename_label', '')
        # display.set_visible('delete_project_page__custom_iso_image_md5_filename_label', False)
        # display.set_visible('delete_project_page__custom_iso_image_md5_filename_instructions', False)
        time.sleep(0.25)

    # Reset all global variables before transitioning to new project page.
    display.show_spinner()
    display.reset_buttons('delete_project_page')

    # Original
    model.set_original_iso_image_filepath('')  # Aggregated value; not displayed.
    model.set_original_iso_image_filename('')
    model.set_original_iso_image_directory('')
    model.set_original_iso_image_volume_id('')
    model.set_original_iso_image_release_name('')
    model.set_original_iso_image_disk_name('')

    # Custom
    model.set_custom_iso_image_version_number('')
    model.set_custom_iso_image_filename('')
    model.set_custom_iso_image_directory('')
    model.set_custom_iso_image_filepath('')  # Aggregated value; not displayed.
    model.set_custom_iso_image_volume_id('')
    model.set_custom_iso_image_release_name('')
    model.set_custom_iso_image_disk_name('')

    # Status
    model.set_is_success_copy_original_iso_files(False)
    model.set_is_success_extract_squashfs(False)

    # [2] Prepare and display the new page.

    # Display original values.
    display.update_entry('new_project_page__original_iso_image_filename_entry', model.original_iso_image_filename)
    display.update_entry('new_project_page__original_iso_image_directory_entry', model.original_iso_image_directory)
    display.update_entry('new_project_page__original_iso_image_volume_id_entry', model.original_iso_image_volume_id)
    display.update_entry('new_project_page__original_iso_image_release_name_entry', model.original_iso_image_release_name)
    display.update_entry('new_project_page__original_iso_image_disk_name_entry', model.original_iso_image_disk_name)

    # Display custom values.
    display.update_entry('new_project_page__custom_iso_image_version_number_entry', model.custom_iso_image_version_number)
    display.update_entry('new_project_page__custom_iso_image_filename_entry', model.custom_iso_image_filename)
    display.update_entry('new_project_page__custom_iso_image_directory_entry', model.custom_iso_image_directory)
    display.update_entry('new_project_page__custom_iso_image_volume_id_entry', model.custom_iso_image_volume_id)
    display.update_entry('new_project_page__custom_iso_image_release_name_entry', model.custom_iso_image_release_name)
    display.update_entry('new_project_page__custom_iso_image_disk_name_entry', model.custom_iso_image_disk_name)

    # Activate radio button 2 as the default option (continue customizing the
    # existing project) when the existing project page is displayed.
    # The handler on_toggled__existing_project_page__radiobutton() is called
    # whenever the radiobutton is toggled; however the function will not
    # execute, because model.propagate is False.
    display.activate_radiobutton('existing_project_page__radiobutton_2', True)

    # Transition to the Delete Project page.
    display.show_page('delete_project_page', 'new_project_page')
    display.reset_buttons('new_project_page', True, True, False)

    # [3] Perform functions on the new page, and activate the new page.

    validators.validate_new_project_page()

    display.hide_spinner()

    model.set_propagate(True)


#
# Unsquashfs Page
#
#
# TODO: This transition is automatic, so this section is not used.
#
# def transition__from__unsquashfs_page__to__terminal_page(thread):
#
#    # [1] Perform functions on the current page, and deactivate the current page.
#
#    display.show_spinner()
#    display.reset_buttons('unsquashfs_page')
#
#    # Save the configuration (since it may have changed).
#    utilities.save_configuration()
#
#    # Prepare the chroot terminal.
#    utilities.prepare_chroot_environment(thread)
#    utilities.enter_chroot_environment(thread)
#
#    # [2] Prepare and display the new page.
#
#    display.set_visible('terminal_page__exit_terminal_label', False)
#
#    # Transition to the Unsquashfs page.
#    display.show_page('unsquashfs_page', 'terminal_page')
#    display.reset_buttons('terminal_page', True, True, True)
#
#    # [3] Perform functions on the new page, and activate the new page.
#
#    utilities.check_chroot_environment(thread)
#    display.hide_spinner()


#
# Terminal Page
#

def transition__from__terminal_page__to__manage_linux_kernels_page(thread):
    # [1] Perform functions on the current page, and deactivate the current page.

    display.show_spinner()
    display.reset_buttons('terminal_page')

    # Exit the chroot environment.
    utilities.exit_chroot_environment(thread)

    # Get the list of linux kernels.
    # .../squashfs-root/boot/vmlinuz-*; initrd.img-*
    directory_1 = os.path.join(model.custom_squashfs_directory, 'boot')
    # .../original-iso-mount/casper/vmlinuz.efi; initrd.lz
    directory_2 = os.path.join(model.original_iso_image_mount_point, 'casper')
    vmlinuz_version_details_list = utilities.create_vmlinuz_version_details_list(directory_1, directory_2)

    # [2] Prepare and display the new page.

    # TODO: # TODO: See if this code can be replaced with elements in cubic.ui
    # REFERENCE: https://whyareyoureadingthisurl.wordpress.com/2012/01/21/howto-pack-gtk-cellrenderers-vertically-in-a-gtk-treeview/
    import gi
    gi.require_version('Gtk', '3.0')
    from gi.repository import Gtk
    column = model.builder.get_object('manage_linux_kernels_page__filename_treeviewcolumn_2')
    area = column.get_area()
    area.set_orientation(Gtk.Orientation.VERTICAL)

    display.update_liststore('manage_linux_kernels_page__kernel_details_liststore', vmlinuz_version_details_list)

    # Transition to the Manage Linux Kernels page.
    display.show_page('terminal_page', 'manage_linux_kernels_page')
    display.reset_buttons('manage_linux_kernels_page', True, True, True)

    # [3] Perform functions on the new page, and activate the new page.

    display.hide_spinner()


# TODO: When you exit from the copy files page, exit chroot also!
def transition__from__terminal_page__to__copy_files_page(thread):
    # [1] Perform functions on the current page, and deactivate the current page.

    display.show_spinner()
    display.reset_buttons('terminal_page')
    # Exit the chroot environment.
    # logger.log_step('Exit the chroot environment')
    # utilities.exit_chroot_environment(thread)

    # Create a file details list of files to be copied.
    file_details_list = utilities.create_file_details_list()

    # [2] Prepare and display the new page.

    display.set_sensitive('copy_files_page__scrolled_window', False)
    display.reset_buttons('copy_files_page', True, True, False)
    display.update_progressbar_text('copy_files_page__copy_files_progressbar', None)
    display.update_progressbar_percent('copy_files_page__copy_files_progressbar', 0)
    display.update_liststore('copy_files_page__file_details_liststore', file_details_list)

    # Transition to the Copy Files page.
    display.show_page('terminal_page', 'copy_files_page')
    display.set_sensitive('copy_files_page__scrolled_window', True)

    # [3] Perform functions on the new page, and activate the new page.

    display.hide_spinner()
    display.reset_buttons('copy_files_page', True, True, True)


#
# Confirm Copy Page
#

# TODO: Consider converting to (page, function) instead of (page, page)
# For example,...
# (1) transition__from__copy_files_page__to__terminal_page_copy_files()
#     - Copy files first, then automatically transition to terminal page.
# (2) transition__from__copy_files_page__to__terminal_page_cancel_copy_files()
#     - Do not Copy files; automatically transition to terminal page.

def transition__from__copy_files_page__to__terminal_page_copy_files(thread):
    # [1] Perform functions on the current page, and deactivate the current page.

    display.reset_buttons('copy_files_page', True, True, False)

    # Copy the files.
    utilities.copy_files(thread)

    display.reset_buttons('copy_files_page')

    # Pause to let the user read the screen before automatic transition.
    time.sleep(1.0)
    display.show_spinner()

    # [2] Prepare and display the new page.

    display.set_visible('terminal_page__exit_terminal_label', False)

    # Transition to the Copy Files page.
    display.show_page('copy_files_page', 'terminal_page')
    display.reset_buttons('terminal_page', True, True, True)

    # [3] Perform functions on the new page, and activate the new page.

    utilities.check_chroot_environment(thread)
    display.hide_spinner()


#
# Manage Linux Kernels Page
#

def transition__from__manage_linux_kernels_page__to__create_manifest_page(thread):
    # [1] Perform functions on the current page, and deactivate the current page.

    display.show_spinner()
    display.reset_buttons('manage_linux_kernels_page')

    # Transition to the Create Manifest page.

    # [1] Perform functions on the current page, and deactivate the current page.

    # Create filesystem manifest file.
    utilities.create_filesystem_manifest_file(thread)

    # Create a package details list of installed packages and packages to be removed.
    installed_packages_list = utilities.get_installed_packages_list()
    removable_packages_list = utilities.get_removable_packages_list()
    package_details_list = utilities.create_package_details_list(installed_packages_list, removable_packages_list)

    # [2] Prepare and display the new page.

    # TODO: Display a dynamic count of packages that will be removed.
    display.update_label('create_manifest_page__create_filesystem_manifest_result_label', '')
    # display.update_label('create_manifest_page__create_filesystem_manifest_result_label', '...')
    # display.set_sensitive('create_manifest_page__scrolled_window', False)
    display.reset_buttons('create_manifest_page', True, True, False)
    display.update_liststore('create_manifest_page__package_details_liststore', package_details_list)
    # display.set_sensitive('create_manifest_page__scrolled_window', True)

    # Transition to the Create Manifest page.
    display.show_page('manage_linux_kernels_page', 'create_manifest_page')
    display.reset_buttons('create_manifest_page', True, True, True)

    # [3] Perform functions on the new page, and activate the new page.

    display.hide_spinner()


#
# Create Manifest Page
#

def transition__from__create_manifest_page__to__repackage_iso_page(thread):
    # [1] Perform functions on the current page, and deactivate the current page.

    display.show_spinner()
    display.reset_buttons('create_manifest_page')

    # [2] Prepare and display the new page.

    display.update_progressbar_percent('repackage_iso_page__copy_boot_files_progressbar', 0)
    display.update_progressbar_text('repackage_iso_page__copy_boot_files_progressbar', '')
    display.update_progressbar_percent('repackage_iso_page__create_squashfs_progressbar', 0)
    display.update_progressbar_text('repackage_iso_page__create_squashfs_progressbar', '')
    display.update_progressbar_percent('repackage_iso_page__create_iso_image_progressbar', 0)
    display.update_progressbar_text('repackage_iso_page__create_iso_image_progressbar', '')
    display.update_label('repackage_iso_page__update_disk_name_result_label', '...')
    display.update_label('repackage_iso_page__update_md5_sums_result_label', '...')
    display.set_label_error('repackage_iso_page__check_iso_size_result_label', False)
    display.update_label('repackage_iso_page__check_iso_size_result_label', '...')
    display.update_label('repackage_iso_page__calculate_iso_image_md5_sum_result_label', '...')
    display.update_label('repackage_iso_page__calculate_iso_image_md5_filename_result_label', '...')
    display.set_visible('repackage_iso_page__copy_boot_files_spinner', False)
    display.update_status('repackage_iso_page__copy_boot_files', 'bullet')
    display.set_visible('repackage_iso_page__create_squashfs_spinner', False)
    display.update_status('repackage_iso_page__create_squashfs', 'bullet')
    display.set_visible('repackage_iso_page__update_filesystem_size_spinner', False)
    display.update_status('repackage_iso_page__update_filesystem_size', 'bullet')
    display.set_visible('repackage_iso_page__update_disk_name_spinner', False)
    display.update_status('repackage_iso_page__update_disk_name', 'bullet')
    display.set_visible('repackage_iso_page__update_md5_sums_spinner', False)
    display.update_status('repackage_iso_page__update_md5_sums', 'bullet')
    display.set_visible('repackage_iso_page__check_iso_size_spinner', False)
    display.update_status('repackage_iso_page__check_iso_size', 'bullet')
    display.set_visible('repackage_iso_page__create_iso_image_spinner', False)
    display.update_status('repackage_iso_page__create_iso_image', 'bullet')
    display.set_visible('repackage_iso_page__calculate_iso_image_md5_sum_spinner', False)
    display.update_status('repackage_iso_page__calculate_iso_image_md5_sum', 'bullet')

    # Update filesystem.manifest-remove file.
    removable_packages_list = utilities.create_removable_packages_list()
    utilities.create_filesystem_manifest_remove_file(removable_packages_list)

    # Transition to the Repackage ISO page.
    display.show_page('create_manifest_page', 'repackage_iso_page')
    display.reset_buttons('repackage_iso_page', True, True, False)

    # [3] Perform functions on the new page, and activate the new page.

    display.hide_spinner()

    # Copy boot files.
    display.update_status('repackage_iso_page__copy_boot_files', 'processing')
    time.sleep(0.25)
    utilities.copy_boot_files(thread)
    display.update_status('repackage_iso_page__copy_boot_files', 'check')
    time.sleep(1.00)

    # Create squashfs.
    display.update_status('repackage_iso_page__create_squashfs', 'processing')
    time.sleep(0.25)
    utilities.create_squashfs(thread)
    display.update_status('repackage_iso_page__create_squashfs', 'check')
    time.sleep(1.00)

    # Update filesystem size.
    display.update_status('repackage_iso_page__update_filesystem_size', 'processing')
    time.sleep(0.25)
    filesystem_size = utilities.update_filesystem_size(thread)
    logger.log_data('The file system size is', '%.2f GiB (%s bytes)' %
                    ((filesystem_size / 1073741824.0), filesystem_size))
    display.update_label('repackage_iso_page__update_filesystem_size_result_label',
                         'The file system size is %.2f GiB (%s bytes).' %
                         ((filesystem_size / 1073741824.0), filesystem_size))
    display.update_status('repackage_iso_page__update_filesystem_size', 'check')
    time.sleep(1.00)

    # Update disk name.
    display.update_status('repackage_iso_page__update_disk_name', 'processing')
    time.sleep(0.25)
    utilities.update_disk_name()
    utilities.update_disk_info()
    logger.log_data('Updated the disk name', model.custom_iso_image_disk_name)
    display.update_label('repackage_iso_page__update_disk_name_result_label',
                         'The disk name is %s.' % model.custom_iso_image_disk_name)
    display.update_status('repackage_iso_page__update_disk_name', 'check')
    time.sleep(1.00)

    # Update MD5 sums.
    display.update_status('repackage_iso_page__update_md5_sums', 'processing')
    time.sleep(0.25)
    utilities.update_md5_sums()
    filepath = os.path.join(model.custom_live_iso_directory, 'md5sum.txt')
    count = utilities.count_lines(thread, filepath)
    logger.log_data('Number of checksums calculated and added to md5sum.txt', count)
    display.update_label('repackage_iso_page__update_md5_sums_result_label',
                         'Calculated and added checksums for %s files.' % count)
    display.update_status('repackage_iso_page__update_md5_sums', 'check')
    time.sleep(1.00)

    # Check ISO size and create Iso image.
    display.update_status('repackage_iso_page__check_iso_size', 'processing')
    time.sleep(0.25)
    # TODO: Create global constants for hard coded values.
    maximum_iso_size_gib = 4.0
    maximum_iso_size_bytes = maximum_iso_size_gib * 1073741824.0
    directory_size_bytes = utilities.get_directory_size(model.custom_live_iso_directory)
    directory_size_gib = directory_size_bytes / 1073741824.0
    logger.log_data('The total size of all files on the disk is',
                    '%.2f GiB (%s bytes)' % (directory_size_gib, directory_size_bytes))
    logger.log_data('The maximum size of all files on the disk is',
                    '%.2f GiB (%s bytes)' % (maximum_iso_size_gib, maximum_iso_size_bytes))
    # TODO: Add or improve log statments below.
    if directory_size_bytes > maximum_iso_size_bytes:
        # Show directory size error message.
        display.update_status('repackage_iso_page__check_iso_size', 'error')
        display.set_label_error('repackage_iso_page__check_iso_size_result_label', True)
        display.update_label('repackage_iso_page__check_iso_size_result_label',
                             'The total size of all files is %.2f GiB (%i bytes).' %
                             (directory_size_gib, directory_size_bytes) +
                             os.linesep +
                             'This is larger than the %.2f GiB (%i bytes) limit.' %
                             (maximum_iso_size_gib, maximum_iso_size_bytes) +
                             os.linesep +
                             'Click the Back button, and reduce the size of the Linux file system.')
        logger.log_data('Error', 'Disk size exceeds maximum')
    else:
        # Show directory size.
        display.update_status('repackage_iso_page__check_iso_size', 'check')
        display.set_label_error('repackage_iso_page__check_iso_size_result_label', False)
        display.update_label('repackage_iso_page__check_iso_size_result_label',
                             'The total size of all files is %.2f GiB (%s bytes).' %
                             (directory_size_gib, directory_size_bytes))
        # Create Iso image.
        display.update_status('repackage_iso_page__create_iso_image', 'processing')
        time.sleep(0.25)
        utilities.create_iso_image(thread)
        display.update_status('repackage_iso_page__create_iso_image', 'check')
        display.reset_buttons('repackage_iso_page', True, True, True)
        time.sleep(1.00)

        # Calculate ISO image MD5 shecksum.
        display.update_status('repackage_iso_page__calculate_iso_image_md5_sum', 'processing')
        time.sleep(0.25)
        utilities.calculate_iso_md5_sum()
        display.update_label('repackage_iso_page__calculate_iso_image_md5_sum_result_label',
                             'The MD5 checksum is %s.' %
                             model.custom_iso_image_md5_sum)
        display.update_label('repackage_iso_page__calculate_iso_image_md5_filename_result_label',
                             'The MD5 checksum file is %s.' %
                             model.custom_iso_image_md5_filename)
        display.update_status('repackage_iso_page__calculate_iso_image_md5_sum', 'check')
        time.sleep(1.00)


#
# Repackage ISO Page
#

def transition__from__repackage_iso_page__to__finish_page(thread):
    # [1] Perform functions on the current page, and deactivate the current page.

    display.show_spinner()
    display.reset_buttons('repackage_iso_page')

    # [2] Prepare and display the new page.

    # Display custom values.
    display.update_entry('finish_page__custom_iso_image_version_number_entry', model.custom_iso_image_version_number)
    display.update_entry('finish_page__custom_iso_image_filename_entry', model.custom_iso_image_filename)
    display.update_entry('finish_page__custom_iso_image_directory_entry', model.custom_iso_image_directory)
    display.update_entry('finish_page__custom_iso_image_volume_id_entry', model.custom_iso_image_volume_id)
    display.update_entry('finish_page__custom_iso_image_release_name_entry', model.custom_iso_image_release_name)
    display.update_entry('finish_page__custom_iso_image_disk_name_entry', model.custom_iso_image_disk_name)
    display.update_entry('finish_page__custom_iso_image_md5_entry', model.custom_iso_image_md5_sum)
    display.update_entry('finish_page__custom_iso_image_md5_filename_entry', model.custom_iso_image_md5_filename)

    # Transition to the Finish page.
    display.show_page('repackage_iso_page', 'finish_page')
    display.reset_buttons('finish_page', False, False, True)

    # [3] Perform functions on the new page, and activate the new page.

    display.hide_spinner()


################################################################################
# TransitionThread - Transition Back Functions
################################################################################

def transition__from__new_project_page__to__project_directory_page(thread):
    # [1] Perform functions on the current page, and deactivate the current page.

    display.show_spinner()
    display.reset_buttons('new_project_page')

    # Unmount the original iso image and delete the mount point.
    logger.log_data('Unmount and delete the original iso image mount point', model.original_iso_image_mount_point)
    utilities.delete_iso_mount(thread, model.original_iso_image_mount_point)

    # [2] Prepare and display the new page.

    # model.set_project_directory('')
    # display.update_entry('project_directory_page__project_directory_entry', project_directory)

    # Transition to the Project Directory page.
    display.show_page('new_project_page', 'project_directory_page')
    display.reset_buttons('project_directory_page', True, False, True)

    # [3] Perform functions on the new page, and activate the new page.

    display.hide_spinner()


def transition__from__existing_project_page__to__project_directory_page(thread):
    # [1] Perform functions on the current page, and deactivate the current page.

    display.show_spinner()
    display.reset_buttons('existing_project_page')

    # Unmount the original iso image and delete the mount point.
    logger.log_data('Unmount and delete the original iso image mount point', model.original_iso_image_mount_point)
    utilities.delete_iso_mount(thread, model.original_iso_image_mount_point)

    # [2] Prepare and display the new page.

    # model.set_project_directory('')
    # display.update_entry('project_directory_page__project_directory_entry', project_directory)

    # Transition to the Project Directory page.
    display.show_page('existing_project_page', 'project_directory_page')
    display.reset_buttons('project_directory_page', True, False, True)

    # [3] Perform functions on the new page, and activate the new page.

    display.hide_spinner()


def transition__from__delete_project_page__to__existing_project_page(thread):
    # [1] Perform functions on the current page, and deactivate the current page.

    display.show_spinner()
    display.reset_buttons('delete_project_page')

    display.set_sensitive('existing_project_page__original_iso_image_filepath_filechooser_open_button', False)

    validators.validate_existing_project_page_for_delete()

    # [2] Prepare and display the new page.

    # Transition to the Existing Project page.
    display.show_page('delete_project_page', 'existing_project_page')
    display.reset_buttons('existing_project_page', True, True, True)

    # [3] Perform functions on the new page, and activate the new page.

    display.hide_spinner()


def transition__from__unsquashfs_page__to__existing_project_page(thread):
    # [1] Perform functions on the current page, and deactivate the current page.

    model.set_propagate(False)

    display.show_spinner()
    display.reset_buttons('unsquashfs_page')

    if not model.is_success_copy_original_iso_files:
        display.set_label_error('unsquashfs_page__copy_original_iso_files_result_label', True)
        display.update_label('unsquashfs_page__copy_original_iso_files_result_label', 'Unable to copy original iso files.')
        display.update_status('unsquashfs_page__copy_original_iso_files', 'error')
    if not model.is_success_extract_squashfs:
        display.set_label_error('unsquashfs_page__unsquashfs_result_label', True)
        display.update_label('unsquashfs_page__unsquashfs_result_label', 'Unable to extract the compressed Linux file system.')
        display.update_status('unsquashfs_page__unsquashfs', 'error')

    # Save the configuration (since it may have changed).
    utilities.save_configuration()
    time.sleep(1.00)

    # [2] Prepare and display the new page.

    # Display original values.
    display.update_entry('existing_project_page__original_iso_image_filename_entry', model.original_iso_image_filename)
    display.update_entry('existing_project_page__original_iso_image_directory_entry', model.original_iso_image_directory)
    display.update_entry('existing_project_page__original_iso_image_volume_id_entry', model.original_iso_image_volume_id)
    display.update_entry('existing_project_page__original_iso_image_release_name_entry', model.original_iso_image_release_name)
    display.update_entry('existing_project_page__original_iso_image_disk_name_entry', model.original_iso_image_disk_name)

    # Display custom values.
    display.update_entry('existing_project_page__custom_iso_image_version_number_entry', model.custom_iso_image_version_number)
    display.update_entry('existing_project_page__custom_iso_image_filename_entry', model.custom_iso_image_filename)
    display.update_entry('existing_project_page__custom_iso_image_directory_entry', model.custom_iso_image_directory)
    display.update_entry('existing_project_page__custom_iso_image_volume_id_entry', model.custom_iso_image_volume_id)
    display.update_entry('existing_project_page__custom_iso_image_release_name_entry', model.custom_iso_image_release_name)
    display.update_entry('existing_project_page__custom_iso_image_disk_name_entry', model.custom_iso_image_disk_name)

    # Transition to the Existing Project page.
    display.show_page('unsquashfs_page', 'existing_project_page')
    display.reset_buttons('existing_project_page', True, True, True)

    # [3] Perform functions on the new page, and activate the new page.

    validators.validate_existing_project_page()

    display.hide_spinner()

    model.set_propagate(True)


def transition__from__terminal_page__to__existing_project_page(thread):
    # [1] Perform functions on the current page, and deactivate the current page.

    model.set_propagate(False)

    display.show_spinner()
    display.reset_buttons('terminal_page')

    # Exit the chroot environment.
    utilities.exit_chroot_environment(thread)

    # [2] Prepare and display the new page.

    # Display original values.
    display.update_entry('existing_project_page__original_iso_image_filename_entry', model.original_iso_image_filename)
    display.update_entry('existing_project_page__original_iso_image_directory_entry', model.original_iso_image_directory)
    display.update_entry('existing_project_page__original_iso_image_volume_id_entry', model.original_iso_image_volume_id)
    display.update_entry('existing_project_page__original_iso_image_release_name_entry', model.original_iso_image_release_name)
    display.update_entry('existing_project_page__original_iso_image_disk_name_entry', model.original_iso_image_disk_name)

    # Display custom values.
    display.update_entry('existing_project_page__custom_iso_image_version_number_entry', model.custom_iso_image_version_number)
    display.update_entry('existing_project_page__custom_iso_image_filename_entry', model.custom_iso_image_filename)
    display.update_entry('existing_project_page__custom_iso_image_directory_entry', model.custom_iso_image_directory)
    display.update_entry('existing_project_page__custom_iso_image_volume_id_entry', model.custom_iso_image_volume_id)
    display.update_entry('existing_project_page__custom_iso_image_release_name_entry', model.custom_iso_image_release_name)
    display.update_entry('existing_project_page__custom_iso_image_disk_name_entry', model.custom_iso_image_disk_name)

    # Transition to the Existing Project page.
    display.show_page('terminal_page', 'existing_project_page')
    display.reset_buttons('existing_project_page', True, True, True)

    # [3] Perform functions on the new page, and activate the new page.

    validators.validate_existing_project_page()

    display.hide_spinner()

    model.set_propagate(True)


def transition__from__copy_files_page__to__terminal_page_cancel_copy_files(thread):
    # [1] Perform functions on the current page, and deactivate the current page.

    # [2] Prepare and display the new page.

    transition('copy_files_page', 'terminal_page', True, True, True)

    # [3] Perform functions on the new page, and activate the new page.


def transition__from__manage_linux_kernels_page__to__terminal_page(thread):
    # [1] Perform functions on the current page, and deactivate the current page.

    display.show_spinner()
    display.reset_buttons('manage_linux_kernels_page')

    utilities.prepare_chroot_environment(thread)
    utilities.enter_chroot_environment(thread)

    # [2] Prepare and display the new page.

    display.set_visible('terminal_page__exit_terminal_label', False)

    # Transition to the Terminal page.
    display.show_page('manage_linux_kernels_page', 'terminal_page')
    display.reset_buttons('terminal_page', True, True, True)

    # [3] Perform functions on the new page, and activate the new page.

    utilities.check_chroot_environment(thread)
    display.hide_spinner()


def transition__from__manage_linux_kernels_page__to__existing_project_page(thread):
    # [1] Perform functions on the current page, and deactivate the current page.

    # [2] Prepare and display the new page.

    transition('manage_linux_kernels_page', 'existing_project_page', True, True, True)

    # [3] Perform functions on the new page, and activate the new page.

    validators.validate_existing_project_page()


def transition__from__create_manifest_page__to__manage_linux_kernels_page(thread):
    # [1] Perform functions on the current page, and deactivate the current page.

    display.show_spinner()
    display.reset_buttons('create_manifest_page')

    # [2] Prepare and display the new page.

    # Transition to the Create Manifest page.
    display.show_page('create_manifest_page', 'manage_linux_kernels_page')
    display.reset_buttons('manage_linux_kernels_page', True, True, True)

    # [3] Perform functions on the new page, and activate the new page.

    display.hide_spinner()


def transition__from__repackage_iso_page__to__create_manifest_page(thread):
    # [1] Perform functions on the current page, and deactivate the current page.

    display.show_spinner()
    display.reset_buttons('repackage_iso_page')

    # [2] Prepare and display the new page.

    # Transition to the Create Manifest page.
    display.show_page('repackage_iso_page', 'create_manifest_page')
    display.reset_buttons('create_manifest_page', True, True, True)

    # [3] Perform functions on the new page, and activate the new page.

    display.hide_spinner()


################################################################################
# TransitionThread - Transition Exit Functions
################################################################################

def transition__from__project_directory_page__to__exit(thread):
    # [1] Perform functions on the current page, and deactivate the current page.

    print()
    logger.log_step('Exiting from project directory page')
    display.show_spinner()
    display.reset_buttons('project_directory_page')

    display.main_quit()
    display.hide_spinner()

    # [2] Prepare and display the new page.

    # [3] Perform functions on the new page, and activate the new page.

    logger.log_note('Finished exiting.')


def transition__from__new_project_page__to__exit(thread):
    # [1] Perform functions on the current page, and deactivate the current page.

    print()
    logger.log_step('Exiting from new project page')
    display.show_spinner()
    display.reset_buttons('new_project_page')

    # Unmount the original iso image and delete the mount point.
    logger.log_data('Unmount and delete the original iso image mount point', model.original_iso_image_mount_point)
    utilities.delete_iso_mount(thread, model.original_iso_image_mount_point)

    display.main_quit()
    display.hide_spinner()

    # [2] Prepare and display the new page.

    # [3] Perform functions on the new page, and activate the new page.

    logger.log_note('Finished exiting.')


def transition__from__existing_project_page__to__exit(thread):
    # [1] Perform functions on the current page, and deactivate the current page.

    print()
    logger.log_step('Exiting from existing project page')
    display.show_spinner()
    display.reset_buttons('existing_project_page')

    # Unmount the original iso image and delete the mount point.
    logger.log_data('Unmount and delete the original iso image mount point', model.original_iso_image_mount_point)
    utilities.delete_iso_mount(thread, model.original_iso_image_mount_point)

    display.main_quit()
    display.hide_spinner()

    # [2] Prepare and display the new page.

    # [3] Perform functions on the new page, and activate the new page.

    logger.log_note('Finished exiting.')


def transition__from__delete_project_page__to__exit(thread):
    # [1] Perform functions on the current page, and deactivate the current page.

    print()
    logger.log_step('Exiting from confirm delete project page')
    display.show_spinner()
    display.reset_buttons('delete_project_page')

    # Unmount the original iso image and delete the mount point.
    logger.log_data('Unmount and delete the original iso image mount point', model.original_iso_image_mount_point)
    utilities.delete_iso_mount(thread, model.original_iso_image_mount_point)

    display.main_quit()
    display.hide_spinner()

    # [2] Prepare and display the new page.

    # [3] Perform functions on the new page, and activate the new page.

    logger.log_note('Finished exiting.')


def transition__from__unsquashfs_page__to__exit(thread):
    # [1] Perform functions on the current page, and deactivate the current page.

    print()
    logger.log_step('Exiting from unsquashfs page')
    if not model.is_success_copy_original_iso_files:
        display.set_label_error('unsquashfs_page__copy_original_iso_files_result_label', True)
        display.update_label('unsquashfs_page__copy_original_iso_files_result_label', 'Unable to copy orioginal iso files.')
        display.update_status('unsquashfs_page__copy_original_iso_files', 'error')
        # Delete the custom live iso directory because it may be corrupt.
        # logger.log_data('Delete the custom live iso directory', model.custom_live_iso_directory)
        # utilities.delete_file(thread, model.custom_live_iso_directory)
    if not model.is_success_extract_squashfs:
        display.set_label_error('unsquashfs_page__unsquashfs_result_label', True)
        display.update_label('unsquashfs_page__unsquashfs_result_label', 'Unable to extract the compressed Linux file system.')
        display.update_status('unsquashfs_page__unsquashfs', 'error')
        # Delete the custom squashfs directory because it may be corrupt.
        # logger.log_data('Delete the custom squashfs directory', model.custom_squashfs_directory)
        # utilities.delete_file(thread, model.custom_squashfs_directory)
    display.show_spinner()
    display.reset_buttons('unsquashfs_page')

    # Unmount the original iso image and delete the mount point.
    logger.log_data('Unmount and delete the original iso image mount point', model.original_iso_image_mount_point)
    utilities.delete_iso_mount(thread, model.original_iso_image_mount_point)

    # Save the configuration (since it may have changed).
    # utilities.save_configuration()

    display.main_quit()
    display.hide_spinner()

    # [2] Prepare and display the new page.

    # [3] Perform functions on the new page, and activate the new page.

    logger.log_note('Finished exiting.')


def transition__from__terminal_page__to__exit(thread):
    # [1] Perform functions on the current page, and deactivate the current page.

    print()
    logger.log_step('Exiting from terminal page')
    display.show_spinner()
    display.reset_buttons('terminal_page')

    # Unmount and delete directory (original-iso-mount).
    logger.log_data('Unmount and delete the original iso image mount point', model.original_iso_image_mount_point)
    utilities.delete_iso_mount(thread, model.original_iso_image_mount_point)

    # Exit the chroot environment.
    utilities.exit_chroot_environment(thread)

    display.main_quit()
    display.hide_spinner()

    # [2] Prepare and display the new page.

    # [3] Perform functions on the new page, and activate the new page.

    logger.log_note('Finished exiting.')


def transition__from__terminal_page__to__terminal_page(thread):
    # [1] Perform functions on the current page, and deactivate the current page.

    print()
    logger.log_step('Exited terminal. Remain on terminal page')
    display.show_spinner()
    display.reset_buttons('terminal_page', True, True, False)

    # Unmount and delete directory (original-iso-mount).
    # logger.log_data('Unmount and delete the original iso image mount point', model.original_iso_image_mount_point)
    # utilities.delete_iso_mount(thread, model.original_iso_image_mount_point)

    # Exit the chroot environment.
    utilities.exit_chroot_environment(thread)

    # [2] Prepare and display the new page.

    # Do not transition to the Terminal Page, since we are already on this page.
    # This is a special case, because the terminal also exits during normal
    # operation (when the Quit, Back or Next buttons are clicked). The function,
    # handlers.on_child_exited__terminal_page(), is also invoked in all cases,
    # and transitioning to the terminal page would interfere with transitions to
    # the new page (when the Back or Next buttons are clicked).
    # display.show_page('terminal_page', 'terminal_page')
    display.reset_buttons('terminal_page', True, True, False)

    display.set_visible('terminal_page__exit_terminal_label', True)
    display.set_label_error('terminal_page__exit_terminal_label', True)

    # [3] Perform functions on the new page, and activate the new page.

    display.hide_spinner()


def transition__from__copy_files_page__to__exit(thread):
    # [1] Perform functions on the current page, and deactivate the current page.

    # This is the same as exiting the terminal page.
    print()
    logger.log_step('Exiting from confirm copy page')
    display.show_spinner()
    display.reset_buttons('copy_files_page')

    # Unmount and delete directory (original-iso-mount).
    logger.log_data('Unmount and delete the original iso image mount point', model.original_iso_image_mount_point)
    utilities.delete_iso_mount(thread, model.original_iso_image_mount_point)

    # Exit the chroot environment.
    utilities.exit_chroot_environment(thread)

    display.main_quit()
    display.hide_spinner()

    # [2] Prepare and display the new page.

    # [3] Perform functions on the new page, and activate the new page.

    logger.log_note('Finished exiting.')


def transition__from__manage_linux_kernels_page__to__exit(thread):
    # [1] Perform functions on the current page, and deactivate the current page.

    print()
    logger.log_step('Exiting from manage linux kernels page')
    display.show_spinner()
    display.reset_buttons('manage_linux_kernels_page')

    # Unmount and delete directory (original-iso-mount).
    logger.log_data('Unmount and delete the original iso image mount point', model.original_iso_image_mount_point)
    utilities.delete_iso_mount(thread, model.original_iso_image_mount_point)

    display.main_quit()
    display.hide_spinner()

    # [2] Prepare and display the new page.

    # [3] Perform functions on the new page, and activate the new page.

    logger.log_note('Finished exiting.')


def transition__from__create_manifest_page__to__exit(thread):
    # [1] Perform functions on the current page, and deactivate the current page.

    print()
    logger.log_step('Exiting from create filesystem manifest page')
    display.show_spinner()
    display.reset_buttons('create_manifest_page')

    # Unmount and delete directory (original-iso-mount).
    logger.log_data('Unmount and delete the original iso image mount point', model.original_iso_image_mount_point)
    utilities.delete_iso_mount(thread, model.original_iso_image_mount_point)

    display.main_quit()
    display.hide_spinner()

    # [2] Prepare and display the new page.

    # [3] Perform functions on the new page, and activate the new page.

    logger.log_note('Finished exiting.')


def transition__from__repackage_iso_page__to__exit(thread):
    # [1] Perform functions on the current page, and deactivate the current page.

    print()
    logger.log_step('Exiting from repackage iso page')
    display.show_spinner()
    display.reset_buttons('repackage_iso_page')

    # Unmount and delete directory (original-iso-mount).
    logger.log_data('Unmount and delete the original iso image mount point', model.original_iso_image_mount_point)
    utilities.delete_iso_mount(thread, model.original_iso_image_mount_point)

    # Delete the custom live iso directory (custom-live-iso) because it may be corrupt.
    # TODO: It may be more efficient to check if everything completed successfully.
    #       If so, no need to delete this.
    #       Technically, you could leave this, because it will get overwritten, next time.
    # logger.log_data('Delete the custom live iso directory', model.custom_live_iso_directory)
    # utilities.delete_file(thread, model.custom_live_iso_directory)

    display.main_quit()
    display.hide_spinner()

    # [2] Prepare and display the new page.

    # [3] Perform functions on the new page, and activate the new page.

    logger.log_note('Finished exiting.')


def transition__from__finish_page__to__exit(thread):
    # [1] Perform functions on the current page, and deactivate the current page.

    print()
    logger.log_step('Exiting from finish page')
    display.show_spinner()
    display.reset_buttons('finish_page')

    # Unmount and delete directory (original-iso-mount).
    logger.log_data('Unmount and delete the original iso image mount point', model.original_iso_image_mount_point)
    utilities.delete_iso_mount(thread, model.original_iso_image_mount_point)

    # Delete project files, if requested.
    checkbutton = model.builder.get_object('finish_page__delete_project_files_checkbutton')
    is_active = checkbutton.get_active()
    logger.log_data('The delete project files checkbutton is checked?', is_active)
    if is_active:
        # Delete directory: custom-live-iso
        logger.log_data('Delete the custom live iso directory', model.custom_live_iso_directory)
        utilities.delete_file(thread, model.custom_live_iso_directory)

        # Delete file: cubic.conf
        logger.log_data('Delete the configuration file', model.configuration_filepath)
        utilities.delete_file(thread, model.configuration_filepath)

        # Delete directory: squashfs-root
        logger.log_data('Delete the custom squashfs directory', model.custom_squashfs_directory)
        utilities.delete_file(thread, model.custom_squashfs_directory)

        # Delete directory: project directory
        # Do not delete this directory because it may be used for other purposes.
        # logger.log_data('Delete the project directory', model.project_directory)
        # try:
        #     os.rmdir(model.project_directory)
        # except OSError as exception:
        #     logger.log_data('The directory could not be deleted due to', exception)

    display.main_quit()
    display.hide_spinner()

    # [2] Prepare and display the new page.

    # [3] Perform functions on the new page, and activate the new page.

    logger.log_note('Finished exiting.')
