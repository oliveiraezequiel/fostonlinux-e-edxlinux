#include "config.h"

#include "SDL.h"

#include "hwsdl_mouse.c"
