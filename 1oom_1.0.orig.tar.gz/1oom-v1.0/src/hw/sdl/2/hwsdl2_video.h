#ifndef INC_1OOM_HWSDL2_VIDEO_H
#define INC_1OOM_HWSDL2_VIDEO_H

extern int hw_video_get_window_id(void);

#endif
