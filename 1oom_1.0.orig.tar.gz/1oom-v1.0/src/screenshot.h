#ifndef INC_1OOM_SCREENSHOT_H
#define INC_1OOM_SCREENSHOT_H

#include "types.h"

extern bool screenshot_save(const uint8_t *screen, const uint8_t *pal, int w, int h);

#endif
