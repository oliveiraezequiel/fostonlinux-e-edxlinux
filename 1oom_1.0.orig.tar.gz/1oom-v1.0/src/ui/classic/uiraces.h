#ifndef INC_1OOM_UIRACES_H
#define INC_1OOM_UIRACES_H

#include "game_types.h"

struct game_s;

extern int ui_races(struct game_s *g, player_id_t pi);

#endif
