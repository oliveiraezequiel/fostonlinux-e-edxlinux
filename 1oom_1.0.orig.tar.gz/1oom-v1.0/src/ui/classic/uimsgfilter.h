#ifndef INC_1OOM_UIMSGFILTER_H
#define INC_1OOM_UIMSGFILTER_H

#include "game_types.h"

struct game_s;

extern void ui_msg_filter(struct game_s *g, player_id_t pi);

#endif
