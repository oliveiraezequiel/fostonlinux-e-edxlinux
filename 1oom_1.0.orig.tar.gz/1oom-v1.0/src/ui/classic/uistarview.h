#ifndef INC_1OOM_UISTARVIEW_H
#define INC_1OOM_UISTARVIEW_H

#include "game_types.h"
#include "types.h"

struct game_s;

extern void ui_starview(struct game_s *g, player_id_t pi);

#endif
