#ifndef INC_1OOM_UINEWS_H
#define INC_1OOM_UINEWS_H

#include "types.h"

extern void ui_news_won(bool flag_good);

#endif
