#ifndef INC_1OOM_UIBASESCRAP_H
#define INC_1OOM_UIBASESCRAP_H

#include "game_types.h"
#include "types.h"

struct game_s;

extern void ui_basescrap(struct game_s *g, player_id_t pi);

#endif
