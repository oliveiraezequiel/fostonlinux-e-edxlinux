#ifndef INC_1OOM_GAME_BOMB_H
#define INC_1OOM_GAME_BOMB_H

struct game_s;

extern void game_turn_bomb(struct game_s *g);

#endif
