#!/bin/sh

echo "No bindist for this platform. Copy src/1oom_* somewhere or use make install."

exit 1
