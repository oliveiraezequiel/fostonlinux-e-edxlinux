#include "palette.h"

uint8_t ui_palette[256*3] = {0};
