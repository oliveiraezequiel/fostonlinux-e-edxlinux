#ifndef INC_1OOM_TYPES_H
#define INC_1OOM_TYPES_H

#include <inttypes.h>
#include <stdbool.h>
#include <stddef.h>

#endif
