#ifndef INC_1OOM_UISOUND_H
#define INC_1OOM_UISOUND_H

extern void ui_sound_play_sfx_24(void);
extern void ui_sound_play_sfx_06(void);
extern void ui_sound_stop_sfx(void);
extern void ui_sound_play_music(int musici);
extern void ui_sound_stop_music(void);

#endif
