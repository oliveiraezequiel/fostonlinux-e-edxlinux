#ifndef INC_1OOM_UIHELP_H
#define INC_1OOM_UIHELP_H

extern void ui_help(int help_index);

#endif
