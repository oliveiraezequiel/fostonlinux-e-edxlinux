#ifndef INC_1OOM_UITECH_H
#define INC_1OOM_UITECH_H

#include "game_types.h"

struct game_s;

extern void ui_tech(struct game_s *g, player_id_t pi);

#endif
