#ifndef INC_1OOM_UIEMPIREREPORT_H
#define INC_1OOM_UIEMPIREREPORT_H

#include "game_types.h"

struct game_s;

extern void ui_empirereport(struct game_s *g, player_id_t active_player, player_id_t pi);

#endif
