#ifndef INC_1OOM_UIPLANETS_H
#define INC_1OOM_UIPLANETS_H

#include "game_types.h"

struct game_s;

extern void ui_planets(struct game_s *g, player_id_t pi);

#endif
