#ifndef INC_1OOM_UILOAD_H
#define INC_1OOM_UILOAD_H

/* returns -1 on cancel or 0..5 on load game */
extern int ui_load_game(void);

#endif
