#ifndef INC_1OOM_UIFLEET_H
#define INC_1OOM_UIFLEET_H

#include "game_types.h"
#include "types.h"

struct game_s;

extern int ui_fleet(struct game_s *g, player_id_t pi);

#endif
