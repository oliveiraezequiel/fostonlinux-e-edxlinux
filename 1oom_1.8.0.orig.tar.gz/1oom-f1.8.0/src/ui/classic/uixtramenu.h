#ifndef INC_1OOM_UIXTRAMENU_H
#define INC_1OOM_UIXTRAMENU_H

#include "uidefs.h"

struct game_s;

extern ui_main_loop_action_t ui_xtramenu(struct game_s *g, player_id_t pi);

#endif
