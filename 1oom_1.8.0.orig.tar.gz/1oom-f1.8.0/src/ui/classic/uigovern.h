#ifndef INC_1OOM_UIGOVERN_H
#define INC_1OOM_UIGOVERN_H

#include "game_types.h"
#include "types.h"

struct game_s;

extern void ui_govern(struct game_s *g, player_id_t pi);

#endif
