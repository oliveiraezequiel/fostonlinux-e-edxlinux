#ifndef INC_1OOM_UIDEBUG_H
#define INC_1OOM_UIDEBUG_H

#include "uidefs.h"

extern const struct input_cmd_s ui_cmds_debug[];

#endif
