#ifndef INC_1OOM_UISAVE_H
#define INC_1OOM_UISAVE_H

struct input_token_s;

extern int ui_cmd_save(struct game_s *g, int api, struct input_token_s *param, int num_param, void *var);

#endif
