#ifndef INC_1OOM_OSDEFS_H
#define INC_1OOM_OSDEFS_H

#define FSDEV_PATH_MAX  2048
#define FSDEV_DIR_SEP_STR    "\\"
#define FSDEV_DIR_SEP_CHR    '\\'
#define FSDEV_DIR_SEP_ALT    '/'
#define FSDEV_EXT_SEP_STR    "."
#define FSDEV_EXT_SEP_CHR    '.'

#endif
