#ifndef INC_1OOM_OSDEFS_H
#define INC_1OOM_OSDEFS_H

#define FSDEV_PATH_MAX  1024
#define FSDEV_DIR_SEP_STR    "\\"
#define FSDEV_DIR_SEP_CHR    '\\'
#define FSDEV_EXT_SEP_STR    "."
#define FSDEV_EXT_SEP_CHR    '.'

#define OS_UI_SCALE_MAX  2

#endif
