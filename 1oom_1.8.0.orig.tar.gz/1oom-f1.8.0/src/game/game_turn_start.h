#ifndef INC_1OOM_GAME_TURN_START_H
#define INC_1OOM_GAME_TURN_START_H

#include "game_types.h"

struct game_s;

extern void game_turn_start_messages(struct game_s *g, player_id_t pi);

#endif
