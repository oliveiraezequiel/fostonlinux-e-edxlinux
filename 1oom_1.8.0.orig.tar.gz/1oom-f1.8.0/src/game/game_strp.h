#ifndef INC_1OOM_GAME_STRP_H
#define INC_1OOM_GAME_STRP_H

extern void game_str_shutdown(void);
extern void game_str_dump(void);

#endif
