#ifndef INC_1OOM_GAME_NEBULA_H
#define INC_1OOM_GAME_NEBULA_H

#include "types.h"

#define NEBULA_TYPE_NUM 10

extern const uint8_t tbl_nebula_data[NEBULA_TYPE_NUM][4][4];

#endif
