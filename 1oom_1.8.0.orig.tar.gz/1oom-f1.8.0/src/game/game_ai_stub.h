#ifndef INC_1OOM_GAME_AI_STUB_H
#define INC_1OOM_GAME_AI_STUB_H

#include "game_ai.h"

extern const struct game_ai_s game_ai_stub;

#endif
