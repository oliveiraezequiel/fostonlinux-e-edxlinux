#include "hwalleg_mouse.c"
