#ifndef INC_1OOM_HWSDL_AUDIO_H
#define INC_1OOM_HWSDL_AUDIO_H

extern int hw_audio_init(void);
extern void hw_audio_shutdown(void);

#endif
