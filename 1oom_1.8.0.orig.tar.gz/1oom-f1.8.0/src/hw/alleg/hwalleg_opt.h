#ifndef INC_1OOM_HWSDL_OPT_H
#define INC_1OOM_HWSDL_OPT_H

extern bool hw_opt_fullscreen;
extern bool hw_opt_relmouse;
extern int hw_opt_mouse_slowdown_x;
extern int hw_opt_mouse_slowdown_y;

#endif
